// ============================================================
// Rollercoaster 3D visualiser — "the virtual rollercoaster"
// Adapted from https://codepen.io/ycw/pen/OJRwedY (three.js r124)
// into a self-contained ES module that renders inside a round
// disc (the main player's MEDIA WINDOW, or the full playlist circle).
//
// MULTI-INSTANCE (Entry S21): _boot(host, opts) builds a fully
// independent instance (own canvas/scene/camera/renderer/composer).
// createInstance(hostOrId, opts) is the public factory.
// The MAIN player instance boots on #player and is exposed as
// window.RoundViz3D (backward compatible — all existing
// window.RoundViz3D.setActive/setColors/setFog/... calls keep
// working). A second instance is created on the playlist circle via
// window.RoundViz3D.create('playlistCircle', {...}).
// ============================================================
import * as THREE from './vendor/three/three.module.js';
import { EffectComposer } from './vendor/three/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from './vendor/three/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from './vendor/three/jsm/postprocessing/UnrealBloomPass.js';
import { Curves } from './vendor/three/jsm/curves/CurveExtras.js';

// Public factory: builds an independent coaster instance inside `host`.
// opts:
//   heightFraction – 0.5 (main player media window = top half) | 1 (full disc)
//   scaleMode      – 'viz' (cinema-aware --viz-scale/--viz-cinema-scale) | 'pl' (--pl-viz-scale)
//   canvasClass    – class of the WebGL canvas element to create/reuse
//   fogClass       – class of the black-fog backdrop layer to create/reuse
//   colorHost      – element whose computed style supplies the theme colour
//                    vars (defaults to #player, where the theme lives)
function createInstance(hostOrId, opts){
  const host = (typeof hostOrId === 'string') ? document.getElementById(hostOrId) : hostOrId;
  return host ? _boot(host, opts || {}) : null;
}

function _boot(host, opts){
  opts = opts || {};
  const heightFraction = (opts.heightFraction != null) ? opts.heightFraction : 0.5;
  const scaleMode = opts.scaleMode || 'viz';
  const canvasClass = opts.canvasClass || 'viz-canvas-3d';
  const fogClass = opts.fogClass || 'viz-fog-layer';
  const colorHost = opts.colorHost || document.getElementById('player') || host;

  // Per-instance ready promise (resolved synchronously at the end of _boot).
  let readyResolve = null;
  const ready = new Promise(res => { readyResolve = res; });

  // black-fog backdrop layer: sits between the artwork and the 3D canvas.
  // The canvas screens against it, so its opacity dials the black
  // background in/out (0 = artwork visible, 1 = full v52 black).
  let fogLayer = host.querySelector('.' + fogClass);
  if (!fogLayer){
    fogLayer = document.createElement('div');
    fogLayer.className = fogClass;
    const ref = host.querySelector('.' + canvasClass + ', .viz-canvas-3d, #vizCanvas, .dash, .pl-scrim');
    host.insertBefore(fogLayer, ref || host.firstChild);
  }
  let fogAmount = 0;

  // own canvas, placed in the media window (top half), below controls
  let cv = host.querySelector('.' + canvasClass);
  if (!cv){
    cv = document.createElement('canvas');
    cv.className = canvasClass;
    cv.setAttribute('aria-hidden', 'true');
    const ref = host.querySelector('#vizCanvas, .dash, .pl-scrim');
    host.insertBefore(cv, ref || host.firstChild);
  }

  const renderer = new THREE.WebGLRenderer({ canvas: cv, alpha: true, antialias: true });
  renderer.setClearColor(0x000000, 0);   // transparent: artwork can show through

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x000000, 0.05);
  scene.add(new THREE.HemisphereLight(0x00ffff, 0xff8c00, 2));

  const camera = new THREE.PerspectiveCamera(75, 2, 0.01, 5000);

  // ---- the track ----
  const mpms = 20 / 1e3;
  const steps = 2000;

  // ---- frames: ORIGINAL Frenet frames + seam-closure blend ----
  // The camera keeps the ORIGINAL codepen behaviour (Frenet binormal up:
  // it banks and swoops through the turns exactly like the pen). The one
  // flaw of the raw Frenet frames is that they don't close: the binormal
  // at the end of the lap is ~171° away from the start, so the original
  // camera snapped violently at the wrap — that snap WAS the "break".
  // Fix: ease the binormal into the start frame over the last stretch of
  // the lap, so frame[steps] === frame[0] and the loop joins seamlessly.
  // 88% of the lap is bit-for-bit the original feel; the tail is a smooth
  // gentle twist that both the track and the camera share.
  function buildSeamlessFrames(curve, n){
    const frenet = curve.computeFrenetFrames(n, false);   // ORIGINAL frames
    const UP_BLEND_START = 0.80;   // last 20% of the lap: the corkscrew join
    const blendK = u => {
      if (u <= UP_BLEND_START) return 0;
      const k = Math.min(1, (u - UP_BLEND_START) / (1 - UP_BLEND_START));
      return k * k * (3 - 2 * k);                          // smoothstep
    };
    const points = [], tangents = [], normals = [], binormals = [];
    const tmpN = new THREE.Vector3(), crossT = new THREE.Vector3(), tmpQ = new THREE.Quaternion();
    // TOTAL closure angle, measured ONCE: the signed roll (around the final
    // tangent) that takes the raw end binormal onto the start binormal.
    // A single constant = a smooth, continuous sweep — no per-frame atan2
    // branch flips (those caused the wild mid-blend jumps).
    const phiTotal = Math.atan2(
      crossT.crossVectors(frenet.binormals[n], frenet.binormals[0]).dot(frenet.tangents[n]),
      frenet.binormals[n].dot(frenet.binormals[0]));
    for (let i = 0; i <= n; i++){
      const u = i / n;
      points.push(curve.getPointAt(u, new THREE.Vector3()));
      tangents.push(frenet.tangents[i]);
      const k = blendK(u);
      let b = frenet.binormals[i].clone();
      if (k > 0){
        // PURE ROLL around the track's tangent by k×phiTotal: the camera +
        // track corkscrew smoothly into the loop's start. At u=1 this lands
        // EXACTLY on binormal[0], so the track joins seamlessly.
        tmpQ.setFromAxisAngle(frenet.tangents[i], phiTotal * k);
        b.applyQuaternion(tmpQ);
      }
      binormals.push(b);
      normals.push(tmpN.crossVectors(tangents[i], b).normalize().clone());
    }
    // raw Frenet seam mismatch (for diagnostics): how far the ORIGINAL up
    // would snap at the wrap
    const twist = Math.acos(Math.max(-1, Math.min(1,
      frenet.binormals[0].dot(frenet.binormals[n - 1]))));
    return { points, tangents, normals, binormals, frenet, twist, UP_BLEND_START };
  }

  // ---- cross-section contour (same silhouette as the original) ----
  function sampleContour(){
    const pts = [];
    const quad = (p0, c, p1, segs) => {
      for (let i = 0; i < segs; i++){
        const t = i / segs, u = 1 - t;
        pts.push([u*u*p0[0] + 2*u*t*c[0] + t*t*p1[0],
                  u*u*p0[1] + 2*u*t*c[1] + t*t*p1[1]]);
      }
    };
    quad([-5, -1], [0, -4], [5, -1], 4);   // top curve
    pts.push([6, -1]);                     // right nub
    quad([6, -1], [0, -5], [-6, -1], 4);   // bottom curve
    pts.push([-5, -1]);                    // close back
    return pts;
  }

  const extrudePath = new Curves.TorusKnot();
  const frames = buildSeamlessFrames(extrudePath, steps);
  const contour = sampleContour();
  const COLS = contour.length;

  // ---- build the ribbon geometry (side walls) from those frames ----
  // Axis convention MUST match three.js ExtrudeGeometry (v52's track):
  //   shape X -> NORMAL, shape Y -> BINORMAL
  // (three's code: normal.copy(normals[s]).multiplyScalar(vert.x);
  //                binormal.copy(binormals[s]).multiplyScalar(vert.y);)
  // Swapping these rotates the road 90° around the path — the track then
  // runs down the LEFT of the view instead of along the BOTTOM.
  const verts = [], uvs = [], idx = [];
  const PB = new THREE.Vector3(), PN = new THREE.Vector3(), PP = new THREE.Vector3();
  for (let i = 0; i <= steps; i++){
    PP.copy(frames.points[i]); PB.copy(frames.binormals[i]); PN.copy(frames.normals[i]);
    for (let c = 0; c < COLS; c++){
      const sx = contour[c][0], sy = contour[c][1];
      verts.push(PP.x + PN.x*sx + PB.x*sy, PP.y + PN.y*sx + PB.y*sy, PP.z + PN.z*sx + PB.z*sy);
      uvs.push(c / (COLS - 1), i / steps);
    }
  }
  for (let i = 0; i < steps; i++){
    for (let c = 0; c < COLS - 1; c++){
      const a = i * COLS + c, b = a + 1;
      const d = (i + 1) * COLS + c, e = d + 1;
      idx.push(a, b, e, a, e, d);
    }
  }
  const ribbonGeom = new THREE.BufferGeometry();
  ribbonGeom.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
  ribbonGeom.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
  ribbonGeom.setIndex(idx);
  ribbonGeom.computeVertexNormals();
  let sideMat = null;
  let scheme = 'theme';

  // ---- procedural neon texture (no network dependency) ----
  // Colour scheme drives the texture:
  //   theme   -> the player's current theme gradient (DEFAULT look)
  //   rainbow -> full hue sweep
  //   mono    -> single colour (the player's --btn-play-fg)
  function buildSideMat(scheme){
    const cs = getComputedStyle(colorHost);
    const c1 = cs.getPropertyValue('--progress-start').trim() || '#ff2992';
    const c2 = cs.getPropertyValue('--progress-mid').trim() || '#ffb84d';
    const c3 = cs.getPropertyValue('--progress-end').trim() || '#29d5ff';
    const mono = cs.getPropertyValue('--btn-play-fg').trim() || '#ffffff';
    const t = document.createElement('canvas');
    t.width = 128; t.height = 128;
    const g = t.getContext('2d');
    let grad;
    if (scheme === 'rainbow'){
      grad = g.createLinearGradient(0, 0, 128, 128);
      const hues = [0, 60, 120, 180, 240, 300, 360];
      hues.forEach((h, i) => grad.addColorStop(i / (hues.length - 1), `hsl(${h}, 85%, 55%)`));
    } else if (scheme === 'mono'){
      grad = g.createLinearGradient(0, 0, 128, 128);
      grad.addColorStop(0, mono); grad.addColorStop(0.5, mono); grad.addColorStop(1, mono);
    } else {
      grad = g.createLinearGradient(0, 0, 128, 128);
      grad.addColorStop(0, c1); grad.addColorStop(0.5, c2); grad.addColorStop(1, c3);
    }
    g.fillStyle = grad; g.fillRect(0, 0, 128, 128);
    // diagonal light streaks
    g.strokeStyle = 'rgba(255,255,255,0.4)';
    g.lineWidth = 6;
    for (let i = -128; i < 256; i += 28){
      g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 110, 128); g.stroke();
    }
    const tex = new THREE.CanvasTexture(t);
    tex.wrapS = THREE.MirroredRepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;

    const shader = THREE.ShaderLib.lambert;
    const uniforms = THREE.UniformsUtils.merge([shader.uniforms, {
      t: { value: 0 },
      stretch: { value: new THREE.Vector2(1, 10) },
      div: { value: new THREE.Vector2(32, 8) },
      // three.js never refreshes fog uniforms for custom ShaderMaterials
      // (they stay at the defaults 0.00025/white), so set them explicitly:
      // black fog at density 0.08 = the near track stays neon, the far
      // track fades to TRANSPARENT via the custom fog chunk below.
      fogDensity: { value: 0.05 },
      fogColor: { value: new THREE.Color(0x000000) }
    }]);
    const vertexShader = `
    uniform sampler2D map;
    uniform vec2 stretch;
    ` + shader.vertexShader
      // self-contained fog: declare + compute the depth varying ourselves so
      // it works regardless of three's USE_FOG defines
      .replace('#include <fog_pars_vertex>', 'varying float vFogDepth;')
      .replace('#include <fog_vertex>', 'vFogDepth = - mvPosition.z;')
      .replace('#include <uv_vertex>', `
    #ifdef USE_UV
        vUv = ( uvTransform * vec3( uv, 1 ) ).xy * stretch;
    #endif
    `);
    const fragmentShader = `
    uniform vec2 div;
    uniform vec2 stretch;
    uniform float t;
    ` + shader.fragmentShader
      .replace('#include <fog_pars_fragment>', `
    uniform vec3 fogColor;
    uniform float fogDensity;
    varying float vFogDepth;
    `)
      .replace('#include <map_fragment>', `
    #ifdef USE_MAP
        {
            vec2 i = vec2(ivec2( vUv * div ));
            vec4 tA = texture2D( map, ( i ) / div );
            vec4 tB = texture2D( map, ( i + 1.0 ) / div );
            vec4 texel = 0.5 * (mix( tA, tB, vUv.x ) + mix( tA, tB, vUv.y ));
            texel.b = step( 0.5, texel.b ) + ( sin( t * 0.001 ) * 0.5 + 0.5 );
            texel.r *= 2.0;
            texel.g *= 0.5;
            vec2 uv = fract( vUv * stretch * div );
            texel *= step( 0.2, uv.x ) * step ( 0.2, uv.y );
            diffuseColor *= texel;
        }
    #endif
    `)
      // Fade the DISTANT track to TRANSPARENT instead of opaque black:
      // the artwork shows through the far track, so there is no black
      // background — the ride dissolves into the artwork. Near track stays
      // bright neon.
      .replace('#include <fog_fragment>', `
        // UNCONDITIONAL distance fade (three's USE_FOG define is not set for
        // this custom material, so we guard nothing): the far track fades to
        // BLACK. The canvas is blended with mix-blend-mode: screen, so black
        // becomes transparent — the artwork shows through the far track and
        // there is no black background, whatever the bloom strength.
        float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
        gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
    `);
    const mat = new THREE.ShaderMaterial({
      uniforms, vertexShader, fragmentShader,
      lights: true, fog: true
    });
    mat.map = mat.uniforms.map.value = tex;
    return mat;
  }

  sideMat = buildSideMat(scheme);
  const mesh = new THREE.Mesh(ribbonGeom, sideMat);
  scene.add(mesh);

  // ---- composer (bloom) ----
  const composer = new EffectComposer(renderer);
  composer.addPass(new RenderPass(scene, camera));
  composer.addPass(new UnrealBloomPass(new THREE.Vector2(), 2, 0.5, 0.7));

  // ---- animation ----
  const totalLen = extrudePath.getLength();
  // ORIGINAL codepen camera: Frenet binormal up (seam-closed via the
  // frames blend), so the ride banks through the turns exactly like the
  // original pen and wraps seamlessly with no snap.
  const $m = new THREE.Matrix4();
  const lookTarget = new THREE.Vector3();
  let lastU = 0;
  const lastPos = new THREE.Vector3();
  const lastUp = new THREE.Vector3();

  function loop(){
    // Re-layout when the on-screen ZOOM of the visualiser has changed since
    // the last frame. The canvas element is enlarged/reduced by the
    // --viz-scale / --pl-viz-scale CSS transform (editor slider, mouse
    // wheel, double-click reset, track load, cinema toggle). layout() sizes
    // the WebGL drawing buffer to match that transform, so without this the
    // buffer stays at the base resolution and the CSS transform simply
    // stretches it = pixelation. Only runs layout() when the value actually
    // moved, so the steady-state per-frame cost is one cheap style read.
    const sc = effectiveVizScale();
    if (sc !== _vizScaleCached){ layout(); }
    // performance.now() is continuous across activate/deactivate, so the
    // ride never "starts over from the beginning" when the mode is toggled.
    const t = performance.now();
    const $u = ((mpms * t) % totalLen) / totalLen;
    extrudePath.getPointAt($u, camera.position);
    // look-ahead WRAPS around the seam ((u+0.01) % 1) instead of clamping
    // at 1.0 — the old clamp froze the camera's rotation at the end of the
    // loop, then snapped it back = the "video stops and restarts" feel.
    extrudePath.getPointAt(($u + 0.01) % 1, lookTarget);
    // ORIGINAL codepen camera up: the Frenet binormal (with the seam blend
    // baked in) — banks and swoops through the turns exactly like the pen,
    // and meets the start frame at the wrap so there is no snap.
    lastUp.copy(frames.binormals[Math.min(steps - 1, ($u * steps) | 0)]);
    camera.setRotationFromMatrix($m.lookAt(
      camera.position,
      lookTarget,
      lastUp
    ));
    renderer.getDrawingBufferSize(composer.passes[1].resolution);
    composer.render();
    sideMat.uniforms.t.value = t;
    lastU = $u;
    lastPos.copy(camera.position);
  }

  // Current on-screen ZOOM of the visualiser. Main player is cinema-aware
  // (--viz-cinema-scale in cinema, --viz-scale out); the playlist instance
  // reads --pl-viz-scale (no cinema variant). The canvas element is scaled
  // by exactly this value via the CSS transform, so the WebGL drawing
  // buffer must be sized to match it or the CSS transform will stretch the
  // fixed-resolution pixels (pixelation).
  let _vizScaleCached = NaN;
  function effectiveVizScale(){
    if (scaleMode === 'pl'){
      const raw = getComputedStyle(host).getPropertyValue('--pl-viz-scale');
      const s = parseFloat(raw);
      return (isFinite(s) && s > 0) ? s : 1;
    }
    const cinema = host.classList.contains('cinema');
    const raw = getComputedStyle(host).getPropertyValue(
      cinema ? '--viz-cinema-scale' : '--viz-scale'
    );
    const s = parseFloat(raw);
    return (isFinite(s) && s > 0) ? s : 1;
  }

  function layout(){
    const r = host.getBoundingClientRect();
    const scale = effectiveVizScale();
    _vizScaleCached = scale;
    // Base CSS size of the canvas (main player = top half of the disc;
    // playlist = the full disc).
    const W = Math.max(1, Math.round(r.width));
    const H = Math.max(1, Math.round(r.height * heightFraction));
    // Drawing-buffer size is the base size MULTIPLIED by the zoom scale, so
    // after the CSS transform enlarges the element on screen there is still
    // one buffer pixel per displayed pixel — zoom keeps its visual integrity
    // instead of pixelating. Both dimensions scale equally, so the camera's
    // aspect ratio uses the BASE size (W/H) and the framing is unchanged.
    const BW = Math.max(1, Math.round(W * scale));
    const BH = Math.max(1, Math.round(H * scale));
    const pr = Math.min(window.devicePixelRatio || 1, 1.5);
    // setPixelRatio BEFORE setSize (canonical order): setSize bakes pr into
    // the canvas backing-store dimensions.
    renderer.setPixelRatio(pr);
    renderer.setSize(BW, BH, false);
    // Keep the bloom composer's render targets at the SAME pixel ratio as
    // the canvas, so the scene + bloom render at full backing-store
    // resolution instead of being upscaled (soft) onto the larger canvas.
    composer.setPixelRatio(pr);
    composer.setSize(BW, BH);
    camera.aspect = W / H;
    camera.updateProjectionMatrix();
  }

  let running = false;
  function start(){
    if (running) return;
    running = true;
    renderer.setAnimationLoop(loop);
  }
  function stop(){
    if (!running) return;
    running = false;
    renderer.setAnimationLoop(null);
  }

  const inst = { ready, active: false };

  inst.setActive = function(on){
    inst.active = !!on;
    cv.classList.toggle('visible', inst.active);
    fogLayer.classList.toggle('visible', inst.active);
    if (!inst.active){ fogLayer.style.opacity = 0; }
    else { fogLayer.style.opacity = String(fogAmount); }
    if (inst.active){ layout(); start(); }
    else stop();
  };

  // Black-fog background amount (0..1). Drives the backdrop layer opacity
  // AND the track's distance-fog density, so the whole ride fades from
  // artwork-visible to the classic v52 black.
  inst.setFog = function(v){
    fogAmount = Math.max(0, Math.min(1, v));
    if (inst.active) fogLayer.style.opacity = String(fogAmount);
    if (sideMat && sideMat.uniforms && sideMat.uniforms.fogDensity){
      sideMat.uniforms.fogDensity.value = 0.05 * fogAmount;
    }
    if (scene.fog) scene.fog.density = 0.05 * fogAmount;
  };
  inst.resize = layout;

  // Colour scheme: rebuild the sidewall texture/material in place.
  inst.setColors = function(s){
    if (!s) return;
    scheme = s;
    sideMat = buildSideMat(scheme);
    mesh.material = sideMat;
  };

  // Audio-reactive bloom: main script calls this every frame with a level.
  inst.setIntensity = function(v){
    if (composer.passes[1]) composer.passes[1].strength = Math.max(0, v);
  };
  inst.getIntensity = function(){
    return composer.passes[1] ? composer.passes[1].strength : 0;
  };

  // Continuity probes (used by the automated tests): the path really closes
  // (position delta at the seam ~0) and the parallel frames match there.
  const seamA = extrudePath.getPointAt(0);
  const seamB = extrudePath.getPointAt(0.9999);
  inst._dbg = {
    seamPosDelta: seamA.distanceTo(seamB),
    // the ribbon's own frames close (track ends join)
    binClose: frames.binormals[steps - 1].dot(frames.binormals[0]),
    // how far the RAW original Frenet up would snap at the seam (~171°)
    rawFrenetSnap: frames.twist,
    lastU: () => lastU,
    lastPos: () => lastPos.toArray(),
    // camera's current up (the blended Frenet binormal — original feel)
    camUp: () => lastUp.toArray(),
    // deterministic probes: the frame field the camera/ribbon uses
    upAt: (u) => frames.binormals[Math.min(steps - 1, (u * steps) | 0)].toArray(),
    rawFrenetUpAt: (u) => frames.frenet.binormals[Math.min(steps - 1, (u * steps) | 0)].toArray(),
    blendStart: frames.UP_BLEND_START,
    // internals for diagnostics
    renderer, scene, mesh, camera, sideMat, host
  };

  readyResolve(inst);
  return inst;
}

// ---- boot the MAIN player instance (backward compatible global) ----
const _mainHost = document.getElementById('player');
const _main = _mainHost ? _boot(_mainHost, { heightFraction: 0.5, scaleMode: 'viz' }) : null;
if (_main){
  // window.RoundViz3D = the main instance (keeps every existing
  // window.RoundViz3D.setActive/setColors/setFog/setIntensity/resize call
  // working unchanged) + a .create() factory for extra instances.
  _main.create = createInstance;
  window.RoundViz3D = _main;
} else {
  // #player not present (e.g. page without the player): expose a stub with
  // the factory so a future instance can still be created.
  window.RoundViz3D = {
    ready: Promise.resolve(),
    active: false,
    setActive(){}, resize(){}, setColors(){}, setFog(){},
    setIntensity(){}, getIntensity(){ return 0; },
    create: createInstance
  };
}
