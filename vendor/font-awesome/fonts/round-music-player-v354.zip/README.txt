Round Music Player — fresh default build (script.js v354), NO media.

RUN:
  1. Install Node.js (https://nodejs.org) if you don't already have it.
  2. In this folder run:   node server.js
  3. Open in your browser:
       http://localhost:3000/         (launcher / hub)
       http://localhost:3000/dev.html (designer editor)
       http://localhost:3000/index.html (deployed player)

This build boots into the DEFAULT demo playlist (no uploaded media). Uploading
your own audio / cover / video works normally and is stored in uploads/.
