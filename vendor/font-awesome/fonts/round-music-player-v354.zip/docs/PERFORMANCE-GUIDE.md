# ⚡ Performance Guide — Fast-Loading, Smooth Player

> Goal: the deployed album page (14 tracks, mixed video / artwork / visualisers
> in the main player **and** the playlist panel) must **load with no perceptible
> wait and run smoothly**. This is the canonical guide — every new feature is
> built against it. Last updated 2026-08-17.

---

## 1. Performance budget (targets for the live album page)

| Metric | Target | Notes |
|---|---|---|
| First Contentful Paint | **< 1.2 s** on 4G | text + first cover visible |
| Time-to-Interactive (play button works) | **< 2.5 s** on 4G | |
| Initial JS (gzip) — core player | **< 80 KB** | excludes on-demand 3D |
| Initial transfer (gzip, excl. media) | **< 250 KB** | |
| First track audio start after Play click | **< 200 ms** | via preload |
| Visualiser frame rate | **60 fps** (≥30 on weak devices) | |

If a change pushes a number past budget, it doesn't ship — optimise or lazy-load first.

---

## 2. Current load profile (after the 3D lazy-load, Entry S15)

What the deployed `index.html` pulls on first paint (unminified → ~gzip):

| Asset | Raw | ~Gzip | Load |
|---|---|---|---|
| `styles.css` | 54 KB | ~12 KB | eager (head) |
| Font Awesome CSS + webfont | ~100 KB | ~28 KB | eager (icons) |
| `color-thief` | 6 KB | ~2 KB | eager |
| `script.js` | 372 KB | ~55 KB | eager (end of body) |
| **`viz3d.js` + `three.module.js`** | **1.19 MB** | ~300 KB | **✅ LAZY now** — only if coaster picked |

**Initial transfer ≈ 530 KB raw / ~100 KB gzip** (excl. media) — down from ~1.7 MB / ~400 KB gzip before the lazy-load. The 3D coaster's 1.2 MB now only downloads for users who actually select it.

---

## 3. Rules for every new feature (keep it fast)

1. **No new eager large dependencies.** Anything > ~30 KB must be `import()`-ed on demand (the way the coaster is). Vendor libs are editor-only by default — never added to `index.html`, only `dev.html`.
2. **One heavy thing at a time.** Only one GPU/CPU-heavy visualiser runs; idle/paused visualisers cancel their `requestAnimationFrame` (rAF) loop — never leave a rAF spinning for an off-screen effect.
3. **Media: current + next only.** Never preload all 14 tracks. Preload the playing track (`preload="auto"`) and arm the **next** track for gapless/crossfade; everything else is `preload="metadata"` or nothing until needed.
4. **Playlist-panel media is lazy.** Panel cover/video art loads when the panel **opens**, not on page load.
5. **No per-frame allocations in rAF loops.** Reuse typed arrays/objects (the viz/edge loops already do); avoid creating arrays/closures each frame.
6. **Cap the expensive knobs.** Bar/particle counts, DPR cap (1.5×), and shadow/blur usage stay bounded (see viz code).
7. **Measure before & after.** Adding a feature? Check DevTools → Network (transfer size + waterfall) and Performance (jank). A feature that grows initial load or drops frames gets reworked before it ships.
8. **Keep `?v=` cache-busting current** so production long-cache + instant updates coexist.

---

## 4. Production deployment checklist (for the real website)

The dev server (`server.js`) intentionally sends `no-store` so edits show instantly — **that is wrong for production**. Before launch, on your real host/CDN:

- [ ] **Compress:** enable **Brotli** (or gzip) for `.html/.css/.js/.json/.svg`. Text assets shrink ~70–80 % (script.js 372 KB → ~55 KB).
- [ ] **Long-cache static assets:** `Cache-Control: public, max-age=31536000, immutable` for `script.js? v=…`, `styles.css? v=…`, `vendor/**`, `uploads/**`. The `?v=` query already gives safe cache-busting on code changes.
- [ ] **Minify** `script.js` + `styles.css` for production (372 KB → ~150 KB raw before compression). Keep unminified as the source of truth; minify at deploy.
- [ ] **Preload the first track:** `<link rel="preload" as="fetch" href="<track1 audio>">` and `<link rel="preload" as="image" href="<track1 cover>">` so Play + first cover are instant. (Keep `preload="metadata"` on the others.)
- [ ] **Image format:** serve cover art as **WebP/AVIF** (≈30–50 % smaller than JPEG), sized to the player (~600–800 px is plenty — the disc is 415 px).
- [ ] **Replace Font Awesome (~100 KB)** with a handful of **inline SVG icons** (the player uses only ~6: volume, share, list, play, etc.) — saves ~90 KB and removes a render-blocking CSS request. *(Optional but high-value.)*
- [ ] **Video:** keep cover clips short (loop a 5–15 s segment) and, when ready, apply the **transcode-on-upload** (Entry S9, deferred) to cap them at ~720 p / ~1.5 Mbps.
- [ ] **CDN** in front of static + media for low latency.
- [ ] **HTTP/2** (or /3) so the ~6–10 initial requests multiplex.

---

## 5. Video / artwork / visualiser combinations — runtime notes

- **Two rAF loops are fine** when an in-circle visualiser + the edge ring run together; both are cheap 2D canvas (capped bar counts, DPR 1.5). The 3D coaster is the only GPU-heavy one and runs alone.
- **Two `AnalyserNode`s** (inner + edge, for independent smoothing) — negligible cost; `getByteFrequencyData` is cheap.
- **Video as a silent visual** (MP3 master + muted cover video): the `<video>` decodes frames on the GPU; keep clips short and avoid > 1080 p source.
- **Cinema mode** simply toggles a class (no extra rendering); it never adds load.
- **rAF auto-pauses** in background tabs (browser behaviour), so off-tab visualisers cost nothing.

---

## 6. What's already optimised (don't regress)

- 3D coaster + three.js **lazy-loaded** (Entry S15) — biggest single win.
- Editor-only libs (`pickr`, `bpm-detect`) are **not** loaded by the deployed `index.html`.
- `script.js` sits at the **end of `<body>`** (non-render-blocking).
- Per-track media; gapless engine preloads **only the next** track.
- Visualiser loops reuse buffers; DPR is capped; canvases are sized to the media window only.
- Upload **dedup** (Entry S14) keeps storage (and therefore served bytes) lean.

---

## 7. Quick "is this feature fast?" gate (before merge)

1. Does it add **eager** bytes to `index.html`? → If > 1 KB, justify or lazy-load.
2. Does it add a **rAF loop**? → Does it stop when idle/hidden?
3. Does it **preload media** beyond current+next? → Remove.
4. Does it allocate **per-frame**? → Hoist outside the loop.
5. Network panel: did **initial transfer (gzip)** grow? → Keep under budget.
