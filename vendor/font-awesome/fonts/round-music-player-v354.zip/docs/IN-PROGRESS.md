# IN PROGRESS — Playlist Visualiser Parity (Coaster + Edge)

> ✅ **COMPLETE (Entry S21, v207).** Coaster-on-playlist + Edge-modes-on-playlist built, verified via functional three.js mock (27/27) + dev.html jsdom smoke test (8/8, 0 errors). Release zip `round-music-player-v207.zip` built. See `docs/PROJECT-CONTEXT.md` Entry S21.
>
> Task: Build the two remaining items from `docs/pl-viz-parity-plan.md`:
> **Coaster-on-playlist** (Step 3) + **Edge-modes-on-playlist** (Step 5).
> Created: 2026-08-20

## Plan

### A. viz3d.js — multi-instance refactor (Step 3, HIGH RISK)
- `_boot(host, opts)` instead of `_boot()` (hardcoded `#player`).
- opts: `heightFraction` (0.5 main / 1.0 playlist), `scaleMode` ('viz' cinema-aware / 'pl' reads `--pl-viz-scale`), `canvasClass`, `fogClass`, `colorHost` (read theme vars from `#player` always).
- `_boot` returns an instance object `{ ready, active, setActive, resize, setColors, setFog, setIntensity, getIntensity, _dbg }`.
- `createInstance(hostOrId, opts)` factory.
- Main instance boots on `#player` and is assigned to `window.RoundViz3D` (BACKWARD COMPAT — all existing `window.RoundViz3D.setX` calls keep working) + `.create` added.

### B. CSS (styles.css v198)
- `.playlist-circle > .pl-viz-canvas-3d` — full-circle, framed by `--pl-viz-*`, `mix-blend-mode: screen`.
- `.playlist-circle > .pl-viz-fog-layer` — black fog layer for PL coaster (default opacity 0).
- `.pl-edge` — sibling of `.playlist-circle` in `.player-pair`, glides RIGHT (`translateX(--open * --pair-gap)`), z-index 4 (behind playlist disc z-5), `opacity: var(--open)`.

### C. script.js (v207)
1. `viz` defaults + `VIZ_DEFAULTS`: add `plEdgeMode/plEdgeReach/plEdgeSensitivity/plEdgeSmoothing/plEdgeOpacity/plEdgeBars/plEdgeColors/plEdgeCustomColors`.
2. Module state: `plCoasterInst`, `plCoasterRAF`, `elPlEdge`, `plEdgeRAF`, `plEdgeFreq`, `plEdgeAnalyser`, PL ripple/particle/bass state.
3. `plEdgeAnalyser` created in `ensureVizGraph` (next to `edgeAnalyser`).
4. `startPlCoaster()/stopPlCoaster()/plCoasterTick()` — lazy-load viz3d, `create('playlistCircle', {...})`, feed bloom intensity.
5. `applyPlViz()` — handle `plMode==='coaster'` (start PL coaster, hide 2D/milkdrop).
6. `ensurePlEdgeCanvas()/sizePlEdgeCanvas()/plEdgeTick()/applyPlEdgeViz()` — reuse 8 edge draw funcs via settings swap (incl. ripple/particle state isolation).
7. `applyTrackViz()` — call `applyPlEdgeViz()`.
8. Resize handler — resize PL coaster + PL edge.
9. `vizSyncUI()` + `attachVisualizerUI()` — PL mode dropdown now has coaster; new PL edge controls.
10. Persist new fields in `saveCurrentAsTrackViz()` + `vizTrackOn` save + applyTrackViz merge.

### D. dev.html — editor UI
- `vizPlMode` add `<option value="coaster">Coaster (3D)</option>`.
- New "Playlist edge mode" section: `vizPlEdgeMode` select + `vizPlEdgeSettings` (reach/sensitivity/smoothing/opacity/bars/colours/custom).

### E. Version bumps + release zip
- `script.js?v=207`, `styles.css?v=198`, `viz3d.js?v=140`.
- `bash make-release-zip.sh` → `round-music-player-v207.zip`.

## Test checklist
- [x] (automated) Main + PL coaster independent instances boot on correct hosts — viz3d.js mock test 27/27.
- [x] (automated) PL edge canvas created/hidden on mode toggle; settings/custom-row visibility; coaster option present; no-throw — dev.html jsdom 8/8, 0 errors.
- [x] Server serves v207/v198 after restart (curl-verified); node --check OK on script.js + viz3d.js.
- [x] Release zip `round-music-player-v207.zip` built (1.2 MB) and contains new code.
- [ ] (user, browser) Main coaster regression — pick Coaster on main player.
- [ ] (user, browser) PL coaster: pick Playlist visualiser → Coaster → see ride in playlist disc.
- [ ] (user, browser) PL coaster + main 2D viz run simultaneously (independent).
- [ ] (user, browser) PL coaster lazy-loads (no three.js on initial load).
- [ ] (user, browser) PL edge: pick PL edge mode → rim pulses around playlist disc, glides right.
- [ ] (user, browser) PL edge + main edge both on (independent settings).
- [ ] (user, browser) Per-track save persists PL coaster/edge.

## RESULT — COMPLETE (v207)
Built both remaining parity items. Playlist panel now matches the main player's full visualiser suite:
2D modes + **Coaster (3D)** + Milkdrop + **Edge/Rim (8 modes)**, all independent, all per-track.
Not browser-verified in-sandbox (no headless WebGL); validated via functional three.js mock + jsdom.
