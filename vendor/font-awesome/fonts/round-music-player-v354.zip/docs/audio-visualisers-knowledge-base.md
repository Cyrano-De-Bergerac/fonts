# Audio Visualisers — Knowledge Base & Implementation Guide
### For the Round Music Player ("the ultimate deployable web music player")

Compiled: 2026-08-07 · Sources: web research — full source list at the bottom.

---

## 1. The iTunes question (and the nostalgia market)

**Is the iTunes classic visualiser still around?** Partly.

- iTunes shipped **two** visualisers: the newer "iTunes Visualizer" (no options) and the beloved **"iTunes Classic Visualizer"** (user-selectable options: Starfield style, waveform line, plasma-ish colour fields). The classic one was the one people remember.
- Apple retired iTunes in 2019 (last version 12.9.3.3), but the visualiser **survived into the macOS Music app**: `Window > Visualizer`, with options under `Window > Visualizer Settings` (reported working in the Music app as of ~2023; some users report it "broken" on newer macOS versions — it's flaky).
- The visualiser people *really* remember (the 3D starfield/wormhole with audio-reactive pulses, ~iTunes 8–11 era) has **no official successor** — hence the constant demand for recreations. The open-source **projectM** (Milkdrop-compatible, cross-platform, with a WebGL port — **butterchurn** — that runs in the browser) is the community's answer, and people still point to it today ("back in the day I was really obsessed with music visualisers… why is nobody making these anymore?").

**The takeaway:** nostalgia is a real, proven desire — a "classic starfield" mode in the Round Player is a crowd-pleaser, and it's cheap to implement (2D canvas pseudo-3D starfield, no WebGL needed).

---

## 2. The anatomy of audio visualisation

Every visualiser is a **mapping from audio data → pixels**. The data comes from one place — the **Web Audio API `AnalyserNode`** (a real-time FFT) — in three flavours:

| Data source | Method | What it represents | Used for |
|---|---|---|---|
| Frequency spectrum | `getByteFrequencyData()` (0–255) or `getFloatFrequencyData()` (dB) | Energy per frequency bin (FFT) | Bars, radial, plasma intensity |
| Time-domain waveform | `getByteTimeDomainData()` / `getFloatTimeDomainData()` | Raw sample values (0–255, 128 = silence) | Oscilloscope, waveform line |
| Beat / onset (derived) | Compute from spectrum (bass energy spikes) | Rhythm events | Pulse/scale effects, beat-synced triggers |

**Key parameters:**
- `analyser.fftSize` — 256 → 2048+; **frequencyBinCount = fftSize / 2** (number of data points). Bigger = finer resolution but slower + emptier high bins. **256 is the classic bar-graph sweet spot; 512–1024 for smooth radial/3D; 2048 for waveform detail.**
- `smoothingTimeConstant` (0–0.95) — the famous "make the bars stop shaking" knob; 0.8 ≈ classic smoothness, 0 = raw/jittery.
- `minDecibels` / `maxDecibels` (−90 / −10 defaults) — dynamic range window; tuning these fixes "bars barely move".
- `requestAnimationFrame` loop — read data, draw, repeat at 60fps. **Never** use setInterval for rendering.

**The three universal gotchas (from real developer pain):**
1. **`createMediaElementSource()` can only be called ONCE per media element** — calling it again throws. Guard with a flag.
2. **Safari/iOS returns flat zeros (or 128s) from `getByteFrequencyData` for cross-origin/streaming media** — the analyser needs CORS-clean audio. Local files (blob), same-origin files, and proxied streams work; a CDN MP3 without CORS headers may not. **Fix: route through a same-origin proxy** (our server already streams `/uploads/…` with Range support — extend it to proxy external URLs).
3. **Autoplay policy**: `AudioContext` starts suspended until a user gesture — call `ctx.resume()` on first play click.

---

## 3. Taxonomy: every visualiser type that exists

Ranked roughly by popularity, with implementation difficulty for a canvas-based web player:

| # | Type | Description | Difficulty | Round-player fit |
|---|---|---|---|---|
| 1 | **Frequency bars** (spectrum analyser) | Classic vertical bars, one per frequency bin | ★ | ★★★ classic |
| 2 | **Circular / radial spectrum** | Bars radiating from a centre ring | ★★ | ★★★★★ (it's a *round* player — the crowd-pleaser: "makes people stop scrolling on TikTok") |
| 3 | **Waveform / oscilloscope** | Time-domain line across the screen | ★ | ★★★★ minimal + elegant |
| 4 | **Mirrored bars** | Bars mirrored top & bottom (or left & right) | ★ | ★★★ |
| 5 | **Particle field** | Audio-reactive particles (bass scatters them) | ★★ | ★★★★ organic |
| 6 | **Plasma** | Classic sin-wave colour fields (PlasmaVis/WMP heritage), intensity reacts to volume | ★★ | ★★★★ nostalgic |
| 7 | **Starfield** | Pseudo-3D stars flying past; speed/brightness react to bass | ★★ | ★★★★★ — **the iTunes-classic homage** |
| 8 | **Spectrum ribbon** | Smooth gradient band flowing across | ★★ | ★★★ |
| 9 | **Ring of fire / glow rings** | Pulsing glowing circles around artwork | ★★ | ★★★★★ (around the artwork = Spotify vibe) |
| 10 | **Beat-reactive artwork** | Album art pulses/scales with bass | ★ | ★★★★★ cheap + popular |
| 11 | **Kaleidoscope** | Mirrored/rotated patterns (SoundSpectrum heritage) | ★★★ | ★★★ |
| 12 | **3D mesh terrain** | WebGL mesh deformed by frequency (SoundTools "Terrain") | ★★★★ | ★★ (needs WebGL; 2D fallback required) |
| 13 | **Galaxy / particle cloud 3D** | WebGL rotating star cloud | ★★★★ | ★★★ |
| 14 | **Spectrogram waterfall** | Frequency × time scrolling surface | ★★★ | ★★ (more analytical than decorative) |
| 15 | **Milkdrop / projectM shaders** | Equation-driven shader presets; the gold standard (Winamp) | ★★★★★ | ★★ (via butterchurn.js WebGL port — heavy, later phase) |
| 16 | **Lyrical visualisers** | Lyrics as the visual (karaoke-adjacent) | ★★★ | ties to our future lyrics panel |
| 17 | **Beat-triggered / rhythmic** | Onset detection syncs animation events to drums/downbeats | ★★★ | ★★★ (add as enhancement layer) |

---

## 4. What people like, dislike & wish for

**What people LOVE (the formula for a beloved visualiser):**
- **Reactivity that reads the music** — bass kicks, snare snaps; "visuals that react to your music" is the #1 compliment. Beat detection on bass bins sells it.
- **Beauty / "moments of beauty"** — Milkdrop-era users: "there's really nothing better to sit and watch music"; abstract generative art > literal bars for many.
- **Customisation** — sensitivity, smoothing, colour palettes, FFT detail, presets (every beloved viz — Milkdrop, G-Force, SoundSpectrum — is preset-driven).
- **60fps smoothness** + optional subtlety ("keep it smooth and subtle" for streaming aesthetics).
- **Nostalgia modes** — starfield, plasma, Milkdrop-style psychedelia; people actively hunt for recreations.

**What people DISLIKE / what fails:**
- **Bars that barely move** (wrong FFT size / smoothing / min/max dB) — the most common complaint in every FAQ.
- **Too distracting at default** — visualiser interfering with other UI (a VoiceZam complaint: the visualizer "may interfere with links… non-clickable"); needs low-opacity/subtle default and `pointer-events: none`.
- **Flat/unresponsive colour** — no palette options.
- **Performance hogging** — WebGL on weak phones, huge FFT on slow CPUs; need 2D fallback + adjustable FFT.
- **Silent failure** — no visualisation when there should be (CORS zeros) with no explanation.

**What people WISH for:**
- "Why is nobody making these anymore?" — modern players dropped visualisers; people want them back (huge opportunity for a deployable web player).
- **Preset/theme sharing** (Milkdrop's .milk ecosystem) — export/import looks.
- **Per-genre presets** (Winamp tailored visuals by genre).
- **Fullscreen mode** for listening sessions/parties.
- **Beat-synced events** (visuals keyed to rhythm, not just loudness).
- **Snapshot/export** the visual as an image.
- Simple controls — old-school visualisers required "archaic custom scripting"; people want **pick-and-play** (a dropdown + a few sliders).

---

## 5. The best players' visualiser suites (benchmarks)

| Player | Visualiser | Notes |
|---|---|---|
| **Winamp** | AVS + **Milkdrop 2** | The legend; equation/shader-driven; thousands of presets; still the reference |
| **projectM / butterchurn** | Milkdrop-compatible | Open-source; **butterchurn is a WebGL port that runs in the browser** — the practical path to "real" Milkdrop on the web (heavy: ~1MB+ JS, WebGL required) |
| **iTunes / Apple Music** | iTunes Visualizer + **Classic** (starfield/plasma) | The nostalgia reference; classic had options, newer didn't |
| **VLC** | Goom, libprojectM, 3D OpenGL spectrum | Free, built-in, custom visualizer plugins |
| **SoundSpectrum** | G-Force, Aeon, WhiteCap | Deep customisation, 3D, "above Milkdrop" per fans |
| **SoundTools / Specterr / LyricMV** | 14 styles (5 universal + 9 WebGL) | The modern web benchmark: Classic Bars, Mirrored Bars, Circular Spectrum, Waveform, Ring of Fire universal; Terrain/Galaxy/Starfield/Particles WebGL |
| **Spotify Canvas / video visualisers** | Animated artwork | Beat-reactive art is now the mainstream "safe" choice |

**Pattern:** every beloved suite = **a set of pick-and-play modes + sensitivity/smoothing/colour controls + (optionally) preset sharing**. Exactly the model for the Round Player.

---

## 6. Recommended architecture for the Round Player

### 6.1 The audio graph (one-time setup, shared with future EQ/crossfade)
```
<audio> ──createMediaElementSource (ONCE)──┐
<video> ──createMediaElementSource (ONCE)──┤
                                           ▼
                                     analyser (fftSize 512, smoothing 0.82)
                                           │
                                           ▼
                                     ctx.destination
```
- Create the `AudioContext` **lazily on first user gesture** (play click) + `resume()`.
- Guard both `createMediaElementSource` calls with flags (one-call rule).
- Both audio AND video elements feed the analyser so the visualiser works whether the master is MP3 or video-audio.

### 6.2 The render layer
- A single `<canvas id="vizCanvas">` absolutely positioned over the whole player circle, `z-index` **above the artwork but below the controls**, `pointer-events: none`, `display: none` when off.
- Size = player rect × `devicePixelRatio`, resized on window resize.
- One `requestAnimationFrame` loop; draw per mode; **read CSS theme vars** (`--progress-start/mid/end`, `--btn-play-fg`, …) so every visualiser is automatically themed.

### 6.3 Modes (phase 1 — 2D canvas only, all cheap)
1. **Frequency Bars** (classic, bottom-anchored, gradient) — ★
2. **Radial Spectrum** (bars around a ring — signature round-player mode) — ★★
3. **Waveform** (oscilloscope line) — ★
4. **Starfield** (iTunes-classic homage: pseudo-3D stars, bass-reactive speed) — ★★
5. **Plasma** (classic sin-wave colour fields, volume-reactive) — ★★

Phase 2: mirrored bars, ring-of-fire, beat-reactive artwork, particles, spectrum ribbon.
Phase 3 (heavy): WebGL galaxy/terrain, butterchurn Milkdrop, snapshot export, preset share.

### 6.4 Controls (the Visualisers tab in the Editor Box)
- **Mode** dropdown (Off + the modes above)
- **Sensitivity** (20–300%), **Smoothing** (0–0.95), **Opacity** (10–100%)
- **Bar count** (8–96), **FFT size** (256/512/1024 — advanced)
- **Colour scheme**: Theme gradient / Rainbow / Mono
- **Show artwork behind** toggle
- Live preview (applies instantly to the player behind the editor), persisted to localStorage **and shipped to the deployed player via the theme save** (server), so the deployed page inherits the chosen visualiser.

### 6.5 Persistence
- localStorage `roundPlayer.visualizer.v1` for the editor session.
- `getThemeData()` gains a `viz` object → saved to the server with the theme → bootstrapped onto the deployed page (`window.__serverViz`), so the deployed player shows the exact visualiser + settings chosen in the editor.

### 6.6 The CORS/proxy note
- Local uploads (blob + `/uploads/…`) and same-origin files: analyser works fully.
- External demo URLs without CORS headers may return flat data in some browsers → future task: same-origin audio proxy (reuse the Range-capable server) + a graceful "visualiser needs a local/proxied source" note.

---

## 7. Performance & quality checklist
- `canvas.getContext('2d')` once; reuse typed arrays; avoid per-frame allocations.
- Skip the top ~40% of frequency bins when drawing bars (most music energy lives low; empty high bars look broken).
- Plasma at low internal resolution (e.g. 52×52) then `drawImage` upscaled — classic trick, smooth 60fps.
- Stop the rAF loop when the mode is Off or the player is hidden; keep it running (cheap) while playing.
- Respect `prefers-reduced-motion`: show a static idle frame instead of animating.

---

## Sources
- iTunes visualiser history/status: Apple Support Communities (Visualizer Classic problems; Apple Music visualization broken — Window > Visualizer, Visualizer Settings); r/VintageApple (iTunes visualizer, ⌘T)
- Nostalgia & demand: r/electronicmusic "What happened to music visualisers?" (Milkdrop/G-Force nostalgia, butterchurnviz.com, projectM); r/appletv "old school music visualization app like Milkdrop"; superuser.com alternatives to Winamp visualizations (Geiss, PlasmaVis, SoundSpectrum G-Force/Aeon/WhiteCap, VSXu, projectM)
- projectM: github.com/projectM-visualizer/projectm (Milkdrop-compatible, presets, beat detection, OpenGL)
- BeatDrop: github.com/OfficialIncubo/BeatDrop-Music-Visualizer (Milkdrop2 standalone, beat detection, shader FFT/wave variables)
- Types/styles: themusicuniverse.com (waveform, spectrum bars, circular reactors, particles/glitch — genre matching); gurusoftware.com (multi-band analysis, rhythmic triggers, lyrical, 3D mesh, particles); soundtools.io (14 styles: Classic Bars, Mirrored Bars, Circular Spectrum, Waveform, Ring of Fire + WebGL Terrain/Galaxy/Starfield/Particles/Glow Pills/Clouds/Lava Lamp/Jellyfish); frequencydetector.com (3D WebGL: spectrogram waterfall, particle field, spectrum sphere; FFT/smoothing FAQ)
- Implementation: MDN/W3Cub "Visualizations with Web Audio API" (fftSize, frequencyBinCount, getByteFrequencyData/getByteTimeDomainData, bar-width trick); 24ways "Feeding the Audio Graph" (analyser loop pattern); stackoverflow (Safari analyser zeros for streams; getByteFrequencyData zero at high freqs → use getFloatFrequencyData or trim bins; createMediaElementSource scope/once rule; min/max decibels tuning)
- Likes/dislikes/wishes: r/electronicmusic thread; themusicuniverse genre guidance ("smooth and subtle" for Spotify Canvas); VoiceZam/visualizer link-interference lesson (nathanpuls medium review); frequencydetector FAQ ("visuals barely move — what's wrong?" → FFT size, smoothing, sensitivity)
