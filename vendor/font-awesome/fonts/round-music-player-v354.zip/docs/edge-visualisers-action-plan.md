# 🌀 Edge / Circumference Visualisers — Research & Action Plan

> Goal: add visualisers that live on the **outer edge / circumference** of the
> circular player — the "pulse around the ring" look popularised by **Vizzy.io**'s
> *Circle* mode — alongside the existing in-circle visualisers.
>
> **Status:** ✅ **IMPLEMENTED (Phases E1 + E2).** 8 edge modes are live: Outer
> Bars, Mirror Bars, Bass Ring, Beat Ripples, Polar Waveform, Concentric Rings,
> Particle Orbit, Stacked Blocks. Adaptive edge-reach slider, per-track
> persistence, layers with the in-circle visualiser, stays visible in cinema.
> (Originally: research → proposed plan, awaiting decisions.)
> **Created:** 2026-08-17 · **Implemented:** 2026-08-17 (script.js v185)

---

## 1. TL;DR

- Vizzy's signature effect is **frequency bars radiating outward from a circle's
  rim** (its *Circle* mode; rivals call the same idea *Circular Spectrum* /
  *Ring of Fire*) [[R1](https://banger.show/compare/vizzy)] [[R9](https://soundtools.io/music-visualizer/)].
- The technique is well-understood: map FFT bins to angles around a circle and
  draw a line/shape from radius `R` to `R ± amplitude` using `cos/sin` [[R6](https://effect-labs.com/en/pages/blog/audio-visualizer-js.html)] [[R4](https://codepen.io/wrtchd/pen/aOGJEr)].
- **The one structural catch in our player:** `.music-player` has
  `overflow: hidden` (it's a clipped disc), so anything that pulses *outward*
  beyond the rim gets cropped. **Fix = add a new un-clipped "edge" canvas layer
  as a sibling of the player** (inside `.player-pair`), not inside it. Inward /
  rim-hugging effects can reuse the existing clipped canvas.
- This reuses our **already-wired** AnalyserNode graph, palette system
  (theme/rainbow/mono/custom), per-track persistence, and beat engine — it's an
  *additive* feature, not a rewrite.
- Recommended first wave (Phase E1): **Outer Bars**, **Mirror Bars**,
  **Bass Ring**, **Beat Ripples**. All four are cheap, high-impact, and cover the
  range from "Vizzy clone" to "elegant".

---

## 2. What Vizzy & the ecosystem actually do (research)

| Platform | Circle / edge modes of note | Key traits |
|---|---|---|
| **Vizzy.io** | *Circle* (their headline circular visual) | Bars/shape around the rim; reactive; templates; live preview [[R1](https://banger.show/compare/vizzy)] [[R4b](https://vibesdrop.com/music-visualizer-for-youtube/)] |
| **SoundTools** | *Circular Spectrum*, *Ring of Fire* | Spikes radiate outward; centre pulses with bass; rotating hue; ring glows with bass energy [[R9](https://soundtools.io/music-visualizer/)] |
| **Banger.show** | *Pulsar*, *Circle*, *Spherical Field* | Audio-reactive shaders, 3D models, layered [[R1](https://banger.show/compare/vizzy)] |
| **dmeldrum6 (ref impl)** | *Radial* + *Frequency Rings* + *Lissajous scope* | **Mirror symmetry**, slow rotation, **inner radius pulses on each beat**, ring ripples, layer compositor, BPM-lock [[R8](https://github.com/dmeldrum6/Web-Audio-Visualizer)] |
| **IUSV (ref impl)** | Ring + glow + bass pulse, stacked blocks, ribbon wave, edge fade, bloom pass | Full production pipeline: ring stroke scaled by bass, edge-fade mask, bloom [[R7](https://github.com/IUSmusic/IUSV)] |
| **nelsonr (ref codepen)** | *Audio Ring* | Two concentric polygons (stereo L/R) whose vertices move with audio, joined by spokes → a living ring shape [[R3](https://codepen.io/nelsonr/embed/WamzJb)] |
| **basicfreetools** | Circular Waveform, Radial Bars (mirrored), Particle Storm, Spiral Galaxy, Kaleidoscope | Concentric rings + orbiting dots + pulsing core; mandala symmetry; beat flash [[R10](https://basicfreetools.com/music-visualizer/)] |
| **everyfreetool** | Circular Spectrum, Galaxy Spiral | Inner ring glows on overall volume; spiral arms wind with frequency [[R11](https://everyfreetool.com/video-tools/music-visualizer)] |
| **kelvinau lib** | circular-audio-wave | ECharts-based circular wave, BPM-aware [[R12](https://github.com/kelvinau/circular-audio-wave)] |

**Common building blocks across all of them:**
1. FFT `getByteFrequencyData()` (or time-domain `getByteTimeDomainData()`) from a Web Audio `AnalyserNode`.
2. Bin → angle mapping: `θ = i / N · 2π`.
3. Polar → cartesian: `x = cx + cos(θ)·r`, `y = cy + sin(θ)·r`.
4. A reactive radius: `r = R ± amplitude·sensitivity`.
5. Bass/energy band extracted (low bins averaged) to drive a **pulse** of the whole ring or inner radius.
6. Beat detection → emit **ripples / flashes / particle bursts**.
7. Glow via `shadowBlur` or a bloom composite; smoothing via `analyser.smoothingTimeConstant` + trail decay.

We already have **1, 4, 5, 6, 7** in the player (AnalyserNode graph, sensitivity/smoothing/FFT, palette, beat engine, bloom in the 3D path). So the work is mostly **#2/#3 drawing + the new layer + the editor wiring**.

---

## 3. The variation catalogue (what "around the edge" can mean)

Twelve distinct styles, grouped by feel. *Direction:* ↗ outward, ↙ inward, ⇅ both.
*Data:* F = frequency bins, T = time-domain waveform, E = energy/bass band, B = beat events.

| # | Style | What it looks like | Dir | Data | Complexity | Notes / refs |
|---|---|---|---|---|---|---|
| E-1 | **Outer Radial Bars** | Spikes radiating outward from the rim (the Vizzy look) | ↗ | F | Low | The headline mode [[R6](https://effect-labs.com/en/pages/blog/audio-visualizer-js.html)] |
| E-2 | **Mirror / Dual Bars** | Bars grow **both** inward + outward from the rim (symmetric) | ⇅ | F | Low | "Mirrored" toggle everywhere [[R8](https://github.com/dmeldrum6/Web-Audio-Visualizer)] |
| E-3 | **Bass Ring (pulsing stroke)** | A clean glowing ring whose radius/width pulses with bass/energy | rim | E | Low | Elegant, minimal [[R7](https://github.com/IUSmusic/IUSV)] |
| E-4 | **Beat Ripple Rings** | Concentric rings emitted on each beat, expanding + fading outward | ↗ | B | Low | "Sonar" effect [[R8](https://github.com/dmeldrum6/Web-Audio-Visualizer)] |
| E-5 | **Polar Waveform (blob ring)** | A closed waveform loop: radius modulated by waveform/spectrum → a living blob | rim | T/F | Med | Stereo L/R → two concentric rings [[R3](https://codepen.io/nelsonr/embed/WamzJb)] |
| E-6 | **Concentric Frequency Rings** | Several rings, each driven by a band (bass/mid/treble), rotating at different speeds | rim | F | Med | "Circular Waveform" core [[R10](https://basicfreetools.com/music-visualizer/)] |
| E-7 | **Particle Orbit** | Particles travel the circumference; size/brightness/speed reactive; bass bursts eject them radially | ↗ | E/F/B | Med | "Particle Storm" on a ring [[R10](https://basicfreetools.com/music-visualizer)] |
| E-8 | **Stacked Blocks** | Square tiles stacked radially around the rim, height = amplitude | ↗ | F | Med | [[R7](https://github.com/IUSmusic/IUSV)] |
| E-9 | **Ribbon / Filled Polar Wave** | A smooth Bezier-filled shape around the circle with edge-fade | ⇅ | F | Med-High | "Ribbon wave" [[R7](https://github.com/IUSmusic/IUSV)] (also satisfies checklist VIZ-04) |
| E-10 | **Spiral / Galaxy Arms** | Frequency-driven spiral arms winding around the centre | ↗ | F | Med-High | [[R10](https://basicfreetools.com/music-visualizer/)] [[R11](https://everyfreetool.com/video-tools/music-visualizer)] |
| E-11 | **Kaleidoscope / Mandala** | Symmetric repeated wedges for a mandala effect | rim | F | Med | [[R10](https://basicfreetools.com/music-visualizer)] |
| E-12 | **Scope Ring (Lissajous polar)** | Oscilloscope plotted in polar coords | rim | T | Med | "Scope" [[R8](https://github.com/dmeldrum6/Web-Audio-Visualizer)] |

All twelve reuse the same polar-math core; they differ mainly in the **draw call** and the **data source**. That means once the edge layer + one bar mode exist, the rest are incremental.

---

## 4. How it fits THIS player (architecture)

### 4.1 The make-or-break detail: `overflow: hidden`
`.music-player` is a clipped disc:
```css
.music-player { border-radius: 50%; overflow: hidden; ... }
```
The current `#vizCanvas` lives **inside** it and only paints the **top-half media window**. So:
- **Inward / rim-hugging** effects (E-2 inward, E-3, E-5, E-6, E-11) can draw inside the clip — fine.
- **Outward** effects (E-1, E-4, E-7 outward, E-8) would be **cropped at the rim**. ❌

### 4.2 Proposed: a new un-clipped **edge layer**
Add a canvas as a **sibling** of `.music-player` inside `.player-pair` (not a child of the player), so it is *not* clipped:

```html
<div class="player-pair" id="playerPair">
  <canvas id="vizEdgeCanvas" class="viz-edge" aria-hidden="true"></canvas>  <!-- NEW: un-clipped, wraps the disc -->
  <div class="music-player" id="player"> …existing… </div>
  <div class="playlist-circle" …></div>
</div>
```
```css
.player-pair { /* already position:absolute centred; allow children to overflow */ }
.viz-edge {
  position: absolute;
  /* bigger than the disc so outward bars have room; centred on the player */
  width:  calc(var(--player-diam) * 1.5);
  height: calc(var(--player-diam) * 1.5);
  left: 50%; top: 50%;
  transform: translate(-50%, -50%);
  pointer-events: none;
  z-index: 6;                 /* above artwork, below menus; tune vs .dash */
  display: none;
}
.viz-edge.visible { display: block; }
```
- The canvas's centre = player centre; player radius `R = player-diam/2` (≈207.5px).
- Outward bars draw from `R` → `R + h`; inward from `R` → `R − h`; both stay inside the 1.5× box.
- **DPR/scale-aware sizing** (apply the same lesson learned on the 3D visualiser): size the backing store to `cssSize × DPR`, and re-size on zoom/resolution changes.
- Pointer events off → never blocks the drag/scrub/cinema interactions.

### 4.3 Reuse — we already have the hard parts
| Existing asset | Reused for |
|---|---|
| `ensureVizGraph()` — AnalyserNode + `getByteFrequencyData`/`getByteTimeDomainData` | Data source for all edge modes |
| `vizPalette()` / `vizColor()` — theme/rainbow/mono/custom | Colours for edge modes (no new palette work) |
| `viz.sensitivity / smoothing / fftSize / opacity` | Same controls drive edge modes |
| Beat engine (Phase 2) + `beatPulseLoop()` | E-4 ripples, E-3 bass pulse, E-7 bursts |
| `saveCurrentAsTrackViz()` / per-track viz persistence | Edge mode + settings save per track |
| Mode `<select id="vizMode">` in the Visualisers tab | New edge modes appear here (or a sub-group) |

### 4.4 New code (the actual work)
- One new draw dispatcher: `vizEdgeTick()` (sibling of `vizTick()`), reading the same analyser.
- Per-mode draw functions: `drawEdgeBars()`, `drawEdgeMirror()`, `drawBassRing()`, `drawBeatRipples()`, …
- `sizeVizEdgeCanvas()` (DPR-aware).
- CSS for `.viz-edge` + cinema visibility rules.
- Editor: edge-mode options + an "Edge length / reach" slider (how far outward) + direction toggle.

---

## 5. Recommended roadmap (prioritised)

| Phase | Modes | Why |
|---|---|---|
| **E1 — Foundation + quick wins** | **E-1 Outer Bars**, **E-2 Mirror**, **E-3 Bass Ring**, **E-4 Beat Ripples** | Delivers the Vizzy look + an elegant alternative; all low-complexity; proves the edge layer. |
| **E2 — Expressive set** | **E-5 Polar Waveform**, **E-6 Concentric Rings**, **E-7 Particle Orbit**, **E-8 Stacked Blocks** | Adds organic + energetic variety; mid-complexity; great demo material. |
| **E3 — Wow factor** | **E-9 Ribbon/Filled**, **E-10 Spiral/Galaxy**, **E-11 Kaleidoscope**, **E-12 Scope Ring** | Showpieces; higher complexity; E-9 also closes checklist item **VIZ-04 (ribbon)**. |

E1 alone gives you the feature you asked for. E2/E3 are "nice to have" differentiators.

---

## 6. Implementation plan — Phase E1 in detail

**Step 1 — Edge layer + sizing (HTML/CSS/JS).** Add `#vizEdgeCanvas`; CSS as in §4.2; `sizeVizEdgeCanvas()` DPR-aware and called on resize + on activate. Centre math uses player `getBoundingClientRect()`.

**Step 2 — Wire into the viz graph.** In `applyViz()` / `vizTick()`, when an edge mode is selected, show `.viz-edge.visible`, start `vizEdgeTick()` (it reads the same `vizFreq`/`vizWave` buffers; no second analyser). Hide `#vizCanvas`/3D when an edge-only mode is active (or allow layering later).

**Step 3 — E-1 Outer Bars (the Vizzy clone).** Core draw:
```js
function drawEdgeBars(ctx, cx, cy, R, data, pal){
  const n = viz.bars || 96;                 // 96 spikes reads great on a ring
  const reach = viz.edgeReach || 60;        // px outward
  for (let i = 0; i < n; i++){
    const bi = Math.min(data.length-1, Math.floor(i/n * data.length*0.6));
    const v = data[bi]/255 * viz.sensitivity/100;
    const a = i/n * Math.PI*2 - Math.PI/2;  // start at top, go clockwise
    const r1 = R, r2 = R + v*reach;
    ctx.strokeStyle = vizColor(pal,'t', i/n, i, n);
    ctx.lineWidth = Math.max(1.5, (2*Math.PI*R)/n * 0.5);
    ctx.beginPath();
    ctx.moveTo(cx+Math.cos(a)*r1, cy+Math.sin(a)*r1);
    ctx.lineTo(cx+Math.cos(a)*r2, cy+Math.sin(a)*r2);
    ctx.stroke();
  }
}
```
*(Adds `shadowBlur` glow; optional slow rotation `a += t*spin`.)*

**Step 4 — E-2 Mirror** = same loop, second pass from `R` → `R − v*reachInward` (clamped ≥ inner limit so it never clutters the centre).

**Step 5 — E-3 Bass Ring** = one `ctx.arc(cx,cy,R+bass*Δ,0,2π)` stroked with palette + `shadowBlur`; radius/width scale with bass energy.

**Step 6 — E-4 Beat Ripples** = on each beat event, push `{r:R, alpha:1}` into a ring buffer; each frame expand `r += speed`, `alpha *= 0.96`, draw stroked circle, drop when `alpha<0.02`.

**Step 7 — Editor UI.** Add an **"Edge / Rim"** optgroup in the mode `<select>` (`outer-bars`, `mirror-bars`, `bass-ring`, `beat-ripples`); add an **Edge reach** slider (px outward) and a **Direction** toggle (out/in/both). Persist via the existing track-viz save path.

**Step 8 — Cinema interplay.** Decide behaviour (see §8 Q3): keep visible (they frame the video nicely) or fade. Default suggestion: **keep visible** — edge rings frame the cinema video without obscuring it.

**Step 9 — Verify.** Restart server, `node --check`, test each mode live in `dev.html`, confirm no clipping, confirm persistence, confirm DPR crispness on zoom, confirm it doesn't block scrubbing/cinema.

---

## 7. Detailed integration notes

- **Files touched:** `index.html` + `dev.html` (new `<canvas id="vizEdgeCanvas">`); `styles.css` (`.viz-edge` + cinema rules); `script.js` (`sizeVizEdgeCanvas`, `vizEdgeTick`, draw fns, `applyViz`/mode wiring, editor bindings, persistence fields). Bump `?v=` on each.
- **Performance:** one extra ~620×620 canvas at 60fps. Keep `n ≤ 128`, reuse the existing analyser read (no extra FFT). Outward bars are ~O(n) line draws — trivial. Particle/ripple pools should be capped.
- **Palette/glow:** reuse `vizColor()`; add an optional `shadowBlur` "glow" already themed via progress colours. Bloom is overkill for 2D — `shadowBlur` is enough.
- **DPR:** size backing store = `cssBox × min(devicePixelRatio,1.5)`; re-size on window resize & on player-size changes (mirror the 3D `layout()` fix so zoom never pixelates).
- **Per-track persistence:** extend `trackVizConfig`/`saveCurrentAsTrackViz` with `edgeMode`, `edgeReach`, `edgeDir`. Default `edgeMode:'off'`.
- **Playlist overlap:** the edge layer is 1.5× the disc and centred — it will overlap the playlist disc's region when open. Mitigation: lower its opacity or hide it while the playlist is open (`body.playlist-open .viz-edge { opacity:.35 }`), and/or constrain drawing to the player's *outer* arc that faces away from the playlist. → §8 Q4.
- **Beat hook:** subscribe to the existing beat event used by `beatPulseLoop()` to fire ripples/bursts (no new detector).
- **Accessibility/motion:** respect `prefers-reduced-motion` (slow/stop rotation & ripples).

---

## 8. Open decisions (need your call before I build)

1. **Scope of first build** — E1 only (4 modes), or push into E2 too?
2. **Outward box size** — 1.5× the disc (compact) vs 1.7× (room for big spikes) vs "as big as the viewport allows"? Bigger = more dramatic but more collision with surroundings.
3. **Cinema behaviour** — keep edge visuals visible (frame the video) or fade them out?
4. **Playlist-open behaviour** — dim, hide, or clip-to-outer-arc when the playlist disc is open?
5. **Mode UX** — one flat mode list (edge modes mixed in), or a separate **"Edge / Rim"** section/optgroup in the Visualisers tab?
6. **Layering** — should an edge mode be able to run *at the same time* as an in-circle mode (e.g. starfield inside + outer bars outside), or are they mutually exclusive (simpler)?

---

## 9. Effort estimate (rough)

| Phase | Modes | Effort | Risk |
|---|---|---|---|
| **E1** | Outer Bars, Mirror, Bass Ring, Beat Ripples | ~1 focused session | Low — proven math, new layer is the only novelty |
| **E2** | Polar Waveform, Concentric Rings, Particle Orbit, Stacked Blocks | ~1–2 sessions | Low–Med (particle pool tuning) |
| **E3** | Ribbon, Spiral/Galaxy, Kaleidoscope, Scope Ring | ~1–2 sessions | Med (spiral/kaleidoscope polish) |

E1 is the "I want what Vizzy has" deliverable; everything else is incremental on the same foundation.

---

## 10. References

- [R1] Banger.show — Vizzy mode comparison (Spectre, Waveform, Circle, Spherical Field): https://banger.show/compare/vizzy
- [R3] nelsonr — "Audio Ring Visualization" (stereo polygon ring) codepen: https://codepen.io/nelsonr/embed/WamzJb
- [R4] wrtchd — Circular Music Visualizer (radial bars + rotation + bass radius) codepen: https://codepen.io/wrtchd/pen/aOGJEr
- [R4b] Vibesdrop — Vizzy overview (templates, live preview): https://vibesdrop.com/music-visualizer-for-youtube/
- [R6] effect-labs — "Create an Audio Visualizer" (radial circle tutorial + code): https://effect-labs.com/en/pages/blog/audio-visualizer-js.html
- [R7] IUSV — standalone circular visualizer (ring+glow+bass pulse, stacked blocks, ribbon wave, edge fade, bloom): https://github.com/IUSmusic/IUSV
- [R8] dmeldrum6 — Web-Audio-Visualizer (radial mirror, inner-radius beat pulse, frequency rings, ring ripples, Lissajous scope, layer compositor, BPM lock): https://github.com/dmeldrum6/Web-Audio-Visualizer
- [R9] SoundTools — Circular Spectrum / Ring of Fire: https://soundtools.io/music-visualizer/
- [R10] basicfreetools — Circular Waveform / Radial Bars (mirrored) / Particle Storm / Spiral Galaxy / Kaleidoscope: https://basicfreetools.com/music-visualizer/
- [R11] everyfreetool — Circular Spectrum (inner ring glows on volume) / Galaxy Spiral: https://everyfreetool.com/video-tools/music-visualizer
- [R12] kelvinau — circular-audio-wave (ECharts, BPM-aware): https://github.com/kelvinau/circular-audio-wave

---

*Prepared as a planning document. Say the word (and answer §8) and I'll start Phase E1.*
