# Phase 2 — Running Worklog (crash-safe transcript)

Append-only log of thinking, commands, and results. Companion to `PHASE2-PROGRESS.md`
(high-level checkpoint). If restarting after a crash, read BOTH: PROGRESS for the
resume pointer, this file for the detailed trail.

**Persisted work-products on disk (survive crashes):**
- `vendor/bpm-detect/bpm-detect.js` — bespoke beat analyzer (DONE, 5/5 tests)
- `test-bpm.js` — analyzer unit test
- `patch-phase2.py` — the COMPLETE atomic script.js patch (all of E1–E12)
- `docs/PHASE2-PROGRESS.md` — checkpoint + decisions + data model
- `docs/dj-phase-2-proposal.md` — the design proposal
- This file.

---

## Entry 1 — setup & analyzer (DONE)
- Read all 6 docs; wrote proposal (`docs/dj-phase-2-proposal.md`).
- Decision: bespoke zero-dep beat engine (not realtime-bpm-analyzer) — onset-flux →
  autocorrelation → parabolic peak → confidence + beat-0 phase.
- Wrote `vendor/bpm-detect/bpm-detect.js` exposing `window.BpmDetect.analyze(buf)->{bpm,confidence,offset}`.
- Wrote `test-bpm.js`; ran → **5/5** (120/90/140/128-noisy/124-60s, all ±0.2 BPM). ✓
- Created `docs/PHASE2-PROGRESS.md` checkpoint.

## Entry 2 — extracting exact code regions (DONE)
- Confirmed script.js is pristine v111 (0 Phase-2 fields present).
- Extracted exact bytes (via `sed -n`) of every edit target; line numbers + exact
  snippets recorded in `PHASE2-PROGRESS.md` § CONFIRMED EXACT SNIPPETS.
- Key lesson reaffirmed: `read_file` collapses some line breaks → always `sed`/`cat`
  for exact text before patching.

## Entry 3 — wrote patch-phase2.py (DONE)
- Persisted the FULL atomic patch (E1..E12 + new-functions append + init wiring) to
  `patch-phase2.py`. Each entry asserts `count==1`; aborts without writing on any miss.
- About to run it + `node --check script.js`.

## Entry 4 — executed the patch (DONE)
- `python3 patch-phase2.py` → **17/17 patches applied**, `node --check` ✓.
- Caught + fixed a self-inflicted bug: BPM cell class had `${t._bpmDetecting ? detecting : ''}`
  (bare identifier) → quoted it to `'detecting'` (would have thrown ReferenceError while detecting).
- `patch-phase2-html.py` (3 patches) + `patch-phase2-css.py` (2 patches) applied cleanly.
- Bumped ?v=111 → ?v=112 in index.html + dev.html.

## Entry 5 — server-track rebuild loops (DONE — important)
- Found the deployed page rebuilds its playlist from the server theme in TWO loops
  (script.js ~492 & ~536) that did NOT carry bpm → a fresh browser would lack BPM.
- Patched both (count==2 assert) to add bpm/bpmConfidence/bpmOffset/bpmSource.
- Now the deployed player inherits BPM for beat-sync + beat-pulse from the server theme.

## Entry 6 — verification (DONE)
- Smoke test: all routes 200; bpm-detect.js served text/javascript; dev.html has it,
  index.html does not (correct). `node --check` ✓. Analyzer re-run 5/5.
- Static integrity: 8 new functions each defined once; no duplicate lets; cross-refs resolved.
- CANNOT run a real browser here → browser test deferred to the user.

## Entry 9 — pulse follows kick + snare (DONE, v115)
- Swapped bass-band *level* for **spectral flux (onset)** over a KICK band (bins 1-4,
  ~80-430 Hz) + SNARE crack band (bins 10-45, ~850 Hz-4 kHz). Flux = sum of positive
  frame-to-frame rises, so it peaks on every drum transient (kick OR snare) regardless
  of loudness, and ≈0 on sustained/beatless audio → still in breakdowns.
- Added `_drumPrev` prev-frame buffer + `_drumGotPrev` first-frame guard (no startup spike).
- Relaxed gate (thresholds 0.05→0.02, gateCoef 0.06→0.08) so it's less shy; bumped depth
  (scale 1.5-7%→2-8%, flash 5-25%→6-28%). `patch-phase2-pulse2.py`. Bumped v114→v115.
- WHY this fixes "doesn't move at some points": bass-only missed the snare (its energy is
  in the high crack); flux catches both kick and snare transients across the spectrum.
## Entry 8 — energy-reactive beat pulse (DONE, v114)
- Replaced the grid-based pulse with an **analyser-driven bass-band energy envelope**
  (`patch-phase2-pulse.py`). Per frame: avg low FFT bins → adaptive peak/floor normalize
  → attack(0.5)/decay(0.12) envelope → `--beat-pulse` (scale) + `--beat-flash` (brightness).
- **Silence gate** (`_beatGate`, eased 0.06): pulses only when real beat dynamics exist
  (range>0.05 && peak>0.05) → **stops during breakdowns/quiet, restarts with the drums**.
- No longer depends on `t.bpm` (reacts to audible drums directly); honest on CORS zeros.
- CSS: `--beat-flash:1` root var + `filter: brightness(var(--beat-flash,1))` on `.album`.
- Deep-dive doc: `docs/beat-pulse-deepdive.md`. Bumped v113→v114; node --check ✓; served ✓.
- Tunables in `beatPulseLoop`: peakRise 0.35, peakDecay 0.01, floor 0.004, attack 0.5,
  decay 0.12, gateCoef 0.06, thresholds (0.05). Adjust if it pulses too eager/too shy.
## Entry 7 — UX tweaks (DONE, v113)
- **Removed BPM chip from the main player** by request. `updateBpmChip()` is now a
  no-op that also strips any existing `#bpmChip`. Tempo still shows in the Playlist
  Manager. (script.js)
- **Manager BPM visibility fix**: `.pm-bpm` now `flex-wrap: wrap` + `max-width:100%`,
  number input 52→48px, dot/btn/src `flex:0 0 auto` so they wrap to a 2nd line instead
  of clipping; **dev panel widened 380→420px** for breathing room. (styles.css)
- Bumped ?v=112 → ?v=113; node --check ✓; served JS/CSS confirmed.
- NOTE: beat-pulse artwork animation left ON (toggleable in Global). If user wants it
  off the player too, flip `gs.beatPulse` default to false (gs object) or stop the loop.

## Entry 10 — calm rhythmic swell (DONE, v116)
- Flux (v115) was too busy/frenetic (fired on every transient). Replaced with a
  **calm per-beat swell**: smooth kick-band LEVEL (rises ~once/beat, not per-transient)
  modulates a per-beat envelope from the BPM grid (soft attack over 10% then long exp
  ease). depth = smoothed normalized bass; gate rests it in breakdowns. `patch-phase2-pulse3.py`.
- Calmer depth: scale 1.5-6.5%, flash 3-15%. Bumped v115→v116. node --check ✓; served ✓.
- This is the "hybrid grid + energy" (Approach D from the deep dive) — the smoothest,
  most rhythmic option: one even swell per beat, deeper in loud sections, still when quiet.
- Tunables: bass smooth 0.15, peak 0.2/0.008, floor 0.003, gate 0.025/0.05, attack 10%,
  exp decay 3.0. To make it calmer: slow decay (smaller exp coef) or widen attack %.

## Entry 11 — onset-triggered beat-locked groove (DONE, v117)
- The grid-prediction swell (v116) felt disconnected because it wasn't synced to the
  AUDIBLE drum. Replaced with **onset triggering**: detect real kick onsets (positive
  rise of lightly-smoothed bass band) -> SNAP a swell on each actual hit. BPM supplies
  the refractory (0.6*beat -> one swell/beat, no rolls/noise) + the decay time-constant
  (45% of beat). Rests after 2.2s with no kick. Learns tempo from kicks if no BPM.
- `patch-phase2-pulse4.py`. Depth: scale 2-8%, flash 4-20%. Bumped v116→v117. parse ✓.
- WHY this should finally "groove": each swell lands on the real kick you hear (locked),
  exactly once per beat (rhythmic), with a musical snap+decay. Tunables: smoothing 0.4,
  thr 2x baseline, refractory 0.6*beat, decay tau 0.45*beat, rest 2.2s.

## DEFERRED — beat-pulse artwork (parked 2026-08-12)
- Tried 4 approaches (grid → bass-level → flux → grid-swell → onset-triggered v117).
- User still "not crazy about the way the beat is looking." PARKED for later.
- Current code: onset-triggered swell (v117), gated by gs.beatPulse (Global toggle).
- Ideas to revisit: (a) tune onset thresholds/decay; (b) require BOTH bpm-grid phase
  AND onset (PLL-style phase-lock) so swells stay perfectly even yet on-the-hit;
  (c) snap swells to 8-bar phrases not every beat; (d) make it follow the bar, not
  the beat; (e) visual: scale-from-center vs translate vs brightness-only. Files:
  beatPulseLoop in script.js; deep dive docs/beat-pulse-deepdive.md.

## Entry 12 — cinema / immersive video mode (DONE, v118)
- NEW FEATURE (not Phase 2): when a VIDEO is playing and the mouse leaves the player,
  the control surface fades out (panel + icons + buttons + text) keeping only the
  scrubber + playhead (.knob-overlay), and the video fills the circle (object-fit cover,
  drag/zoom neutralised). Mouse onto the MAIN area fades controls back; hovering the
  scrubber keeps them hidden (scrub in peace). Pause -> controls show. Video-only.
- Decisions (from user): trigger=playing-only, model=pure-hover (no timer),
  scrub=hidden (bar usable alone), fill=cover.
- Impl: `.cinema` class on .music-player; CSS fades `.dash::before/::after` +
  `.dash > *:not(.seeker):not(.knob-overlay)`; `#coverVideo.album` -> object-fit cover.
  JS: engageCinema/videoMediaActive/cinemaOnPlay/attachCinema; mouseenter/leave/mousemove
  (mousemove exits cinema only when target is NOT .seeker/.knob-overlay); wired into
  onPlay (cinemaOnPlay), onPause (exit if video), loadTrack (exit), init (attachCinema).
- Patches: `patch-phase2-cinema.py` (JS), `patch-phase2-cinema-css.py` (CSS). v117→v118.
- object-fit snaps (not animatable); the 0.35s panel fade masks it. Smoother resize
  (transform-scale tween) = future polish if wanted.

## Entry 13 — cinema v2: pure-hover + toggles (DONE, v119)
- (1) "Have to mouse too far in": dropped the scrubber-keeps-hidden exception. Now PURE
  HOVER — mouseenter on the player (incl. crossing the progress bar) -> engageCinema(false)
  (controls back). Removed the mousemove handler. attachCinema rewritten.
- (2) Per-track + global toggles: t.cinema (per track) + gs.cinema (default true).
  cinemaEnabledForTrack() = t.cinema==null ? gs.cinema!==false : !!t.cinema. Gated in
  cinemaOnPlay + mouseleave. UI: #trackCinema checkbox (Editor > Video options) +
  #gsCinema checkbox (Global tab). Persisted: getThemeData.tracks.cinema + both server
  rebuild loops + gs. Patches: patch-phase2-cinema2.py (JS, 9 edits) + patch-phase2-cinema2-html.py.
  v118→v119. NOTE: dev.html patch needed correct 6-space/4-space indentation (first attempt
  failed on whitespace — lesson: cat -A before writing HTML anchors).

## Entry 14 — cinema: 1cm buffer above the bar (DONE, v120)
- v119 pure-hover made entering onto the playhead show controls immediately -> couldn't
  grab/drag the playhead while hidden. Fix: buffer zone. mouseenter no longer exits
  cinema; a mousemove handler exits cinema ONLY when clientY < seeker.top - 38px (~1cm
  past the progress bar). Over the bar / within 1cm above it -> cinema stays (scrub in
  peace). Past that -> controls back. mouseleave still engages cinema. `patch-phase2-cinema3.py`.
- Tunable: CM (38px ~1cm) and the reference (el.seeker.top). v119→v120. parse ✓; served ✓.

## Entry 15 — cinema: arc-hugging buffer + scrub guard (DONE, v121)
- Issue A: clicking playhead showed controls because scrub PAUSES -> onPause -> engageCinema(false).
  Guarded: `if (videoMediaActive() && !state.dragging) engageCinema(false)` (scrub-pause no exit).
- Issue B: rectangular buffer (seeker box top) made controls appear only at the player middle.
  Replaced with distance-from-center: cinema stays within CM of the player's circular EDGE
  (the progress arc lives on the edge), returns once mouse moves past into the middle. Hugs the arc.
- CM 38->18 (~5mm; > knob radius so playhead stays grabbable). v120->v121. parse ✓; served ✓.
- Tunable: CM (buffer width in px) in attachCinema.

## Entry 16 — cinema: wider buffer + style dropdown (DONE, v122)
- (1) Buffer CM 18->30 so the trigger sits JUST OFF the bar (was firing over the bar's
  inner edge / knob). Distance-from-center unchanged.
- (2) Cinema STYLE dropdown: 'bar' (progress bar) | 'head' (playhead only). head-only
  hides arc-track + arc-progress + .wheel (CSS opacity 0, 0.35s), keeps the playhead dot
  + its hit target -> fully scrubbable. engageCinema toggles a .head-only class via
  cinemaStyleForTrack() (t.cinemaStyle || gs.cinemaStyle || 'bar'). UI: #trackCinemaStyle
  (Editor > Video options) + #gsCinemaStyle (Global tab). Persisted in tracks + 2 rebuild
  loops + gs. Patches: patch-phase2-cinema5{,-html,-css}.py. v121->v122. parse ✓; served ✓.

## WORKING RULE (from user, 2026-08-12)
After ANY code change: restart the server AND verify the latest version is served
(curl the served HTML's ?v= + key markers). Don't leave the user on a stale cache.
The Node server stops between turns — assume it's down at the start of each task.

## Entry 17 — direct video framing (DONE, v123)
- Drag-to-reposition + wheel-to-zoom directly on the video, active only when a video is
  showing AND cinema is off (panel out) AND not in editor Reposition mode. Reuses --cover-*
  vars (consistent with the editor Reposition tool). Persists t.transform per track on
  pointerup / wheel-stop. Works on editor + deployed. attachVideoFraming() in init.
- CSS: grab cursor on #coverVideo (default in cinema). Patches patch-phase2-videoframe{,-css}.py.
- v122->v123. parse ✓; restarted server + verified served v123.
- LESSON: NEVER use `pkill -f "node server.js"` in bash — the pattern self-matches the
  running shell command and kills it (exit -1). To stop a server use stop_process on its
  process_id, or kill by port. To restart, just start_process again.

## Entry 18 — video framing fix + editor-only (DONE, v124)
- Drag wasn't firing: handler was on #coverVideo which lost the pointer to stacked
  layers above. Rewrote attachVideoFraming to attach pointerdown/move/up/wheel to
  el.player (reliable hit-testing), with onControl() filter so real controls (play /
  scrub / icons / volume / playhead) still work, v.draggable=false (block native drag),
  e.preventDefault() on pointerdown. Gated to isEditorPage() (editor/backend ONLY, not
  deployed). `patch-phase2-videoframe2.py`. v123->v124. parse ✓.

## Entry 19 — reframe video IN CINEMA view (DONE, v125)
- User wants to reposition/zoom the video while it's in the FULL-CIRCLE cinema state (not
  the small loaded state). Fixes:
  (1) framable() no longer blocks cinema -> drag/wheel work in cinema too.
  (2) state._videoDragActive flag set during drag; cinema mousemove skips while dragging.
  (3) Cinema hover-exit changed from circular-buffer to a lower CONTROL ZONE (clientY >
      top+height*0.6) -> the VIDEO area (upper) stays in cinema (draggable/zoomable);
      controls return when moving to the bottom (progress bar/buttons) or leaving player.
  (4) Cinema CSS video transform now uses --cover-dx/dy/scale on the cover-fill, so the
      user's framing applies in cinema; cursor grab in cinema too.
- Patches patch-phase2-videoframe3{,-css}.py. v124->v125. parse ✓; restarted + served v125.
- NOTE: this changes earlier "scrub hidden near bar" (circular buffer) — controls now show
  when moving to the bottom zone. Trade-off for cinema reframing. Tunable: the 0.6 zone line.

## Entry 20 — no-crop video (DONE, v126)
- Cinema video was cropping widescreen media: object-fit cover + auto cover-fill on load.
- (1) Cinema #coverVideo.album object-fit cover -> CONTAIN (whole video, letterboxed, no crop).
- (2) maybeAutoFillCover now returns early for video (no cover-fill zoom) so it loads at
  scale 1 = full frame. Cover image auto-fill unchanged.
- User can still drag/wheel to zoom (zoom-in crops — optional). Patches patch-phase2-nocrop{,-css}.py.
- v125->v126. parse ✓; restarted + served v126.

## Entry 21 — videos default to FILL again (DONE, v127)
- v126 wrongly defaulted video to the uncropped frame. User wants DEFAULT = fill the circle
  (as before) + ability to zoom OUT to the full aspect ratio.
- Reverted the maybeAutoFillCover video-skip (auto cover-fill runs for video again) ->
  contain + cover-fill scale = fills the circle by default. Kept cinema object-fit:contain
  (from v126) so zooming OUT continuously reveals the full uncropped frame. Zoom IN crops more.
- `patch-phase2-nocrop-revert.py`. v126->v127. parse ✓; restarted + served v127.

## Entry 22 — reliable video fill + full-media access (DONE, v128)
- Root cause of "everything zoomed out": loadTrack computed the cover-fill scale
  SYNCHRONOUSLY before the video had dimensions -> null -> scale 1 -> letterboxed.
- Fix: object-fit stays CONTAIN (so the WHOLE media is rendered and reachable by
  pan/zoom — drag to any corner, zoom in/out). Added a robust vfill() that re-applies
  the cover-fill scale once the video's metadata lands (readyState>=1 now, else
  loadedmetadata once-listener, +500ms timeout fallback). Also treats near-1 scale with
  no drag as untweaked (heals stale framing from v126/v127 experiments) so every video
  fills again. No toggle. Default = fills the circle (looks like v125), full media
  accessible. `patch-phase2-videofill.py`. v127->v128. parse ✓; restarted + served v128.

## Entry 23 — artwork & video independent repositioning FIXED (DONE, v139)
- Symptom (recurring): "artwork and video are not independently repositionable."
  v138 had already given them SEPARATE CSS vars (--cover-* for the video,
  --art-* for the cover-art backdrop) — but the user still saw them move together.
- ROOT CAUSE: the cover <img> only switches to its own --art-* transform when the
  player carries the `.video-active` class (rule `.music-player.video-active
  #cover.album`). Several code paths that show a video NEVER added that class:
    * upload paths (script.js ~671-672, ~1577-1580, ~1665-1666)
    * crossfade handover set display:none yet toggled the class off-truth (~5144)
  Without `.video-active`, the cover <img> fell back to the BASE rule
  `.music-player > .album` which uses --cover-* — the SAME variable as the video
  — so the two moved as one. The CSS cascade itself was always correct.
- FIX (single source of truth): added `syncVideoActive()` which sets
  `.video-active = videoMediaActive()`, kept in lock-step by a MutationObserver
  on el.coverVideo watching its `src`+`style` attributes. Now EVERY path (load,
  upload, handover, clear) keeps the class correct automatically — no per-call-site
  bookkeeping. Also declared --art-dx/dy/scale on .music-player.
- PROOF: test_independent_transform.js loads the REAL styles.css into jsdom and
  confirms: video-active ON  -> cover binds var(--art-dx), video binds var(--cover-dx)
  (DIFFERENT vars = independent); audio-only -> cover uses --cover-* (legacy).
  All assertions pass.
- v138->v139 (bumped ?v= on styles.css + script.js in dev.html & index.html).
  node --check OK; restarted server; served v139 confirmed via curl.
- REFINEMENT: syncVideoActive() derives .video-active from TRACK TYPE
  (demoPlaylist[currentIndex].video), not from the video element's display
  state. Track-type is stable across the src/display churn of load/upload/
  handover, so the cover never flickers between backdrop-mode and main-mode.
  The MutationObserver on el.coverVideo (src+style) re-derives it on every
  mutation — catching the upload paths that previously dropped the class.

## Entry 24 — artwork backdrop: full image, NO crop (DONE, v140)
- User: artwork was cropped into a square; wanted the full image.
- Cause: `.music-player.video-active #cover.album { object-fit: cover }` cropped
  the cover-art backdrop to fill the square/circle.
- Fix: changed to `object-fit: contain` (full image, never cropped). User can still
  zoom in via "Cover art zoom" to fill more if desired. v139->v140; served v140.

## Entry 25 — cinema: scrub without controls; reveal only on progress bar (DONE, v141)
- User: "can't scrub in cinema mode without the controls appearing. Controls should
  appear only when the progress bar is crossed."
- Cause: attachCinema's mousemove revealed controls for ANY pointer in the lower 40%
  (clientY > 0.6H) — the progress arc/playhead LIVE in that zone, so reaching for or
  dragging the playhead popped the whole dash (panel + play button + icons). Worse,
  once revealed the handler early-returned (!cinema) so the controls stayed up mid-scrub.
- Fix (attachCinema mousemove):
  1. SCRUB suppression FIRST: while state.dragging (set by startSeek/endSeek), call
     engageCinema(true) and return — controls hide so you can drag the playhead in peace,
     even if they flashed on a moment before. engageCinema(true) is a no-op when cinema is
     already on, so it's cheap every move.
  2. Reveal is now PROGRESS-BAR gated: controls appear only when e.target is within .seeker
     (the progress bar hit area at the bottom), not the whole lower 40%. Hovering the video
     keeps cinema on.
- Removed the now-unused CM/buffer constants + stale comment. v140->v141; node --check OK;
  served v141 confirmed.

## Entry 26 — default look: artwork + video both FILL the circle (DONE, v142)
- User: "Default look should be all artwork and video filling the circle. The user
  can reposition and zoom from there."
- The VIDEO already filled by default (computeCoverFillScale -> --cover-scale on a
  contain base, so zoom-out reveals the full frame). But the ARTWORK backdrop (its own
  --art-* layer behind the video) sat at --art-scale 1 with object-fit:contain -> it
  was letterboxed and did NOT fill. computeCoverFillScale() couldn't be reused: it keys
  off the VIDEO when one is showing.
- Fix:
  * computeArtFillScale() — always measures the cover <img> (min/max cover-fit math,
    same as the video helper but for the image).
  * applyArtAutoFill() — sets --art-scale to the fill + syncs the art-zoom slider.
  * maybeAutoFillArt() — gated to video tracks (audio-only uses --cover-* as main media).
  * loadTrack + crossfade handover now reset --art-dx/dy per track and FILL --art-scale
    (cover 'load' event + 800ms timeout cover the async image-size timing).
  * Art Reset button + double-click reset now reset to FILL (not scale 1).
- object-fit stays contain for the artwork -> default fills the circle (clipped to the
  circle, no harsh square crop), and zooming OUT to 1.0 reveals the full image.
- NOTE: artwork transform is per-session (not persisted per track yet); video transform
  still persists. v141->v142; node --check OK; served v142 confirmed.

## Entry 27 — INVESTIGATE: artwork + video not filling the circle (dark grey) (DONE, v143)
- User: "Cover art and video still do not fill the circle by default. I still see dark
  grey. It should fill the circle like it did in v125."
- Facts found: player bg is #252c36 (the dark grey). Seed cover is 600x600 (square ->
  fills at scale 1). User's track uses Sunshine_Roses_Image.jpg = 450x600 PORTRAIT
  (needs --art-scale ~1.33) + a video (needs --cover-scale ~1.78). Fill MATH verified
  correct in isolation. So the vars weren't being APPLIED.
- Root causes:
  1. maybeAutoFillCover had a fragile src-matching gate (absURL compare + blob/uploads
     special-case) that could silently no-op, so the video never re-filled with its own
     dims after metadata landed.
  2. The video fill in loadTrack ran BEFORE the video element was set up, so it used the
     cover-IMG dimensions (wrong) or null, then relied entirely on maybeAutoFillCover to
     correct.
  3. isIdentityTransform gate: tracks repositioned in earlier sessions (while the fill
     was failing) saved a scale-1 transform -> non-identity -> fill skipped every reload
     (stuck letterboxed).
- Fix (v143): make the DEFAULT fill unconditional & reliable:
  * maybeAutoFillCover: always applyCoverAutoFill() (dropped src-match + isIdentity gates).
  * Added vfill() in the VIDEO branch: fills --cover-scale from the VIDEO's own dims once
    metadata lands (+ 800ms timeout) — the one place the video is actually set up.
  * maybeAutoFillArt already ungated; reset --art-dx/dy per track (handover too).
- Net: both layers fill the circle on every load (like v125). object-fit stays contain so
  zoom-out still reveals the full frame. Repositioning is now per-session (always re-fills
  on load); say the word if you want it to persist again.
- Verified math; node --check OK; served v143. (jsdom can't load real media so couldn't
  render-confirm — needs browser check.)

## Entry 28 — NEW FEATURE: per-track playlist-panel backdrop (image+video) (DONE, v144)
- User wants the SAME layered artwork+video capability as the main player, but for the
  PLAYLIST panel (.playlist-circle behind the track list) — PER TRACK (not global):
  drag-&-drop independent artwork/video, OR a per-track toggle to mirror the main
  player; muted video; full backdrop with a readability scrim; saved per track.
- HTML (dev.html + index.html): added .pl-backdrop {#plCover img, #plVideo video},
  .pl-scrim, .pl-drag-overlay inside .playlist-circle.
- CSS: backdrop layers fill the circle (contain + cover-fill scale), independent
  transforms (--pl-art-* image, --pl-vid-* video), .pl-video-on shows the video,
  .pl-scrim (rgba 0.42) for list readability, .pl-drop-target affordance,
  .pl-drag-overlay(.active) reposition surface. Vars declared on .playlist-circle.
- JS:
  * applyPlBackdrop(t): mirror (default ON, uses t.cover/t.video) or independent
    (t.plCover/t.plVideo); muted autoplay video; saved transforms; fills both layers.
  * computePlFillScale/applyPlArtFill/applyPlVidFill — cover-fill for each layer.
  * attachPlDrop: drag image/video onto the circle -> set t.plCover/t.plVideo, leave
    mirror mode, upload to server (keys plCover/plVideo).
  * togglePlDragMode('pl-art'|'pl-vid') + persistPlTransform — independent
    reposition/zoom over the playlist circle (parallel to the main player's drag).
  * attachPlFraming: mirror toggle, file pickers, zoom sliders, drag/reset buttons,
    + load/loadedmetadata re-fill.
  * Wired into loadTrack + crossfade handover; init calls attachPlDrop/attachPlFraming.
  * savePlaylist already persists full track objects, so the new fields save per-track.
- Editor UI (dev.html, track tab): "Playlist panel" section — mirror checkbox, cover/
  video pickers, art/video Reposition+Reset, art/video zoom sliders.
- v143->v144; node --check OK; served v144 confirmed (layers+CSS+JS on both pages).

## Entry 29 — playlist backdrop media ON/OFF toggle (DONE, v145)
- User: a way to switch the playlist backdrop media on/off; when OFF, the playlist
  shows the colour scheme from the 'Colors' tab.
- The Colors tab already drives --pl-base/--pl-grad -> .pl-bg/.pl-gradient (always
  present, just covered when media is on). So OFF = just hide the backdrop layers.
- Per-track t.plMedia (default true). applyPlBackdrop toggles .pl-media-off on the
  playlist circle; when off it hides .pl-backdrop + .pl-scrim (=> colours show),
  pauses the video, and skips loading media. Saved per track via savePlaylist.
- Editor UI: "Playlist media" checkbox at the top of the Playlist panel section
  (on = backdrop; off = colour scheme). Wired in attachPlFraming + syncPlBackdropUI.
- CSS: .playlist-circle.pl-media-off > .pl-backdrop, .pl-scrim { display:none }.
- v144->v145; node --check OK; served v145 confirmed.

## Entry 30 — editor cleanup: two tabs under "Swap / Edit Track" (DONE, v146)
- User: split the "Swap / Edit Track" section into two tabs — "Edit Main Player" and
  "Edit Playlist Panel" — so main-player vs playlist-panel functions are separated.
- Added a nested sub-tab bar (.sub-tabbar, #editTabbar) with two .sub-panel containers.
  * Edit Main Player: drag-drop audio, track file, cover image, cover video + clear,
    video options (useVideoAudio/videoLoop/trackCinema/trackCinemaStyle), scrub behavior,
    Video tools, Cover art tools, Cover art zoom, Cover/Video zoom.
  * Edit Playlist Panel: media on/off, mirror toggle, pl cover/video pickers, pl
    art/video tools, pl art/video zoom.
  * Track Title / Artist / Apply stay below the tabs (general metadata, always visible).
- CSS: .sub-tabbar (pill buttons, cyan active) + .sub-panel{display:none}/.active{block}.
- JS: attachDevTabs now also wires #editTabbar (data-stab) -> toggles .sub-panel.active.
- Removed the redundant <h3>Playlist panel</h3> (the tab replaces it). v145->v146;
  node --check OK; served v146 confirmed (controls in correct panels).

## Entry 31 — cinema: grab playhead without controls (re-fix) (DONE, v147)
- User: the playhead issue reoccurred — can't grab it without the controls appearing.
- Cause: v141's reveal fired whenever the pointer was over .seeker (the whole bottom
  progress-bar hit area, which INCLUDES the playhead), so just APPROACHING the playhead
  popped the controls before the drag. The scrub-drag suppression only hid them mid-drag.
- Fix (attachCinema mousemove): reveal controls ONLY when the pointer is over the
  control CLUSTER (.controls = play/pause buttons at the CENTRE), by bounding-box test —
  never over the progress bar/playhead. Leaving the cluster re-engages cinema (controls
  hide), so moving from the centre down to the playhead hides the UI before you grab it.
  Guarded to act only while a video is playing with cinema enabled (no change when paused
  or for non-video / cinema-disabled tracks). Scrub-drag suppression kept as a safety.
- Net: move to the centre to get controls; grab/scrub the playhead at the bottom in peace.
- v146->v147; node --check OK; served v147 confirmed.

## Entry 32 — cinema reveal hugs the progress-track curve (DONE, v148)
- User: v147's centre-only reveal was "too far in". Want the controls to reappear when
  the mouse crosses the progress track and is "just over" it, in the wave-panel area,
  hugging the curve — while the playhead/track stays a clean scrub zone.
- Fix (attachCinema mousemove): reveal zone is a radial BAND just INSIDE the arc
  (d in [0.78wr, 0.94wr] from the wheel centre, lower half only) — it hugs the arc curve.
  The track ring itself (d >= 0.94wr, where the playhead lives) is the scrub zone and
  forces cinema ON immediately, so grabbing the playhead never pops the UI. A short
  160ms dwell on the band means a quick pass through it (on the way to the playhead)
  doesn't flash the controls; once shown they stay up off the ring until mouseleave.
  Added _cinemaRevealT timer (cleared on ring/mouseleave/drag). Scrub-drag suppression kept.
- v147->v148; node --check OK; served v148 confirmed.

## Entry 33 — cinema reveal: whole wave-panel inside the arc (DONE, v149)
- User: v148's reveal band was too thin — crossing the progress bar into the wave panel
  didn't reveal (only near the playhead). Want: cross the arc ANYWHERE into the wave
  panel -> controls appear.
- Fix: expanded the reveal zone from a thin ring band (d in [0.78wr, 0.94wr]) to the
  ENTIRE area inside the arc (d < 0.94wr, below the wheel centre) = the whole wave
  panel. The track ring (d >= 0.94wr, where the playhead lives) remains the scrub zone
  (immediate hide). Dwell reduced 160->120ms for responsiveness; stay-revealed + ring/
  mouseleave hide unchanged. So crossing the arc into the wave panel anywhere reveals.
- v148->v149; node --check OK; served v149 confirmed.
## Entry 34 — cinema engages for all video tracks; "Progress bar" style visible (DONE, v150)
- User: "Cinema mode ... and Cinema style: Progress bar does not work. Cannot ever see
  the progress bar when progress bar is selected."
- Root cause: cinemaOnPlay gated engagement on `state.master === el.coverVideo`, so for
  video tracks that play MP3 audio (video as a muted visual — the common case) cinema
  NEVER auto-engaged. Without cinema engaging, you never got the cinema look (controls
  hidden, progress bar remaining) at all.
- Fix 1: cinemaOnPlay now engages for ANY video track while playing
  (videoMediaActive() && cinemaEnabledForTrack() && !mouseOver) — dropped the
  video-master requirement. (mouseleave already engaged regardless of master.)
- Fix 2 (defensive CSS): .music-player.cinema:not(.head-only) forces the arc-track /
  arc-progress / wheel to stay visible, so the "Progress bar" style always shows the
  progress bar; only .head-only hides them. (Base rules already did this, but the
  explicit rule guarantees it.)
- v149->v150; node --check OK; served v150 confirmed.
## Entry 35 — non-cinema controls stay; "Progress bar" reliably shows (DONE, v151)
- User: (1) In NON-cinema mode (checkbox off), crossing/scrubbing the progress bar hid
  the controls (cinema behaviour). (2) Still no progress bar when "Progress bar" style
  is selected.
- Fix 1 (non-cinema): the mousemove handler ran the scrub `engageCinema(true)` BEFORE
  the `cinemaEnabledForTrack()` guard, so scrubbing hid controls even with cinema off.
  Moved the guard to the top -> in non-cinema mode the handler returns immediately and
  controls are ALWAYS shown.
- Fix 2 (progress bar): cinemaStyleForTrack now defaults to 'bar' (progress bar visible)
  and only returns 'head' on an EXPLICIT per-track "Playhead only" (ignoring a stale
  global setting). The global cinema-style dropdown also writes the current track's
  cinemaStyle so it takes effect immediately. Defensive CSS (cinema:not(.head-only)
  forces arc visible) from v150 remains.
- v150->v151; node --check OK; served v151 confirmed.
## Entry 36 — mirror mode: playlist video syncs to the main video (DONE, v152)
- User: with "Mirror main player" on, the playlist video must play in sync with the main
  player's video (same time / play-pause). It was playing independently (its own muted loop).
- Fix: syncPlVideo() mirrors el.coverVideo -> el.plVideo when in mirror mode (plMirror &&
  plMedia both on): same play/pause, currentTime re-aligned when drift > 120ms, same
  playbackRate, and loop follows the main video. applyPlBackdrop now calls syncPlVideo()
  in mirror mode (independent mode still free-loops). attachPlVideoSync() listens on the
  main video's play/pause/seeked/seeking/ratechange/loadedmetadata/timeupdate/playing/
  waiting/ended -> syncPlVideo. Wired in init.
- v151->v152; node --check OK; served v152 confirmed.
## Entry 37 — mirror: panel video reliably plays + mirrors main framing (DONE, v153)
- User: (1) Sometimes toggling Mirror on didn't play the video in the panel (just cover
  art). (2) Repositioning/zooming the MAIN player didn't reflect in the playlist panel.
- Fix 1 (video play race): added el.plVideo 'loadedmetadata'/'canplay' listeners that
  re-run syncPlVideo, so once the panel video is actually ready it starts playing in
  step with the main video (the previous call could fire before it had loaded).
- Fix 2 (mirror framing): new syncPlMirror() copies the main player's --cover-* ->
  --pl-vid-* and --art-* -> --pl-art-* on the playlist circle (panel video follows the
  main video's framing, panel artwork follows the main artwork). Kept in sync via a
  MutationObserver on el.player's style (signature-cached so the per-frame beat-pulse
  writes don't trigger work). applyPlArtFill/applyPlVidFill now skip in mirror mode
  (framing comes from the main player); applyPlBackdrop calls syncPlMirror() at the end.
- v152->v153; node --check OK; served v153 confirmed.
## Entry 38 — playlist panel: video layer on/off toggle (DONE, v154)
- User: ability to turn the playlist-panel VIDEO on/off, in both mirror and independent
  modes.
- Added per-track t.plVideoOn (default true) + "Playlist video" checkbox in the Playlist
  Panel editor tab. applyPlBackdrop: videoSrc is empty when video is off, so the video
  element is cleared + .pl-video-on removed -> only the cover art shows. Works in mirror
  mode (don't mirror the video) and independent mode (don't show the plVideo). The cover
  art layer is unaffected. syncPlBackdropUI syncs the checkbox; attachPlFraming wires it.
- v153->v154; node --check OK; served v154 confirmed.
## Entry 39 — playlist video on/off reliable (DONE, v155)
- User: "Show video layer" checkbox worked intermittently — checked sometimes showed no
  video, unchecked sometimes still showed.
- Causes: (1) el.plVideo used preload="metadata", so a PAUSED (mirroring) panel video had
  no decoded frame -> transparent -> cover art showed instead of the video. (2) syncPlVideo
  didn't check plVideoOn, so it could keep driving the panel video after it was turned off.
- Fix: el.plVideo preload="auto" (decodes frames -> the video shows even when paused, on
  the same frame as the main video). syncPlVideo now returns early when plVideoOn is false,
  and aligns currentTime at a tighter 0.08s threshold so a paused main still mirrors its
  frame into the panel. Turning the box off clears+hides the video (display:none via no
  .pl-video-on), turning it on sets the src + plays/shows it.
- v154->v155; node --check OK; served v155 confirmed.
## Entry 40 — playlist video on/off made reliable (DONE, v156)
- User: still intermittent on v155 — checked sometimes showed no video, unchecked
  sometimes still showed.
- Root cause: turning the video OFF did removeAttribute('src') + load(), so turning it
  back ON had to RELOAD the video — and during that reload (or the reload/play() race)
  the panel was transparent (cover art) or got stuck.
- Fix: turning the video off now just hides (remove .pl-video-on -> display:none) +
  pauses, and KEEPS the src. So re-enabling is instant (src already loaded) -> the
  video shows/plays immediately with no reload race. The mirror branch also calls
  play() directly (not only via syncPlVideo) as a safety. (src is cleared only on a
  genuine track switch / no-video track, via the if-branch's src-change check.)
- v155->v156; node --check OK; served v156 confirmed.
## Entry 41 — playlist-panel media OFF by default on load (DONE, v157)
- User: on first load the panel showed the box checked but no video; want the panel to
  load showing the colour scheme from Colors (media OFF), then opt in via "Show backdrop
  media".
- Fix: flipped the plMedia default from ON to OFF. mediaOn now = !!(t && t.plMedia === true)
  (was !(... === false)). All dependent default-on checks (syncPlBackdropUI checkbox,
  syncPlVideo/syncPlMirror mirror gates, applyPlArtFill/applyPlVidFill guards) changed from
  `plMedia !== false` to `plMedia === true`. The editor "Show backdrop media" checkbox is
  unchecked by default. So a fresh load shows the Colors scheme; checking the box turns
  media on (and the mirror/video layers then apply). Tracks where you explicitly turned
  media on (plMedia === true) keep it.
- v156->v157; node --check OK; served v157 confirmed.
## Entry 42 — mirror mode = cinema view (video only) in playlist panel (DONE, v158)
- User: when "Mirror main player" is checked, the playlist panel should play ONLY the
  cinema view (just the video, no cover-art layer).
- Fix: applyPlBackdrop toggles .pl-mirror-cinema on the playlist circle when mirror AND
  there's a video source. CSS hides the cover-art (#plCover) under that class, so the
  panel shows only the (filling, synced) video = cinema view. Tracks without a video, or
  with the video layer off, fall back to the cover. Independent (mirror off) keeps both
  layers as before.
- v157->v158; node --check OK; served v158 confirmed.
## Entry 43 — mirror = full cinema view (video + cover), no switching (DONE, v159)
- User: (1) couldn't see the cover art in the panel (v158 hid it) — wants it mirrored
  (the cinema view HAS cover art behind the video). (2) When the main player reveals its
  controls (cinema off) the panel switched to the non-cinema view — it should keep
  playing the cinema view. (3) Mirror = cinema view only.
- Fix 1: reverted v158 — removed the .pl-mirror-cinema hide-cover class + CSS, so the
  cover art shows in mirror mode (mirrors the main cover via --art-*).
- Fix 2: syncPlMirror now mirrors the panel VIDEO from --cover-* ONLY while the main
  player is in cinema (.cinema on). When the main reveals controls (cinema off) the panel
  video FREEZES on the last cinema framing — so it keeps playing the cinema view instead
  of jumping to non-cinema. The cover art always mirrors --art-* (constant, never
  switches). Signature cache retained.
- v158->v159; node --check OK; served v159 confirmed.
## Entry 44 — keep 12% overlap, hide the grey panel from the overlap (DONE, v160)
- User: KEEP the 12% main-over-playlist overlap (do not change). Just kill the dark grey
  anomaly that appeared on the playlist's left edge when the main controls revealed
  (cinema off), cutting off the playlist's media.
- Cause: the main player (z-index 10) overlaps the playlist; when cinema disengages its
  dark wave panel (.dash::before/::after) becomes visible and bled through the overlap
  onto the playlist.
- Fix: when the playlist is open, clip the main player's .dash (panel + scalloped cap +
  controls) out of the overlap region: clip-path: inset(0 calc(--overlap-fraction*100%) 0 0).
  The video + cover-art (siblings of .dash, separate layers) still overlap — seamless in
  mirror mode because it's the same media. So the grey panel never shows on the playlist,
  but the 12% overlap is preserved.
- v159->v160; served v160 confirmed (overlap-fraction still 0.12).
## Entry 45 — full wave panel + no grey anomaly (revert clip, fill video) (DONE, v161)
- User: v160's dash clip cropped the wave panel + progress bar in the main player AND the
  grey anomaly still showed in the playlist. Want a FULL wave panel (no cropping) AND no
  dark grey anomaly cropping the playlist media.
- Root cause (real): the anomaly was NOT the dash panel. When cinema disengages, the main
  video's --cover-scale reset to 1 (nt.coverScale || 1, untweaked) -> letterboxed -> the
  main player's dark background (#252c36) showed through the bars in the 12% overlap onto
  the playlist = the grey anomaly.
- Fix 1: reverted v160's .dash clip-path (wave panel + progress bar are full again).
- Fix 2: engageCinema disengage now uses nt.coverScale || computeCoverFillScale() || 1, so
  an untweaked video stays FILLED out of cinema (no letterbox bars, no background bleed).
  Tweaked repositioning still respected. Overlap stays 0.12 (untouched).
- v160->v161; node --check OK; served v161 confirmed.
## Entry 46 — fix grey anomaly: playlist rises above main when controls reveal (DONE, v162)
- User: anomaly persists in MIRROR MODE only — dark grey cropping the playlist's media
  when the main controls reveal. Full wave panel required (don't crop). 12% overlap kept.
- Root cause: the main player (z-index 10) overlaps the playlist (z-index 5). When cinema
  disengages, the main's dark wave panel (.dash) becomes visible and bleeds through the
  12% overlap onto the playlist's media. Can't clip the panel without cropping the wave
  panel (same pixels). Can't change the overlap (user said don't change).
- Fix: DYNAMIC Z-ORDER. When cinema is OFF (controls visible), raise the playlist circle
  ABOVE the main (body.pl-front -> .playlist-circle z-index: 11 > main's 10). The
  playlist's media then covers the main's panel in the overlap — seamless in mirror mode
  because the playlist video is the same as the main's. When cinema re-engages, the main
  goes back on top (normal overlap). engageCinema toggles body.pl-front = !on.
- v161->v162; node --check OK; served v162 confirmed.
## Entry 47 — grey anomaly: video must fill (>= fill) on cinema disengage (DONE, v163)
- User: anomaly persists in MIRROR MODE only. Do NOT raise playlist over main. Everything
  as-is, just kill the grey.
- Root cause: cinema ENGAGE can save coverScale=1 (before the video's fill has computed).
  Then DISENGAGE used `nt.coverScale || fill` — but `1` is truthy, so it short-circuited
  and used 1 → letterboxed video → dark cover/background showed through the overlap → grey.
  v161's `||` was the wrong operator.
- Fix: `cs = Math.max(nt.coverScale || 1, computeCoverFillScale() || 1)` — ensures the
  video scale is ALWAYS >= fill on disengage. No letterbox bars, no dark bleed-through.
  Reverted v162 (z-index raise) per user instruction. Overlap stays 0.12 (untouched).
- v162->v163; node --check OK; served v163 confirmed.
## Entry 48 — restore cinema/non-cinema independent framing, no grey (DONE, v165)
- User: v164 fixed the grey but removed the independent framing. Want both: independent
  cinema/non-cinema video framing AND no grey anomaly.
- Fix: restored the transform swap in engageCinema, but with Math.max(scale, fill) on
  BOTH save AND apply (4 places). The original grey bug was the swap saving coverScale=1
  (pre-fill) and replaying it → letterbox → dark bleed-through the overlap. Now the
  saved AND applied scale is always >= fill → no letterbox, no grey. The user can
  reposition/zoom independently in cinema (saved to t.cinemaTransform) vs non-cinema
  (saved to t.transform), as before.
- v164->v165; node --check OK; served v165 confirmed.
## Entry 49 — cinema repositioning lost on toggle: persist + skip cinema during drag (DONE, v166)
- User: reposition the video in cinema → works fine → mouse over (controls) → mouse off
  (cinema re-engages) → repositioning LOST.
- Root cause: the overlay drag (Video tools → Reposition, toggleDragMode 'cover') had two
  gaps: (1) onUp did NOT call persistCoverTransform(), so the repositioned --cover-dx/dy
  were never saved to t.cinemaTransform; the swap's save at disengage could miss them if
  the cinema mousemove handler interfered. (2) the overlay drag did NOT set
  state._videoDragActive, so the cinema mousemove handler ran during the drag and could
  toggle cinema (engage/disengage swap) mid-drag, corrupting the saved transforms.
- Fix: startDragMode now sets state._videoDragActive = true for 'cover' mode (cinema
  handler skips during the drag). endDragMode clears it. The overlay onUp now calls
  persistCoverTransform() for 'cover' mode, explicitly saving the repositioned values
  to t.cinemaTransform (or t.transform if not in cinema) so the swap restores them.
- v165->v166; node --check OK; served v166 confirmed.
## Entry 50 — remove fragile swap; reliable repositioning/zoom + no grey (DONE, v167)
- User: v165/v166 swap broke repositioning/zoom (Math.max blocked zoom-out; swap
  corrupted values across cinema toggles). Non-cinema persistence regressed.
- Root cause: the JS transform swap in engageCinema was fundamentally fragile. Saving
  coverScale pre-fill (1) and replaying it caused grey; Math.max(scale, fill) to fix
  the grey blocked legitimate zoom-out; the rapid engage/disengage by the cinema
  mousemove handler could corrupt saved transforms mid-session.
- Fix: REMOVED the swap entirely from engageCinema (back to v164 approach — just toggle
  .cinema class). The video uses ONE set of vars (--cover-*) in both cinema and non-cinema
  states. Repositioning/zoom changes --cover-* and persists via persistCoverTransform
  (v166's onUp addition + drag handlers). The cinema handler skips during overlay drag
  (v166's _videoDragActive). No swap = no corruption, no grey, zoom-out works, persistence
  works. Trade-off: no independent cinema vs non-cinema framing (same look in both states).
  Can be added later via CSS-variable approach (separate --cinema-* vars switched by the
  .cinema class — no JS swap needed).
- v166->v167; node --check OK; served v167 confirmed.
## Entry 51 — cinema checkbox engages/disengages directly; engages on load (DONE, v168)
- User: "Lost the non-cinema view." Cinema box checked on load but no cinema view.
  Toggling a couple of times eventually engages. "If the box is checked Cinema view
  should be on."
- Root causes: (1) The checkbox handler only DISENGAGED on uncheck — checking the box
  did nothing (no engageCinema(true)). (2) loadTrack called engageCinema(false) at the
  start but never re-engaged at the end for cinema-enabled tracks. (3) The mouseleave
  handler required !state.master.paused to re-engage — so a paused video wouldn't
  re-engage cinema.
- Fix: (1) Checkbox handler now calls engageCinema(true) on check. (2) loadTrack now
  engages cinema at the end if cinemaEnabledForTrack() is true (regardless of play state).
  (3) mouseleave re-engages cinema if cinemaEnabledForTrack() — removed the !paused gate.
  Now: checkbox checked → cinema on (immediately, on load). Unchecked → cinema off
  (controls visible = the non-cinema view).
- v167->v168; node --check OK; served v168 confirmed.
## Entry 52 — independent cinema/non-cinema framing via CSS vars (DONE, v174)
- User: "I have no zoomable, repositionable, non-cinema view. When I move the video
  with the control panel visible it moves the cinema view."
- Root cause: v167 removed the JS swap, so the video used ONE set of vars (--cover-*)
  in both cinema and non-cinema. Repositioning in one state moved the video in both.
- Fix: SEPARATE CSS VARIABLES — no JS swap needed.
  * CSS: `.music-player.cinema > .album` uses `var(--cinema-dx, var(--cover-dx))` etc.
    (fallback to --cover-* so the default look is the same until repositioned).
  * JS helper: `coverVar(suffix)` returns '--cinema-' or '--cover-' prefix based on
    .cinema class. All drag/zoom/persist handlers now use coverVar('dx'/'dy'/'scale')
    so they write to the correct var in each mode.
  * loadTrack: sets BOTH --cover-* (from t.transform) and --cinema-* (from
    t.cinemaTransform, or copies --cover-*) — so the fallback is never used once
    loaded; both are independent from the start.
  * applyCoverAutoFill: sets BOTH --cover-scale and --cinema-scale to the fill.
  * engageCinema: NO swap (just toggles .cinema). The CSS handles the switch.
  * persistCoverTransform: reads via coverVar, saves to t.cinemaTransform or t.transform.
- Result: reposition/zoom in non-cinema = --cover-* (doesn't affect cinema).
  Reposition/zoom in cinema = --cinema-* (doesn't affect non-cinema). Both persist.
  No grey anomaly (no JS swap to corrupt values).
- v173->v174; node --check OK; served v174 confirmed.
## Entry 54 — independent visualiser framing for cinema/non-cinema (DONE, v179)
- User: "add visualisers to the Cinema view. I need to reposition/zoom them independently
  for cinema view without affecting non-cinema."
- Implemented using the same --viz-*/--viz-cinema-* CSS variable pattern as the video:
  * CSS: .viz-canvas and .viz-canvas-3d now have transform: translate(var(--viz-dx,0),
    var(--viz-dy,0)) scale(var(--viz-scale,1)). .music-player.cinema overrides with
    var(--viz-cinema-*, var(--viz-*)) fallback.
  * JS: vizVar('dx'/'dy'/'scale') returns --viz-cinema-* in cinema, --viz-* otherwise.
  * Drag mode 'viz' added to startDragMode (onDown/onMove/onDbl/onWheel/onUp).
  * persistVizTransform() saves to t.vizTransform (non-cinema) or t.vizCinemaTransform (cinema).
  * loadTrack + crossfade handover restore both sets of vars from saved data.
  * Editor: "Visualiser framing" section with Reposition button, Reset button, and
    Visualiser zoom slider — all cinema-aware (write to the correct var set).
- v178->v179; node --check OK; served v179 confirmed.

## Entry 55 — 3D rollercoaster visualiser no longer pixelates on zoom (DONE, viz3d v139)
- User: "When I zoom in on the rollercoaster 3d visualiser it starts to pixelate.
  Can you make it so that when I zoom in it keeps its visual integrity?"
- Root cause: the WebGL drawing buffer was sized to the canvas's BASE CSS size only
  (top half of the player), and never re-sized when the --viz-scale CSS transform
  enlarged the canvas on screen. So zooming in via the CSS transform just STRETCHED
  the fixed-resolution pixels => pixelation. The pixel-ratio cap (1.5) made it worse
  the more you zoomed (effective res = 1.5/(dpr*scale) drawing px per device px).
- Fix (viz3d.js only):
  * New `effectiveVizScale()` — reads the cinema-aware --viz-cinema-scale / --viz-scale
    CSS var off the player (mirrors the main script's vizVar() logic).
  * `layout()` now sizes the drawing buffer = base CSS size × zoom scale (BW/BH),
    so after the CSS transform enlarges the element there is ~1 buffer pixel per
    displayed pixel at every zoom level. Camera aspect still uses the BASE W/H
    (both dims scale equally) so framing is unchanged.
  * `layout()` also syncs `composer.setPixelRatio(pr)` so the bloom composer's
    render targets match the canvas backing-store ratio (scene + bloom render at
    full res instead of being upscaled soft onto the larger canvas).
  * `loop()` reads effectiveVizScale() each frame and only re-runs layout() when it
    actually changed — catches ALL zoom sources (editor slider, mouse wheel,
    double-click reset, track load, crossfade, cinema toggle) with no per-call-site
    wiring, and the steady-state cost is one cheap style read per frame.
- camera FOV/aspect and the per-frame `renderer.getDrawingBufferSize(bloom.resolution)`
  sync are untouched, so the ride's look is preserved — just crisper when zoomed.
- Cache-bust: viz3d.js?v=138 -> v139 in index.html + dev.html (script.js v184 unchanged).
- node --check OK; served v139 + Cache-Control no-store confirmed.

---
## Entry S21 (2026-08-20) — Build the rest of the playlist plan (Coaster + Edge on playlist)

**User:** "the Coaster-on-playlist and edge-modes-on-playlist are the remaining items from the parity
plan, ready to build when you say." → "Build the rest of the playlist plan"

**Done:**
1. viz3d.js multi-instance refactor (`_boot(host, opts)` + `createInstance` factory). Main instance
   = `window.RoundViz3D` (backward compat). PL instance via `.create('playlistCircle', {...})`.
   opts: heightFraction, scaleMode ('viz' cinema-aware / 'pl' reads --pl-viz-scale), canvasClass,
   fogClass, colorHost. Coaster math unchanged.
2. PL Coaster integration: startPlCoaster/stopPlCoaster/plCoasterTick; applyPlViz handles
   plMode==='coaster'; togglePlaylist pauses/resumes with the disc; .pl-viz-canvas-3d +
   .pl-viz-fog-layer CSS (full circle, --pl-viz-* framing, mix-blend screen).
3. PL Edge: ensurePlEdgeCanvas/sizePlEdgeCanvas/plEdgeTick/applyPlEdgeViz; reuses 8 edge draws via
   settings+state swap (own plEdgeAnalyser, own ripple/particle/bass state); .pl-edge canvas glides
   RIGHT, z-4 behind disc, opacity:var(--open).
4. New viz.plEdge* settings + VIZ_DEFAULTS + per-track persistence. Editor UI: Coaster option in
   vizPlMode + full "Playlist edge / rim" section (vizPlEdgeMode + settings/custom colours).
5. Versions: script.js v207, styles.css v198, viz3d.js v140. round-music-player-v207.zip built.

**Tests:**
- node --check: script.js + viz3d.js OK.
- viz3d.js in Node with functional three.js mock + jsdom DOM: 27/27 multi-instance checks
  (independent instances, correct hosts, backward-compat API, coaster math runs — seam closes).
- dev.html jsdom smoke test: 8/8 DOM integration checks, 0 runtime errors.

**Note:** no headless Chromium + WebGL in sandbox, so not browser-verified here; user to hard-refresh
and confirm coaster renders in the playlist disc + edge rims pulse around it.
