# Beat-Pulse Artwork — Deep Dive & Implementation (Phase 2)

## The problem with the v1 pulse
v1 was **grid-based**: it computed `phase = (currentTime - offset) % beatPeriod` from the
offline-detected BPM and pulsed on a fixed schedule. So it (a) kept ticking through
breakdowns/ambient sections, (b) drifted if the detection was off or tempo varied, and
(c) never reacted to dynamics. It was a metronome, not a reaction.

## The goal
Artwork **swells on real drum hits**, **settles between hits**, and **goes still** when
there's no beat (breakdown, ambient pad, quiet intro/outro, silence). Restart in time
when the drums return.

## Approach chosen: A — bass-band energy envelope (real-time, analyser-driven)
Per animation frame, using the shared `AnalyserNode` (already wired for visualisers):

1. **Bass level** — average the lowest ~6 FFT bins (≈80–520 Hz @ fftSize 512) → `bass` (0–1).
   This is where the kick drum's energy lives.
2. **Adaptive normalization** — a running `_bassPeak` (chases loud hits fast, decays slow)
   and `_bassFloor` (drifts with the quiet baseline). `lvl = (bass − floor) / (peak − floor)`.
   This makes it work across loud/quiet tracks with NO per-track tuning.
3. **Attack/decay envelope** — one-pole: fast attack (coef ~0.5, snaps outward on the hit),
   slower decay (coef ~0.12, settles after). This is the satisfying "thump".
4. **Silence/beat gate** — `targetGate = 1` only when there are real dynamics
   (`peak − floor > 0.05` AND `peak > 0.05`); else 0. Eased (`coef 0.06`) so it starts/stops
   smoothly. **This is what makes it stop when there's no beat.**
5. **Drive** — `--beat-pulse` (scale, 1.5–7%) and `--beat-flash` (brightness, 5–25%) on `.album`.

Result: on every kick the art snaps out + brightens, relaxes between kicks, and freezes at
rest during quiet sections — genuinely "in time with the drums", no BPM dependency, no drift.

## Why this beats the alternatives here
- **No drift / no false pulse**: it's driven by actual audio energy, not a free-running grid.
- **No offline-BPM dependency**: works even if `t.bpm` wasn't detected (reacts to audible
  drums directly). BPM still powers beat-synced transitions separately.
- **Honest on CORS**: if the analyser returns zeros (remote track without CORS), it simply
  stays still instead of faking a pulse.
- **Cheap**: ~6 bins + a few floats per frame on an existing rAF.

## Alternatives considered (documented for later)
- **B** spectral-flux onsets — discrete event pulses (also catches snares); heavier.
- **C** live beat-tracking — gold-standard lock; heavy/complex; overkill now.
- **D** hybrid energy + BPM grid — energy confirms predicted beats; most stable sustained
  feel. A natural Phase-3 upgrade if we want a perfectly even "heartbeat" on steady sections.
- **E** RMS/loudness — reacts to everything, not the drums; rejected.

## Tunables (in `beatPulseLoop`)
peakRise 0.35 · peakDecayCoef 0.01 · floorCoef 0.004 · attack 0.5 · decay 0.12 ·
gateCoef 0.06 · gate thresholds (range 0.05, peak 0.05). Strength slider scales depth.
