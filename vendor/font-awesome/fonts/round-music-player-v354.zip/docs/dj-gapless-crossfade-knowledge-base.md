# DJ-Style Gapless & Crossfade Playlists — Knowledge Base & Action Plan
### For the Round Music Player

Compiled: 2026-08-08 · Sources: web research (gapless mechanics, crossfade curve theory, DJ software landscape, DJ community workflows) — full list at the bottom.

---

## 1. Executive summary

The Round Player already ships a basic gapless mode (v65: preloads the next track + instant switch). This document is the deep dive needed to turn that into a **professional transition engine**: per-transition crossfade durations (your 0–88s idea), beat-synced blends, and the DJ workflow features (BPM/key/energy, cue points, smart crates) that pros expect.

**Three ideas at the heart of it:**
1. **Gapless ≠ crossfade.** Gapless = zero gap, exact original timing (album/live-record continuity). Crossfade = intentional overlap that *modifies* the audio. A single slider from 0 (gapless) to N seconds (blend) is exactly the right model — 0 must mean *true* gapless, not "tiny gap".
2. **Per-transition crossfades are a real, professional pattern.** DJs save "transition tests" crates and rehearse specific blends between specific pairs. Storing a duration per adjacent pair in the playlist is the right data model — and it's cheap to implement.
3. **Seconds are only half the story; beats matter.** In club music, blends are measured in **bars** (8–32 bars is the norm), not seconds. A beat-synced crossfade (duration expressed in beats, converted via the track BPM) is what separates "consumer" from "pro".

---

## 2. Gapless playback — the mechanics

### Why gaps happen
| Cause | Typical size | Notes |
|---|---|---|
| Decoder latency (load + decode + buffer the next track) | 100–500 ms | The dominant cause in naive players |
| MP3 encoder delay/padding ("priming") | ~576–1152 samples (~13–26 ms @44.1 kHz) | LAME tags store exact values; decoders without tag support leave the silence |
| AAC priming | 1024–2112 samples (~23–48 ms) | iTunSMPB tag in MP4; varies by encoder (FFmpeg 1024, FDK-AAC 2048) |
| Audio device buffering / driver switch | varies | WASAPI-exclusive avoids it; Bluetooth adds it |

### Format reality
- **FLAC / ALAC (lossless)** — inherently gapless (sample-exact, no padding).
- **Ogg Vorbis / Opus** — native gapless (precise end trimming, Vorbis uses exactly one priming frame, Opus near-zero delay).
- **MP3** — gapless *only* if the player trims the LAME-encoded delay/padding (or the "detect silence" kludge).
- **AAC/M4A** — gapless via iTunSMPB tag; unreliable in generic web decoders.

### The true-gapless recipe
1. **Pre-buffer** the next track while the current plays (already done in v65).
2. **Seamless switch** — the transition must not stop/reopen the audio output.
3. **Encoder-delay compensation** — trim priming samples.
4. **Continuous output stream** — the audio device stays active.

### Web Audio implementation reality
- **Best quality path**: `decodeAudioData()` each track into an `AudioBuffer`, play via `AudioBufferSourceNode` with **sample-accurate scheduling**:
  ```js
  out.stop(switchTime);
  in.start(switchTime, startGapSeconds);   // startGap trims encoder priming
  ```
- **Streaming path (current player)**: two `<audio>` elements + preload + switch at `currentTime` boundary. Decoder latency makes this "seamless-ish" rather than sample-exact — acceptable for most use, imperfect for purists.
- The player already routes both audio + video through one Web Audio graph (master gain + analyser) — the **dual-element engine plugs straight into that graph**.

### How to test gaplessness
- **Sine-wave boundary test**: two tracks with a continuous sine spanning the boundary — any click/pop/interruption = not gapless.
- **Live-album applause test**: applause spanning a track boundary must not cut out.

---

## 3. Crossfades — curves, durations, DJ practice

### The two classic curves
| Curve | Midpoint gains | Midpoint level | When to use |
|---|---|---|---|
| **Equal-power** (cos/sin) | 0.707 each | −3 dB, constant power | Default for music (uncorrelated signals) — no dip |
| **Equal-gain** (linear) | 0.5 each | −6 dB (power dips) | Correlated material (identical loops, mono stems) |
| Hann / S-curve | ~0.5–0.7 | smooth | Extra-gentle fade-outs; rarely for crossfades |

The pro rule of thumb: **equal-power by default; switch to equal-gain if you hear a volume bump/dip**. DJ software (Serato, VirtualDJ) exposes exactly this as crossfader *curve* options (sharp for scratching, slow/smooth for mixing; VirtualDJ even lets you draw a custom curve).

### Duration practice (seconds vs bars)
- **0.5–5 s** — masks buffering/decoder seams; the "consumer crossfade".
- **8–32 bars** — the standard DJ blend length. At 124 BPM: 8 bars ≈ 15.5 s, 16 bars ≈ 31 s, 32 bars ≈ 62 s.
- **Minutes** — ambient/drone "layered" mixes; rare but real.
- **Your 88 s idea**: ≈ 45 bars @124 BPM — a *very* long blend. It works for ambient/outro-lead-in contexts, and for loop-based styles where the outgoing track's outro and incoming track's intro are both instrumental. With mismatched tempos/keys it will sound messy — which is exactly why beat-syncing (Section 4) matters. Recommendation: keep the range 0–90 s (or 0–64 bars in beats mode) so 88 s is available but the default presets are musical.

### Beat-synced crossfade (the pro feature)
Duration is set **in beats/bars**, converted per-transition using the outgoing (or average) track BPM: `seconds = bars × 4 × 60 / BPM`. A 16-bar blend then *stays* 16 bars whether the track is 120 or 140 BPM. This is what DJ software's "auto-mix length" does.

### Per-transition storage — the data model
```
track list:  [T0, T1, T2, T3, …]
transitions: { '0→1': {fade: 0,  curve: 'equal-power', beats: null },
               '1→2': {fade: 15.5, curve: 'equal-power', beats: 8},
               '2→3': {fade: 88,  curve: 'equal-power', beats: null} }
```
- Stored per adjacent pair (persisted with the playlist + server theme, like per-track themes).
- A **global default** applies to pairs without an override (0 = gapless).
- "Apply to all" button copies the current setting to every transition.

---

## 4. The DJ software landscape (what the pros use)

| Software | Role | Relevant features |
|---|---|---|
| **Rekordbox** (AlphaTheta/Pioneer) | Club-booth standard | Beatgrids, hot cues, memory cues, loops, **intelligent playlists by BPM/key**, phrase analysis, USB/CDJ export |
| **Serato DJ Pro** | Controller/DVS | **Smart crates (rule-based)**, key/BPM columns, scratch, crossfader curves |
| **Traktor Pro** | Creative/electronic | Beat-sync, quantize, loops, **STEMS** (mix stems independently), FX chains |
| **VirtualDJ** | Flexible/mobile | Video mixing, **custom crossfader curves**, automix |
| **DJ.Studio** | Timeline mix *preparation* | Automix/harmonize (order by key/BPM), **energy curves**, stems, transition auditioning, export |
| **SetFlow** | Web set generator | Import library → generate sets by harmonic mixing + BPM matching + energy |
| **Web libraries** | BPM/key analysis in-browser | `realtime-bpm-analyzer` (AudioWorklet, zero-dep, file/stream/mic), `pulse.js`, `music-beat-detector` — **client-side BPM detection is proven** |

---

## 5. What DJs & EDM fans want (requirements & wishes)

From DJ community threads (r/DJs, r/Beatmatch), prep guides (DJ.Studio, Vibes, Mixed In Key) and feature lists:

### Playlist / set construction
1. **BPM + key visible on every track** — the two columns every DJ checks first.
2. **Harmonic mixing guidance** — Camelot wheel (8A→9A→8B micro-moves; same/adjacent for smooth blends, big jumps only for resets).
3. **Energy tagging (1–10) + energy arcs** — a set is a story: opening → peak → closing; plan the arc, not just the order.
4. **Smart crates / filters** — auto-assemble pools by BPM band + key family + energy ("any pick from this crate just works").
5. **"Transition tests" crate** — save blends that worked (both directions!), with the per-transition settings that made them work.
6. **Cue points & phrase alignment** — mark intros/outros/drops; align blends to 8/16/32-bar phrases (DJs prep 60–70 tracks per hour of set, in crates).
7. **Next-track suggestions** — "what mixes well into this?" (key/BPM/energy compatible) — the SetFlow/DJ.Studio automix idea, offline and lightweight.
8. **Pack-of-4/5 playlists + mini-routines** — reusable micro-sets.

### Transition engine
9. **Per-transition control** — exactly your idea: remember what blend length (and curve) works between each specific pair.
10. **Beat-synced blending** — durations in bars, BPM-aware.
11. **Curve selection** — equal-power default, equal-gain option (per transition or global).
12. **Tempo handling on blend** — options: instant speed change at the switch, or gradual tempo ramp during the crossfade (the "DJ pitch-rider" feel), or tempo-lock (no pitch change) — pros differ; expose a choice.
13. **Loop-friendly transitions** — if a track has a saved loop (e.g. 8-bar outro loop), the blend can loop the outro until the incoming track is phrase-ready.

### Analysis & data
14. **BPM auto-detection** (client-side, proven libraries exist).
15. **Key auto-detection** (harder; honest options: client-side chromagram estimate, manual entry, or import from Mixed In Key / Rekordbox tags).
16. **Waveform overviews** in the playlist to spot intros/outros/drops at a glance.
17. **Phrase/intro-outro markers** — energy-envelope analysis or manual cue points.

---

## 6. Design proposal for the Round Player

### The transition engine (core)
- **Two media elements** (A/B) fed into the existing Web Audio graph (master gain → analyser). One plays; the other preloads during the last ~10 s (gapless) or at `transitionStart - fade` (crossfade).
- **State machine**: `idle → preload → arm → blend → handover → idle`.
- **On 'ended'** (or at the arm point): apply the transition for the pair:
  - `fade === 0` → hard switch at the boundary (true gapless via prebuffer; sample-accurate scheduling when decoded buffers are used).
  - `fade > 0` → equal-power (or equal-gain) ramp: out gain 1→0, in gain 0→1 over `fade` seconds, starting `fade` seconds before the boundary.
  - **beats mode**: `fade = bars × 4 × 60 / BPM` computed live.
- **Curve**: per-transition `curve: 'equal-power' | 'equal-gain'` (global default equal-power).

### Data model (persisted with the playlist)
```
track.viz / track.theme / ...  (existing per-track config)
track.transition = { out: { fade, curve, beats, tempoMode } }   // to the NEXT track
```
Plus a `global.transitionDefault` in the Global settings. Shuffle/loop-one bypass transitions (or use the global default).

### UI
- **Global tab**: "Transition default" — slider 0–90 s (0 = gapless) + curve select + beats/bars toggle + tempo-mode select.
- **Playlist Manager**: per-transition column/row — a small "⧉" button per track row opens the transition editor for that pair (fade slider with live 0/gapless marker, curve, beats, "apply to all", copy-paste transition presets).
- **Deployed player**: honors saved transitions silently.

### Analysis (phased)
- BPM column (auto-detected on upload via vendored `realtime-bpm-analyzer`), editable.
- Key column (manual / imported / estimated), Camelot-compatible coloring.
- Energy column (1–10, manual or auto-estimate).
- Smart filters in the manager (BPM range + key family + energy).
- Next-track suggestion (key/BPM/energy compatibility score, using only the local playlist).

---

## 7. Actionable implementation steps

**Phase 1 — Transition engine (foundation, ~1 day)**
- [ ] **TR-01** Dual-element A/B engine: second `<audio>`, both into the Web Audio graph; state machine `idle→preload→arm→blend→handover`.
- [ ] **TR-02** Per-transition storage: `transition` on each track (to-next), persisted in playlist + server theme; `global.transitionDefault` fallback.
- [ ] **TR-03** True gapless at 0 s: preload + hard switch at boundary (improve the v65 preload into the A/B engine).
- [ ] **TR-04** Equal-power crossfade ramp (0–90 s slider, live), starting `fade` before the boundary; curve select (equal-power default / equal-gain).
- [ ] **TR-05** UI: Global default slider + per-transition editor in the Playlist Manager (per-row ⧉, "apply to all", copy/paste presets).
- [ ] **TR-06** Tests: sine-boundary gapless test, crossfade gain-math assertions, per-transition persistence + deployed inheritance.

**Phase 2 — Beats & tempo (1–2 days)**
- [ ] **TR-07** Vendor `realtime-bpm-analyzer` (AudioWorklet, zero-dep) — auto BPM on upload + editable BPM per track.
- [ ] **TR-08** Beat-synced transitions: bars-based duration → seconds via BPM; beats/bars toggle in UI.
- [ ] **TR-09** Tempo mode on blend: instant / gradual ramp during fade / tempo-lock (playbackRate with pitch preservation).

**Phase 3 — Analysis & smart playlists (2–3 days)**
- [ ] **TR-10** Key column: manual + import (Mixed In Key / Rekordbox tag parse) + optional client-side chromagram estimate; Camelot display.
- [ ] **TR-11** Energy column (1–10) manual + simple auto-estimate (RMS/spectral envelope).
- [ ] **TR-12** Smart filters in the manager (BPM band, key family, energy) — the "smart crate" idea.
- [ ] **TR-13** Next-track compatibility suggestions (key/BPM/energy score against the current track).

**Phase 4 — Pro workflow extras (later)**
- [ ] **TR-14** Cue points per track (jump-to + labels) + phrase/intro-outro markers (manual first).
- [ ] **TR-15** Loop-aware transitions (blend while looping the outro).
- [ ] **TR-16** Waveform overview strip in the playlist (decoded-buffer peaks).
- [ ] **TR-17** "Transition tests" mode — practice view listing saved blends; export/import transition presets.
- [ ] **TR-18** Automix / set-planning view (energy arc + key chain visualization).

---

## 8. Sources
- **Gapless**: Grokipedia "Gapless playback"; Auris Journal "Gapless Playback: What It Is and How It Works"; Vimeo Engineering "A brief history of gapless audio"; Jake Archibald "Sounds fun" (Web Audio sample-accurate scheduling, priming); StackOverflow AAC priming/decoding
- **Crossfade curves**: CMUSE Equal-Power Crossfade Calculator (gains/dB table); DSP StackExchange "Equal power crossfade" (formulas); r/audioengineering "what kind of fades do you use" (equal-gain vs equal-power practice); r/Beatmatch "Crossfader Curves in Serato"; VirtualDJ VDJPedia "Crossfader Curve"
- **DJ software**: DJCU (Rekordbox/Serato/Traktor conversion — cues, loops, beatgrid, crates); SetFlow "Rekordbox vs Serato vs Traktor"; DJ.Studio blog (set preparation workflow, mixing feature cheat sheet, community-trusted software guide); Rekordbox/Serato/Traktor docs referenced therein
- **DJ workflows & wishes**: r/DJs "How exactly do you plan sets?" (crate sizes, mini-routines, smart crates, pack-of-4/5); musicianstool.com "Building the Perfect DJ Set" (energy arc, BPM flow, key compatibility); Vibes "Track Selection for DJs" (8–32 bar intent, cue points, transition tests); DJ.Studio "DJ Set Preparation: The Complete Modern Workflow" (harmonic smart crates, energy lanes)
- **Web analysis libraries**: realtime-bpm-analyzer (npm); pulse.js (GitHub); music-beat-detector (GitHub); BeatDetektor
