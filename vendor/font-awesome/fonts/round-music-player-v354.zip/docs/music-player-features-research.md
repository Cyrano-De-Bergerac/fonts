# Music Player Features — Research Report
### For the Round Music Player ("the ultimate deployable web music player")

Compiled: 2026-08-07 · Sources: web research (player libraries, plugins, browser docs, user forums) — full source list at the bottom.

---

## 1. The benchmark: what the great players had

### Winamp (1997–) — the feature king people still miss
Winamp is repeatedly cited as the gold standard for player features. Its catalogue:

- **Skins / shape-changing UI**: classic skins (bitmap layouts) AND "modern/freeform" skins with alpha transparency, region files, and scripted layouts — i.e. the player UI itself could be **any shape**, not a rectangle.
- **Visualisations**: AVS (Advanced Visualization Studio) + Milkdrop 2 — infinitely customisable, audio-reactive, fullscreen.
- **Plugin system**: input codecs, DSP/effects, general-purpose (alarm clock, media library, pause-on-logout…), visualisation, portable-sync.
- **10-band graphic EQ** with presets + saveable custom settings; balance/panning.
- **Crossfade and gapless playback** (MP3/AAC), **ReplayGain** (volume leveling across tracks).
- **Formats**: MP3, WAV, AAC, M4A, FLAC, OGG Vorbis, WMA, MIDI, MOD, MP2 + video.
- **Media Library** with smart views (dynamic playlists), auto-tagging, album art, artist info, recommendations.
- **Streaming radio**: SHOUTcast (30,000+ stations), podcast support.
- **Windowshade mode** (collapse to a thin bar), notification popups, language packs.

### VLC Media Player (videolan.org) — the "plays everything" utility player
The most-used open-source player; ~100+ million users. Its catalogue:

- **Universal format playback** — MP3, FLAC, AAC, WAV, OGG, M4A, WMA, OPUS, AIFF + every video codec (H.264/H.265/VP9/AV1), DVDs, Blu-rays, CDs, network streams. **No codec packs, no plugins needed.**
- **10-band graphic EQ** with **18 presets** (Flat, Classical, Club, Dance, Full Bass, Full Treble, Headphones, Large Hall, Live, Party, Pop, Reggae, Rock, Ska, Soft, Soft Rock, Techno) + preamp slider; changes apply **live, in real time**.
- **Full audio-effects toolkit**: compressor (dynamic range), spatializer (simulated room), stereo widener, **pitch shifter**, parametric EQ, **headphone virtual spatialization (7.1)**, channel remapper, stereo→mono downmix, sound delay, volume normalizer, gain control, **simple karaoke filter (vocal reduction)**.
- **ReplayGain** (track AND album modes) + **volume normalisation to a target dB** that persists across sessions.
- **Volume boost beyond 100%** (up to ~200%+) without losing clarity — a beloved VLC quirk.
- **Speed control with pitch preservation** (scaletempo/timestretch) and an option to disable timestretch.
- **Audio track selection, audio device selection, stereo modes** (Mono/Stereo/Left/Right/Reverse).
- **Visualisations**: Goom, libprojectM (Milkdrop), 3D OpenGL spectrum, custom visualizer plugins.
- **Custom hotkeys** — *almost every action* can be rebound; skins (Windows); **Lua extensions** (e.g. auto subtitle download).
- **Playlists** with loop + shuffle; **video filters** (crop, rotate, deinterlace, sharpen, aspect control); **overlay filters** (logo/watermark, text); fun filters (puzzle, psychedelic, mirror, waves, old-movie grain, sepia, B&W); **convert/record** anything.
- **No ads, no spyware, no tracking** — non-profit, publicly refused ad revenue; portable mode for locked-down machines.

**What people love:** plays *anything* when other players fail; free + clean + lightweight; deep customisation (EQ, hotkeys, skins, extensions); volume boost; works offline and portably.

**What people WISH it had** (user gripes): a modern UI / **native dark mode** ("the worst UI of any app I've installed", "stuck in the 90s"); **touch-friendly UI** (bigger buttons for tablets); **thumbnail previews on the seek bar**, frame-by-frame backwards step; better HDR/high-bitrate 4K handling; **true-random shuffle** (VLC's shuffle famously repeats the *same* order every time — same seed!); visible speed/timestretch controls (buried in advanced settings); timestamp bookmarks; "skinless"/borderless mode; no focus-stealing on repeat. **Lesson: power features mean nothing if the UI/UX lags — and a broken shuffle is noticed and mocked.**

### VoiceZam (voicezam.com) — the professional demo/portfolio player
A subscription ($8.95/mo) embeddable web player purpose-built for **voiceover artists** to present demos; the closest thing to a "portfolio-in-a-player".

- **Multi-demo track-list player**: multiple demos (Commercial, Narration, Promo, e-Learning, Telephony/IVR, Jingle…) switchable via a dropdown; every track inside a demo is individually **clickable, auto-playing and downloadable** — buyers jump straight to the spot type they're casting.
- **Downloads a la mode**: one-click download of the **full demo** OR **individual tracks**, with the **track title as the filename**.
- **Contacts view**: professional name, direct contact info, **representation/agent details** (listed in the order the artist chooses), **social media buttons** — the player doubles as a "voiceover calling card".
- **Zamtistics analytics add-on** ($4.95/mo): who listened, how long they listened, exactly which tracks were played, per-track play counts — marketing intelligence for the artist.
- **Full CSS skinning** — every element rendered with CSS so designers can restyle it to match a brand.
- **One-line embed** with step-by-step video tutorials for every major website platform; **instant updates** when new reads are uploaded (no re-embedding).
- Unlimited demos + unlimited reads; works on all smartphones/tablets/desktop; "patented perfect playback".

**What people love:** buyers can preview *exactly* the read they need instead of sitting through a whole demo; per-track + full-demo downloads; contacts/representation right in the player; analytics; easy embed; brandable look.

**What people WISH it had:** **no subscription fee** (the #1 complaint — users hunt for free/self-hosted alternatives like Royal Audio Player); **visible category links** instead of a hidden dropdown (users didn't discover the demo dropdown); visualizer that doesn't interfere with page links (pointer-events/z-index); smoother autoplay on load ("click twice" annoyance on desktop). **Lessons for the Round Player: a portfolio/showcase mode with categories + per-track downloads + contact info + play analytics is a proven, loved pattern — and "no subscription, self-hosted" is the exact opening our deployable player fills.**

### Bandcamp (bandcamp.com) — the indie-artist storefront & discovery network
The direct-to-fan platform for independent music: digital + physical sales, streaming for discovery. Its catalogue:

- **Direct-to-fan marketplace**: artists keep **82–85%+ of revenue** (15% Bandcamp cut on digital, 10% on physical); name-your-price / pay-what-you-want, free-download options; digital (MP3 + **lossless FLAC/WAV** downloads) AND physical (vinyl, CD, cassette) + merch; artist subscriptions/fan clubs (monthly/yearly tiers, exclusive content).
- **Streaming for discovery, purchase for unlimited**: anyone can stream tracks in full before buying, but **artist-set stream limits** (default **3 full plays**) trigger a friendly "support the artist" purchase prompt — the purchase-vs-stream etiquette is built into the platform.
- **Ownership-based playlists (Bandcamp Playlists beta)**: fans can only add tracks they **own** to playlists; listeners sample non-owned tracks up to the limit then get directed to purchase; requires a fan login. "Every playlist is a reflection of real support."
- **Discovery — deliberately NOT algorithmic**: no personalized feed, no "for you", no autoplay queue. Instead: **tag system** (12–16 accurate tags is the working benchmark — genre/subgenre/mood/instrumentation/location), **Bandcamp Discover** (editorial; "surprise me"), **Bandcamp Daily** (editorial magazine, 4–6 features/day), **Bandcamp Weekly radio show** (loved by fans), genre hubs, "bought-together" collaborative-filtering panel ("If you like X, you may also like…"), **public fan collections** (browse what other fans bought — crowdsourced discovery that "works better than any algorithm"), **wishlists**, listening parties, Bandcamp Fridays (revenue-boost days).
- **Fan data**: artists get buyer emails, locations, purchase history — "Bandcamp turns transactions into relationships."
- **Official embed player**: `bandcamp.com/EmbeddedPlayer/album=ID/size=large/…` — iframe widget with size/colour/layout options.
- **API (limited)**: OAuth 2.0 API exists but is **labels/merchandise partners only** (accounts, sales reports, merch orders) — *no public streaming/collection API*. Community tooling fills the gap: **bandcamp-fetch** (Node library that scrapes page metadata — the `data-tralbum` JSON in every album/track page contains title, artist, cover, track list + mp3-128 streaming URLs), **Bandcamp Streamer** browser extension (plays the featured track of every album in your feed = a de-facto genre radio), playlist-streaming sites.

**What people love:** directly supports artists; high-quality lossless downloads; community/editorial discovery; the Weekly radio show; fan collections; no ads, no algorithm.

**What people WISH it had:** a **real radio / continuous-shuffle mode** — the #1 recurring ask ("I'd love to put Bandcamp on in the morning at work and hear music all day"; "why does Bandcamp not have a built-in streaming service?"); **playlists from the browser**; **better recommendation heuristics** ("wish they had better heuristics" — the bought-together panel is hidden and minimal); **weekly digest of followed artists' releases**; more subgenre/new-release surfaces. Fans also complain the *discovery surfaces are hidden* ("the feature is hidden there", "it's there, just not enough") — the "If you like…" panel is at the bottom of album pages, Discover requires digging.

**Lessons for the Round Player:** a self-hosted **"Bandcamp radio"** (pre-curated genre playlists + random picks from tag feeds, streamed through the Round Player with cover/theme/visualisers) directly answers the #1 fan wish; importing a Bandcamp album/track URL into the playlist (title/artist/cover/tracks from the page metadata) is a proven pattern (bandcamp-fetch); and the **purchase-prompt etiquette** (nudge "buy/support" after ~3 plays, per-track Bandcamp links) is both ethically right and ToS-aware — it turns a radio into a discovery funnel that *sends money to artists*, which is exactly Bandcamp's philosophy and a genuinely differentiating stance for a web player.

### Modern references
- **Spotify / Apple Music / YouTube Music (web)**: synced lyrics panels, gapless-ish transitions, smart shuffle, queue management, playback history, Media Session/OS integration, mini-player, liked songs, autoplay radio from any track, cross-device "Connect" control.
- **SoundCloud embeds**: waveform seek bar, comments pinned to timestamps, customisable embed (colour, size, autoplay, show/hide comments/downloads/buy/share), embed analytics ("Insights" play counts).
- **Podcast players (browser)**: RSS import, episode search/filter/pagination, chapter markers, transcripts, playback speed, sleep timer, resume position, subscribe/notifications.
- **WordPress audio plugins** (the closest analogue to "deploy on any website"): shortcodes/blocks, sticky mini-player, skins, drag-reorder playlists, download buttons, skip intervals, stream fallback URLs, per-episode art/metadata, HLS live streaming, state saving (resume), podcast RSS fetch, Google Drive/SoundCloud proxy playback.

---

## 2. Feature catalogue by category

Legend: **[C]** = common in existing players · **[W]** = frequently wished-for / rarely delivered · **[R]** = rare/differentiating

### A. Playback & audio engine
- **[C] Play/pause/stop, next/previous, seek** (scrub bar + click-to-seek)
- **[C] Volume slider, mute, per-track volume**
- **[C] Loop modes** (off / all / one) and **shuffle** (incl. smart shuffle that avoids repeating the same artist)
- **[VLC] True-random shuffle** — VLC's shuffle famously replays the same order every session (same seed); a proper seeded/randomised shuffle is a differentiating quality detail
- **[C] Autoplay** (with the browser's muted-start / user-gesture rules)
- **[C] Playback speed** 0.5×–2× (pitch-corrected)
- **[VLC] Speed with timestretch toggle** — pitch-preserving tempo change with an explicit on/off (VLC users complained the toggle was buried; ours must be visible) + **[VLC] volume boost beyond 100%** (up to 200%, a beloved VLC quirk)
- **[C] Preload strategies** (none/metadata/auto) & buffering indicators
- **[C] Resume playback** — remember position per track/session ("state saving")
- **[C] Crossfade between tracks** (user-controlled duration, incl. 0 = off)
- **[W] Gapless playback** — the single most-requested missing feature across player forums ("essential for concept albums and DJ mixes", "a hard pass without it"). In browsers it needs preloading the next track + Web Audio scheduling; genuinely rare in web players.
- **[C] Fade-in / fade-out** on play/pause and track change
- **[W] ReplayGain / volume normalisation** so tracks don't jump in loudness
- **[C] Keyboard shortcuts** (space = play/pause, arrows = seek, N/P = next/prev, M = mute, +/- volume, F fullscreen…)
- **[C] Repeat-A-B segment** (podcast/learning players)
- **[R] BPM detection** (client-side, from the analyser)
- **[R] Beat-synced scheduling** (via Web Audio clock — tone.js-style)

### B. Formats & codecs (browser reality, 2025)
- **[C] MP3** — every browser.
- **[C] WAV (PCM)** — every browser (the user's ask: zero work, just accept the file).
- **[C] FLAC** — Chrome 56+, Edge 16+, Firefox 51+, Safari 11+ (iOS) / 13+ (macOS), Opera, Samsung Internet — ≈96% of web traffic. Native `<audio>` support; the server just needs to serve `audio/flac`. **FLAC in the browser is a solved problem — no transcoding needed.**
- **[C] AAC / M4A / MP4 audio** — every browser.
- **[C] OGG Vorbis, Opus (WebM/OGG)** — all except Safari (Opus-in-WebM OK on Safari 15+/macOS Monterey+).
- **[R] ALAC, AIFF, DSD** — not supported by `<audio>`; would need server-side transcoding or an Emscripten decoder (heavy). Most web players don't bother; some use `canPlayType()` detection to show graceful "format not supported on your browser" messages.
- **[VLC] "Plays everything" positioning** — VLC's core selling point is universal formats with zero codec packs. A web player can mirror this by accepting every format the browser can decode (`canPlayType()` gate) + a clear unsupported-format notice instead of silent failure.
- **[C] Video as cover media** (MP4/WebM) — already a Round Player feature.
- **[C] `canPlayType()` detection + friendly unsupported-format message** instead of silent failure.
- **[W] .cue sheet support** (track splitting) — mostly a desktop wishlist item.

### C. Visualisation (Web Audio API `AnalyserNode` — canvas/WebGL)
Common modes seen across players (Winamp, web visualisers, streaming tools):
- **[C] Frequency bars** (classic spectrum analyser, EQ-style)
- **[C] Circular / radial** spectrum (bars around a ring — *fits the Round Player perfectly*)
- **[C] Waveform / oscilloscope** (time-domain trace)
- **[C] Smooth spectrum ribbon** (gradient-filled band)
- **[C] Particle field** (audio-reactive particles — bass scatters them)
- **[C] Radial burst** (outward spikes) and **spiral**
- **[R] 3D modes** (WebGL: spectrogram waterfall, morphing spectrum sphere, starfield/galaxy)
- **[C] Per-mode options**: sensitivity/smoothing, FFT size, colour schemes/palettes, glow, background art/transparency
- **[R] Snapshot/export** the visualiser as an image
- **[C] Visualiser sizing**: inline area, fullscreen mode, background of the whole player
- **[C] Audio-reactive cover art** (album art pulses/zooms with the beat — cheap and popular)

### D. Lyrics
- **[C] Synced lyrics panel** with **auto-scroll** (current line highlighted/centred)
- **[C] Click a line → seek to that timestamp**
- **[C] Karaoke mode** — large fullscreen lyrics with word-level highlight
- **[C] LRC file support** (standard `[mm:ss.xx]` lines; "enhanced" LRC has word-level inline tags)
- **[C] Auto-fetch lyrics** from free APIs (LRCLIB — no key needed; Musixmatch; Genius) by title+artist
- **[C] Manual timing offset** (bracket keys ±0.5s/±1s) when sync drifts
- **[C] Manual override**: paste own LRC, manual search, per-track lyrics storage
- **[R] Lyrics translation panel** (dual-language), instrumental-detection
- **[R] AI-generated/transcribed lyrics** from the audio (whisper-style)

### E. Playlists, queue & library
- **[C] Create/edit/reorder** playlists (drag & drop — Round Player has this)
- **[C] Queue** (play-next list separate from playlist)
- **[C] Play history** (recently played, back/forward)
- **[C] Search & filter** the playlist (live frontend search)
- **[C] Sort** by title/artist/duration/likes
- **[C] Like/favourite** tracks (Round Player has liked)
- **[C] Per-track artwork, title, artist, album, tags** (ID3/APIC parsing — Round Player has this)
- **[C] "Play radio from this track"** (auto-generated continuation)
- **[W] Smart playlists** (rules: artist, genre, plays, mood), pinned playlists
- **[W] Folder/artist/album/genre browsing** (library view)
- **[R] Mood/energy detection & auto-playlists** (AI)

### F. UI, design & theming
- **[C] Colour theming / skins** (Round Player: full per-track designer — beyond most)
- **[C] Light/dark mode**
- **[C] Responsive + mobile-friendly**, touch gestures (swipe to change track)
- **[C] Mini-player / compact mode**, sticky/fixed player ("windowshade" idea)
- **[C] Fullscreen mode** (great for visualisers/karaoke)
- **[W→R] Shape-changing player** — round → triangle → octagon → user-generated polygon, with controls re-flowing to fit. Nothing mainstream does this; closest precedents are Winamp freeform skins and CSS `clip-path` morphing. **This would be a genuine differentiator.**
- **[C] Collapsible panels** (playlist/lyrics/visualiser drawers)
- **[C] Custom player sizes**, border radius, shadows, fonts
- **[R] User-generated skin/theme export + import**
- **[C] Notifications**: "now playing" toast on track change
- **[C] Contextual hover states, animated transitions** (Round Player has these)
- **[W] Widgets/lockscreen theming** (mobile app territory)

### G. OS & platform integration (web)
- **[C] Media Session API** — title/artist/album/artwork on the OS lock screen, notification shade, and hardware media keys (play/pause/next/prev/seek). Chrome, Edge, Firefox 82+, Safari. **This is the #1 "makes it feel native" feature for a web player.** Gotchas: metadata only shows while playing; register action handlers in try/catch; provide multiple artwork sizes; update `setPositionState` for the lock-screen scrubber.
- **[C] Keyboard media keys** via Media Session (covered above)
- **[C] PWA** (installable, offline caching of shell + playlists, service worker)
- **[C] Background playback** (PWA + Media Session on mobile)
- **[R] Last.fm scrobbling** (needs an API key; a recurring user wish)
- **[R] Web Share API** (share track link natively)

### H. Embedding & sharing (the "deploy on any website" story)
- **[C] One-line embed** (iframe or `<script>` tag + config object)
- **[C] Config via HTML data-attributes** (Round Player already does `data-audio`, `data-cover`, `data-title`…)
- **[C] Customisable embed options**: colour, size, autoplay, show/hide download, comments, artwork, buy button, share
- **[C] Download button** toggle (Bandcamp-style)
- **[VZ] Per-track download with the track title as filename + "download full playlist/demo"** — VoiceZam's "Downloads a la mode"; buyers grab exactly the reads they need
- **[VZ] Portfolio/showcase mode** — group a playlist into named demos/categories (Commercial, Narration, Promo…) switchable via dropdown or visible tabs (VoiceZam's hidden dropdown was a UX complaint — make categories visible)
- **[VZ] Contacts panel** — professional name, direct contact info, agent/representation details, social-media buttons; the player doubles as a "calling card"
- **[VZ] Play analytics** — who listened, how long, which tracks got played, per-track play counts (Zamtistics-style; the Round Player's own server can collect these — no third party)
- **[C] Buy/support links** per track (Bandcamp/Itch-style)
- **[C] Share links** (X/WhatsApp/copy link) with the track deep-linked
- **[C] Play counts / analytics** (SoundCloud Insights-style; needs a backend)
- **[C] Multiple independent instances on one page**
- **[C] Podcast RSS import** so the player doubles as a podcast player
- **[C] Third-party streaming** (SoundCloud/YouTube/Google Drive via URL or proxy) — react-player-style support
- **[R] Auto-generated embed code snippet** in the designer

### I. Streaming & live
- **[C] Direct file streaming** with Range requests (Round Player's server does this — needed for seeking)
- **[C] Live radio URLs** (Icecast/Shoutcast), **HLS (.m3u8)** streams
- **[C] Buffering/connecting/offline status indicators**
- **[R] Fallback stream URL** if primary dies
- **[R] Live metadata** (now-playing title from stream)
- **[R] WebRTC** for real-time/interactive audio

### J. Audio processing & effects (Web Audio API)
- **[C] Graphic EQ** — 8–10 bands (BiquadFilterNode chain: lowshelf → peaking ×8 → highshelf), ±12 dB, presets (Flat, Bass Boost, Vocal, Rock, Pop, Classical, Electronic)
- **[VLC] EQ preset library** — VLC ships 18 presets (Club, Dance, Full Bass, Full Treble, Headphones, Large Hall, Live, Party, Reggae, Ska, Soft, Soft Rock, Techno…) + preamp; all adjustments apply live without pausing
- **[C] Bass boost** (low-shelf, 0–24 dB with cutoff)
- **[C] Reverb** (ConvolverNode with a synthetic impulse; wet/dry mix)
- **[C] Stereo widener** (channel splitter/merger) and balance/panning
- **[VLC] Compressor / dynamic-range control** (ratio + threshold; tames movie loudness swings)
- **[VLC] Spatializer & headphone virtual surround** (simulated room; 7.1-style headphone virtualisation)
- **[VLC] Simple karaoke filter (vocal reduction)** — pairs perfectly with karaoke lyrics mode
- **[VLC] Stereo modes + channel remap** (Mono / Stereo / Left / Right / Reverse; swap channels)
- **[VLC] ReplayGain track + album modes** and target-dB volume normalisation
- **[R] Pitch shifting, voice removal, echo/delay** (Winamp DSP nostalgia)
- **[W] Parametric EQ with Q control + importable EQ curves**

### K. Accessibility, mobile & i18n
- **[C] ARIA labels, keyboard navigation, visible focus states** on custom controls
- **[C] Transcripts/captions for audio** (`<track>` or panel) — podcast-friendly
- **[C] `prefers-reduced-motion`** respect for animations
- **[C] Touch targets ≥ 44px, swipe gestures, safe-area insets**
- **[C] Language packs / i18n**
- **[C] Colour-contrast-safe themes**

### L. Content & metadata features
- **[C] ID3/metadata parsing** incl. embedded cover art (Round Player: done)
- **[C] Auto-fill title/artist from filename or tags**
- **[C] Album-level grouping, track numbers, disc numbers**
- **[W] Auto tag correction / artist info lookup**
- **[R] Timestamped comments** (SoundCloud style)
- **[R] Track chapters/intros** (podcasts)

### M. Indie-artist platform integration (Bandcamp & friends)
- **[BC] Import a Bandcamp album/track URL** → server parses the page metadata (`data-tralbum` JSON) → playlist populated with title, artist, cover, track list + streaming URLs (bandcamp-fetch pattern)
- **[BC] "Bandcamp radio" mode** — pre-curated genre/theme playlists (drawn from Bandcamp tag feeds + editorial picks) streamed through the player; answers the #1 fan wish (continuous radio)
- **[BC] Random-discovery mode** — "surprise me": random tag/genre picks streamed one after another, like Bandcamp's Discover but continuous
- **[BC] Per-track "Buy / support on Bandcamp" link** — every imported track links to its album page with artist pricing (name-your-price, pay-what-you-want)
- **[BC] Purchase-prompt etiquette** — after ~3 free plays of an unowned imported track, nudge "support the artist" (mirrors Bandcamp's own stream limits; keeps a radio ethical + ToS-aware)
- **[BC] Attribution-first UI** — artist name, album, release year, "you may also like" bought-together suggestions surfaced in the player
- **[BC] Tag-aware browsing** — browse radio stations by Bandcamp tag (genre/mood/location); the 12–16-tag benchmark means rich metadata to filter on
- **[BC] Official embed fallback** — `bandcamp.com/EmbeddedPlayer` iframe as an option ("play in Bandcamp's own player") when direct streaming isn't desirable
- **[BC] Owned-tracks playlists (future)** — fan-login OAuth to import a purchased collection into the player (Bandcamp Playlists are ownership-based; needs API partner access — long-term)
- **[BC] Play analytics for radio** — which imported tracks get liked/played most; feed that back into the radio's curation (self-hosted Zamtistics-style loop)

### N. Community & discovery features (from the wishlists)
- **[C] "Surprise me" random track/album** — one-click discovery (Bandcamp Discover's button, generalised)
- **[W] Continuous radio by genre/mood** — the #1 Bandcamp wish; the Round Player's radio mode
- **[R] "Bought-together" recommendations** — surface what other listeners of this track also like (Bandcamp's hidden panel, made visible)
- **[R] Weekly digest of new releases from followed artists** — a wish in every community
- **[R] Public listening sessions / "now listening"** — listening-party culture (Bandcamp listening parties)
- **[R] Timestamped community comments** (SoundCloud-style, ties to N-04)

---

## 3. What people WISH existed (user voices)

From Reddit (r/StevesPlayer, r/DigitalAudioPlayer, r/fossdroid, r/AppleMusic, r/androidapps) and player reviews, the recurring wishes:

1. **Gapless playback** — overwhelmingly the #1 wish ("at least half my albums require gapless", "essential", "hard pass" without it). Web players rarely do it.
2. **Parametric/16-band EQ + importable GraphicEQ curves**.
3. **Synced lyrics that actually auto-scroll** and don't require manual sync every time.
4. **Lossless support** (FLAC) treated as a given, not a premium feature.
5. **Last.fm scrobbling**.
6. **Smart playlists / rules** and **pinning** favourite playlists.
7. **"Connect"-style remote control** (Spotify Connect-like, control from another device).
8. **Sleep timer** (15/30/45/60 min).
9. **Crossfade + fade in/out + ReplayGain** ("seamless transitions").
10. **A real visualiser suite** (people still miss Winamp's Milkdrop).
11. **Folder/artist/album/genre library views + folder exclusion**.
12. **Gestures**: swipe to skip, shake to change track.
13. **.cue support**, DSD playback (desktop niche).
14. **Shuffle that's actually smart** (no artist repeats).
15. **Download-all / batch actions**, tag editors.
16. **Ads-free, privacy-respecting, no-login** (recurring theme for web players).

From **VLC** users specifically: a modern UI + **native dark mode**; **touch-friendly controls**; seek-bar **thumbnail previews**; true-random shuffle; visible timestretch toggle; timestamp bookmarks; volume boost kept.

From **VoiceZam** users specifically: **no subscription** (the #1 gripe — free/self-hosted alternative); **visible demo categories** rather than a hidden dropdown; visualizer that doesn't block page links; autoplay without double-clicks; per-track downloads with clean filenames.

From **Bandcamp** fans specifically: a **real radio / continuous-shuffle mode** ("put Bandcamp on in the morning at work and hear music all day"; "why does Bandcamp not have a built-in streaming service?"); **playlists from the browser**; **better recommendation heuristics** ("wish they had better heuristics"; the bought-together panel is "hidden there"); **weekly digest of followed artists' releases**; more subgenre/new-release surfaces. Fans *defend* the no-algorithm stance ("there's no algorithm spoon-feeding you derivative music, and I see that as a good thing") — so a radio for Bandcamp should feel **curated/community-driven, not algorithmic**. Notably, the community already built tools for exactly this gap (Bandcamp Streamer extension = feed-based radio; bandcamp-fetch = import library).

### The Round Player's own ideas (confirmed viable)
- **A suite of visualisers** — fully supported by Web Audio API (`AnalyserNode` → canvas/WebGL). Circular/radial modes would be a natural fit for a round player.
- **WAV + FLAC playback** — both are natively supported by every modern browser; mostly a matter of accepting the file types and serving with the right MIME types. No transcoding, no libraries.
- **Lyric panel with auto-scroll** — LRC parsing + LRCLIB fetch + click-to-seek is a well-trodden path (several Chrome extensions do exactly this against YouTube).
- **Shape-changing player (round → triangle → octagon → user-generated)** — no mainstream player does this; the precedents are Winamp freeform skins and CSS `clip-path` polygon morphing. The Round Player's circular layout + absolute positioning + per-track themes makes it plausible: swap the mask/clip-path, and re-flow controls via JS layout functions per shape. **Genuine differentiator.**

---

## 4. Feasibility notes for the Round Player

| Feature | Effort | Notes |
|---|---|---|
| WAV/FLAC accept+play | **Low** | Native `<audio>` support; allow extensions in file inputs; serve correct MIME; show `canPlayType` warning for odd cases |
| Visualiser suite | **Low–Med** | `AnalyserNode` + `requestAnimationFrame` canvas; modes: bars, radial, waveform, particles; sensitivity + palette options; fullscreen |
| Lyrics panel (LRC) | **Med** | Parse LRC (line + enhanced), auto-scroll with manual-override pause, click-to-seek, LRCLIB fetch, per-track offset, per-track storage |
| Media Session / OS keys | **Low** | ~40 lines; metadata + action handlers + position state; huge "native feel" win |
| Keyboard shortcuts | **Low** | Global keydown map (space, arrows, N/P, M, +/-) |
| Resume position | **Low** | localStorage per-track currentTime |
| Playback speed | **Low** | `audio.playbackRate` |
| Download / buy links | **Low** | Per-track config |
| Embeds: iframe/script + data-attrs | **Low–Med** | Round Player already config-driven; add a generated embed snippet in the designer |
| Sleep timer | **Low** | Countdown → pause |
| Fade in/out | **Low** | Web Audio gain ramp |
| Crossfade audio | **Med** | Two AudioContext sources + gain envelopes; Round Player already has theme crossfade plumbing |
| Gapless | **Med–Hard** | Preload next + Web Audio scheduling; approximate on `<audio>` |
| EQ / bass boost / reverb | **Med** | BiquadFilter chain + ConvolverNode; routing through AudioContext (needs care with MediaElementSource + autoplay policies) |
| Shape changer | **Med–Hard** | clip-path/polygon + per-shape layout functions; most ambitious/unique item |
| Smart shuffle, play history, queue | **Low–Med** | Pure JS state |
| PWA install/offline | **Med** | manifest + service worker; conflicts with server-persistence model — needs care |
| Last.fm scrobbling | **Med** | needs user API key + session auth |
| Podcast RSS | **Med** | fetch + parse RSS; playlist population |
| HLS / live radio | **Med** | hls.js library for m3u8; direct Icecast URLs mostly "just work" with `<audio>` |
| Smart playlists / AI features | **High** | Later phase |
| Volume boost >100% | **Low** | `audio.volume` up to 2.0 + soft-clip warning; VLC-beloved |
| Speed + timestretch toggle | **Low** | `playbackRate` + optional Web Audio time-stretch; keep the toggle VISIBLE (VLC lesson) |
| True-random shuffle | **Low** | Re-seed per session; never repeat order (VLC's same-seed bug) |
| EQ preset library (18 VLC-style presets + preamp) | **Low** | Static band arrays applied to the same filter chain |
| Compressor / spatializer / headphone surround | **Med** | DynamicsCompressorNode; ConvolverNode IRs for room/surround |
| Karaoke vocal-reduction filter | **Med** | Phase-inversion of mid/side or notch filtering; pairs with karaoke lyrics |
| Stereo modes + channel remap | **Low–Med** | ChannelSplitter/Merger + gain pans |
| ReplayGain (track+album, target dB) | **Med** | Needs loudness metadata (or compute per file); store per-track |
| Per-track + full-playlist downloads (title filenames) | **Low** | `<a download>` + server URL; zip-all on server |
| Portfolio/showcase categories | **Low–Med** | Add `category` field per track; dropdown/tabs filter the playlist |
| Contacts panel (agents, socials) | **Low–Med** | New panel fed by theme.json fields; natural for artist portfolios |
| Play analytics (plays, duration, per-track) | **Med** | Round Player's own server already receives play events — log + dashboard |
| Bandcamp album/track URL import | **Med** | Server fetches the album page, parses `data-tralbum` JSON (title/artist/cover/tracks + mp3-128 URLs) — bandcamp-fetch pattern; cache + rate-limit |
| "Bandcamp radio" (curated genre playlists) | **Med** | Server pulls tag/Discover feeds into playlists; player streams imported URLs; cover/theme flow through the existing pipeline |
| Random "surprise me" radio | **Low–Med** | Same import pipeline + random tag/album picker; "skip" = next random pick |
| Per-track "Buy on Bandcamp" links | **Low** | Add `bandcamp` field per track; button opens the album page (name-your-price) |
| 3-play purchase-prompt etiquette | **Low** | localStorage play counter per imported track; after ~3 plays show "support the artist" nudge (mirrors Bandcamp's own limit) |
| Audio proxy for CORS (visualisers on imported streams) | **Med** | Reuse the existing Range-capable server to proxy `bcbits.com` streams so Web Audio analysers work cross-origin |
| Owned-collection import (fan login) | **High** | Needs Bandcamp API partner access / OAuth; long-term |
| Official embed fallback ("play in Bandcamp") | **Low** | `<iframe src="https://bandcamp.com/EmbeddedPlayer/album=ID/...">` |
| Bought-together / tag-aware recommendations | **Med–High** | Requires an import/curation backend (what other fans bought is public per-album); later phase |

---

## Sources
- HTML5 audio capabilities: allabouthtml.com HTML5 Audio Player guide; Wikipedia "HTML5 audio"; MDN Media Session API docs; apurvkhare.com Media Session article; mintlify Beat App Media Session docs; wavesurfer.xyz media-session example
- Format support: Wikipedia HTML5 audio codec table; Mozilla Support "Audio and video files in Firefox"; testmuai.com FLAC browser support; powermapper browser-compat rule; heamusic.com format table
- Libraries: pkgpulse.com howler vs tone vs wavesurfer; supadark.com tone vs howler; openbase 10 best JS audio player libraries; libhunt audio topic; waveform-playlist
- Visualisers: frequencydetector.com 3D WebGL visualiser; webguysllc.com 8-mode visualiser; github webprofusion/web-audio-viz (Winamp-inspired: bars/waveform/circular/spiral/particles); awesomerank awesome-audio-visualization; aaron-f-bianchi LSaO (spectrum/oscilloscope)
- Lyrics: Chrome Web Store — LyricScroll, YT Music Karaoke, YouTube Lyrics Viewer; lrcsong.com LRC preview player (LRC standard + enhanced, click-to-seek, auto-scroll)
- Winamp: sourceforge Winamp; support.winamp.com 5.6–5.9 comparison; pawelporwisz.pl Winamp features (EQ, plugins, skins, ReplayGain, gapless); web.archive Winamp 1.9–2.0 changelog; designyourway skins list
- Players/plugins: wordpress.org HTML5 Audio Player plugin (RSS, HLS, FLAC, skins, state saving, fallback streams); bplugins HTML5 Audio Player; codecanyon HTML5 Web Audio Player (speed, upload, light/dark); WMPlayer GitHub (playlist, YouTube, docking)
- Wishlists: r/StevesPlayer (EQ, DSD, Last.fm, gapless, sorting); r/DigitalAudioPlayer (gapless); r/fossdroid (gapless, folder exclusion, .cue); r/AppleMusic (smart playlists, pinning, Connect, download all); androidcentral player guide (EQ, sleep timer, shake, scrobbling, ReplayGain, lyrics)
- Effects: reddit reverb+bass boost PoC; removevocals.ai bass booster; ReEQ GitHub (10-band parametric EQ extension); soundyak.com 8-band EQ; jasperbernaers.com MP3 player (EQ, crossfade, sleep timer, BPM, effects, fullscreen visualiser)
- Embeds: SoundCloud help (HTML5 player, Visual player, embedding, permissions/analytics); WordPress "Player for SoundCloud" block
- **VLC**: vlc-mediaplayer.com features tour; vlc-help.com volume/audio-controls guide (EQ, visualizations, stereo modes, ReplayGain); mandredtw.itch.io devlog (EQ presets, compressor, spatializer, audio normalisation); fileion VLC EQ guide; mundobytes.com filters guide; r/Windows_Redesign (UI gripes, dark mode); r/pcmasterrace (VLC vs MPC, 4K/HDR limits); r/VLC (shuffle same-seed bug, timestretch toggle placement, touch UI, dark mode); r/IAmA VLC dev AMA (subtitles, lightweight trade-offs)
- **VoiceZam**: voicezam.com "What is VoiceZam" (tracks view, contacts view, demo downloads); voicezam.com "whatisvoicezam" (tracks list); LinkedIn "Let's talk about the VoiceZam Player" (unlimited, instant updates, CSS skinning, embed tutorials, downloads); prweb 2013 release (Zamtistics analytics, pricing, mobile); thevoiceofbarbara.com (contacts panel, social sharing, per-track demo); nathanpuls.medium.com (Royal Audio Player alternative — subscription gripe, hidden dropdown complaint, visualizer link interference)
- **Bandcamp**: swacapp.com "How does Bandcamp work" (artist features, fan features); labelgrid.com distribution guide (revenue shares, Bandcamp Fridays, editorial); expandedramblings.com statistics; orphiq.com strategy guide (fan data, economics table); loop.fans distribution guide (subscriptions, physical/merch); bandcamp.com/developer (API access — labels/merch partners only, OAuth 2.0); get.bandcamp.help streaming-limits article (3-play default, purchase prompt); bandcamp.com/about_playlists (ownership-based playlists beta); bandcamp.com "Does Bandcamp have an API"; stackoverflow "generate a Bandcamp player embed given an album" (data-tralbum JSON, item_id extraction); r/BandCamp "Radio option?" / "Shuffle Radio/Feed/Random" / "Idea proposal: online radio" / "How do you discover new music?" / "the culture of Bandcamp radio shows" (wishes: radio, shuffle, playlists, heuristics, weekly digest; discovery surfaces: tags, collections, bought-together); Bandcamp Streamer Chrome extension (feed-based radio); patrickkfkan/bandcamp-fetch GitHub (scraping library, rate limiting); chartlex.com "Bandcamp Discovery and Fan-Finding 2026" (six discovery surfaces, tag benchmark, no algorithm)
