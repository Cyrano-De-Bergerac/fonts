# Editor Redesign — Strategy & Action Plan

> Goal: remake the dev editor into a compact, stylish, intuitive editing experience for a highly-customisable round music player.
> Created: 2026-08-21 · Status: design brief + phased plan (ready to implement)

---

## 1. Current-state audit

**Scale:** **169 controllable items** — 101 inputs, 20 selects, 48 buttons — across **12 sections**, **4 main tabs** (Editor / Playlist Manager / Visualisers / Global), and **two separate sub-tab systems** (Editor → Edit Main / Edit Playlist; Visualisers → Main / Playlist).

**Today's information architecture:**
```
Editor ─────────── (shared) Look presets, Save This Track
  ├─ Edit Main Player   → media, colors, cinema(track)
  └─ Edit Playlist Panel→ PL backdrop, PL colors, PL framing
Visualisers ────── (shared) viz on/off + save
  ├─ Main player        → in-circle mode+settings, blend, framing, Edge/Rim
  └─ Playlist           → PL in-circle, blend, Edge/Rim
Playlist Manager ── track list, reorder, BPM, transitions
Global ─────────── overall theme, playback, OS, defaults, housekeeping,
                    CINEMA (global + playlist!), beat-pulse
```

**The "I forget where it is" map (confirmed by line audit):**
| Control | Today | Pain |
|---|---|---|
| `trackCinema` (main cinema) | Editor | ok-ish |
| `gsPlCinema` (playlist cinema) | **Global** | far from playlist work |
| `gsCinema` / style (global cinema) | Global | split from per-track cinema |
| `plMedia` / `plMirror` / `plVideoOn` | Editor (PL sub) | ok, but cinema for PL is elsewhere |
| `vizTrackOn` + save viz | Visualisers | split from theme save |
| `masterThemeToggle` | Global | far from Colors |
| Beat-pulse, boost, speed | Global | far from playback feel |

**Root problems:**
1. **Two organising axes fight:** "which surface?" (main vs playlist) vs "which concern?" (media/colors/visualiser/cinema/playback). One concern (cinema) is split across surface + global.
2. **Nested tabs (2 levels, twice).** NN/g & Material advise ≤2 levels and prefer accordions/dropdowns over nested tabs for settings.
3. **169 items, flat rows, weak grouping, no progressive disclosure** — everything visible at one intensity.
4. **Multiple paths / redundancy:** 3 overlapping "Save" buttons; Colors appears in Editor *and* inside Visualiser (blend); per-track vs global cinema presented as separate, unconnected controls.
5. **No global search** — the only fix for "I forget where" is memorising the map.

---

## 2. Research findings (web study)

- **Progressive disclosure** (Nielsen, 1995; IxDF): reveal complexity in stages — essential controls up front, advanced on request. Cuts time-to-first-action **30–50%**. Patterns: accordions, "Advanced" sections, modals, contextual menus. *Rule: one secondary screen per item; avoid multiple access paths.*
- **Accordions > tabs for settings** (NN/g, uxpatterns.dev): accordions win when content is **hierarchical** and users **don't switch constantly** — exactly a settings/properties panel. Tabs win for **parallel, frequently-switched** views. Our editor is the former.
- **Nested tabs:** keep **≤2 levels**; if you need more, "use accordions, collapsible panels, or progressive disclosure instead" (designmonks). We currently have 2 sub-tab systems stacked → prime candidate to flatten.
- **Figma / Linear "properties inspector" pattern:** a single contextual right-panel that **reflects the selected object**, grouped by **concern** (Layout / Color / Typography), each a collapsible section. This is the gold standard for "edit the selected thing." → Maps perfectly to our two surfaces.
- **Command palette (⌘K)** (GitHub, Linear, Raycast, cmdk/kbar): keyboard-first overlay to **find/jump to any action or setting** by typing. **Augments** visible nav (doesn't replace it); solves "I forget where" definitively. Bind ⌘K/Ctrl+K; fuzzy filter; grouped results; keyboard nav.
- **Information hierarchy:** prioritise; secondary data subtler/lower; guide the eye; white space defines zones; group with headings.
- **macOS System Settings / Notion:** left category menu + content area; advanced behind "Advanced…"; a single **search bar** that filters settings.

**Synthesis for our player:** adopt the *Figma contextual-inspector* model — **pick a surface (Main / Playlist), see that surface's properties grouped by concern in collapsible accordions** — kill the nested tabs, **co-locate every concern** (esp. cinema), and add a **⌘K palette** so nothing is ever more than a keystroke away.

---

## 3. Proposed new information architecture

**One panel. Surface-scoped. Accordion-by-concern. Searchable.**

```
┌─ TOP BAR ────────────────────────────────────────────────┐
│  Surface: [ ● Main player ] [ Playlist panel ]   ⌘K   💾 │  ← scope + search + save
├─ TRACK (always visible, not surface-scoped) ─────────────┤
│  Title / Artist · Audio · Cover · Video · Bandcamp       │
│  [Look presets ▾]  [Save track]  [Reset]                 │
├─ ACCORDIONS (scoped to the selected surface) ────────────┤
│  ▸ Media & Artwork      cover/video, show-art, reposition│
│  ▸ Colours              palette + customise (inline)     │
│  ▸ Visualiser           mode ▸ (advanced: sens/smooth/   │
│                          bars/fft/colours/star/fog)      │
│                          + Blend [on/off] mode ▾ amount ─│
│                          + framing (reposition/zoom)     │
│  ▸ Edge / Rim           mode ▸ (advanced: reach/sens/    │
│                          smooth/opacity/bars/colours)    │
│  ▸ Cinema & Motion      cinema [track on/off] style ▾    │
│                          + beat-pulse + (PL cinema here) │
│  ▸ Wave Panel (Main)    texture/blend/mode/grey/framing  │
├─ PLAYER (global, not surface-scoped) ────────────────────┤
│  ▸ Playback             loop/shuffle/gapless/fade/speed/ │
│                          boost/transitions               │
│  ▸ Defaults & OS        autoplay/resume/volume/media-    │
│                          session/sleep/overall-theme      │
│  ▸ Housekeeping         reset, status, diagnostics       │
└──────────────────────────────────────────────────────────┘
```

**Why this works:**
- **Surface selector scopes the accordion content** → editing the playlist? Every section (Colours, Visualiser, Cinema…) now shows *playlist* controls. No more hunting across tabs. (Figma "select object → properties".)
- **Accordions replace nested tabs** → one level of nesting max (the surface scope is a toggle, not a tab). Multiple sections can be open at once for comparison.
- **Cinema is ONE section** — main + playlist + global-default all live together, scoped by the surface selector. The exact "where's playlist cinema?" problem is solved structurally.
- **⌘K command palette** — type "cinema", "blend", "fog" → jump straight to that control, opening the right accordion + surface. The definitive fix for "I forget where."
- **One Save** — a single "Save track" (look + media + viz + panel) replaces the 3 overlapping buttons. Look Presets stay.

### Redundancies to eliminate
- **3 Save buttons → 1** "Save track" (does theme + viz + transforms + media). Keep "Look presets" separate (cross-track).
- **Colours duplicated** (Editor sub-tab *and* Visualiser blend-colours) → one Colours accordion; blend "custom colours" reuses the same picker.
- **Per-track vs global cinema** presented as 3 disconnected toggles → ONE Cinema section: a "use global default" vs "override for this track" choice + the style, with the global default set in Player ▸ Defaults.
- **trackCinema vs gsCinema vs gsPlCinema** → collapse to: `cinemaMode` per surface (inherit | on | off) + a global default. Same data, one mental model.

### Streamlining patterns to adopt
- **Mode-led disclosure:** picking Visualiser mode = "off" hides sensitivity/bars/fft; = "milkdrop" shows preset picker; = "coaster" shows fog. Only relevant controls render (we partly do this — extend it everywhere).
- **"Advanced" sub-accordion** inside each section for the rarely-touched knobs (FFT size, edge smoothing, star size) so the top of each section stays scannable.
- **Segmented controls** for 2–4 option choices (e.g., loop: off/all/one; surface: Main/Playlist) instead of dropdowns — faster, more visible.
- **Live preview chips** on accordion headers (a 3-swatch colour dot, the viz-mode name, "blend: overlay 60%") so you can read the current state without opening the section.
- **Sticky section header** with the surface name + a one-line "what this surface shows right now".

---

## 4. Visual & interaction direction ("beautiful, stylish, cool, fun")

- **Glassy dark inspector** — translucent panels, subtle inner border, soft shadow; the round player stays the hero on the left.
- **Compact density** — 11–12px labels, tight 4–6px row gaps, inline value readouts; sliders thin with a glowing fill in the track's accent colour.
- **Accordion headers** = full-width, clickable, with a rotating chevron, a small icon, the section name, and a **live state chip** on the right.
- **Micro-interactions** — smooth height transitions on expand/collapse; the active section gets a faint accent-glow left border; slider thumbs scale on hover; saving flashes a soft ✓ toast.
- **Colour** — accent = the track's own `--progress-mid`, so the editor visually belongs to the track you're editing (reinforces "I'm editing THIS track").
- **Empty/quiet states** — sections that are "off" dim to 50% and show a one-line hint ("Visualiser off — pick a mode"), inviting action without clutter.
- **Fun touches** — the surface toggle could be two mini round-disc icons (main + playlist) rather than text tabs; the ⌘K palette has a blurred backdrop and snappy keyboard nav.

---

## 5. Phased action plan

> Each phase ships independently and is usable. No big-bang rewrite.

### Phase 0 — Inventory & component scaffolding (low risk)
- Build a reusable **Accordion** component (`<details>`-based or JS) + a **SegmentedControl** + a **StateChip** helper. Add the accordion CSS.
- Tag every existing control with `data-section` + `data-surface` + `data-keywords` (for search) — no behaviour change yet, just metadata for the reorganisation.
- *Exit:* components exist; page unchanged.

### Phase 1 — Co-locate the cross-cutting controls (high impact, low risk) ← fixes the reported pain fast
- **Create a "Cinema & Motion" group** that gathers `trackCinema`, `trackCinemaStyle`, `gsPlCinema`, beat-pulse into one place (surface-scoped). Remove `gsPlCinema` from the Global tab.
- **Unify the saves:** collapse the 3 save buttons into one **"Save track"** (calls theme + viz + transforms), keep Look Presets.
- **Surface selector** (Main / Playlist) at the top of the Editor tab that shows/hides the relevant colour + cinema rows (preview of the full model).
- *Exit:* the exact "where's playlist cinema?" complaint is gone; fewer tabs to thumb through.

### Phase 2 — Accordions replace nested tabs (the big structural win)
- Convert the Editor sub-tabs and Visualiser sub-tabs into **accordion sections under the surface selector** (Media, Colours, Visualiser, Edge/Rim, Cinema & Motion, Wave Panel). Flatten to one level.
- Mode-led disclosure throughout (only relevant sub-controls show).
- Live state chips on headers.
- Move Playlist Manager to a top-level tab still (it's a different task — managing tracks, not styling one).
- *Exit:* one scannable, collapsible panel per surface; no nested tabs.

### Phase 3 — ⌘K Command Palette / settings search (the "I forget where" killer)
- Add a ⌘K/Ctrl+K overlay that fuzzy-searches all controls by label + keywords, grouped by section. Selecting a result **switches surface + opens the accordion + scrolls/highlights** the control.
- Reuse the `data-keywords` metadata from Phase 0.
- *Exit:* any of 169 settings is one keystroke away; "where is it?" is solved permanently.

### Phase 4 — Visual polish & "quick look"
- Glassy dark theme, accent = track colour, micro-interactions, sticky surface header.
- A collapsed **"Quick look"** summary at the top (palette swatches + viz mode + blend + cinema) as a one-glance card; click to jump.
- Empty/quiet states for "off" sections; toasts on save.
- *Exit:* the stylish, fun, premium feel.

### Phase 5 (optional) — Adaptive / expert mode
- A "Simple / Advanced" toggle: Simple hides Edge, FFT, smoothing, transforms; Advanced reveals everything. Persists per user. (Progressive disclosure matching expertise.)

---

## 6. Success checks
- A new user can style a track's main + playlist look (colours + visualiser + blend + cinema) **without backtracking between tabs**.
- "Find the playlist cinema toggle" takes **< 3 s** via either the surface-scoped Cinema section or ⌘K.
- Total visible controls at first glance drops from **~169 → ~30–40** (the rest behind accordions/disclosure).
- No control has more than one home (single-path IA).

---
*This brief is the source of truth for the redesign. Implementation begins at Phase 1 (co-locating cinema + unifying saves) unless directed otherwise.*
