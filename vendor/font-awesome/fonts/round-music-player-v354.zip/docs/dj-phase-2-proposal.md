# DJ Phase 2 — Beat & Tempo Detection + Beat-Synced Transitions

### Design proposal for the Round Music Player
Compiled 2026-08-11 · Research-backed (sources cited inline). Goal: **simple, clean, clear, easy for the end user.**

---

## 0. Executive summary — the magic in one paragraph

Today the player already has a pro transition *engine* (dual-element A/B, per-pair crossfades, equal-power curves, true gapless at 0 s) — but its "bars" mode is **dormant** because no track ever has a BPM. Phase 2 makes BPM **real**: every track is auto-analyzed on upload, the existing "8/16/32 bars" setting suddenly means *actual musical bars of that track*, blends **tempo-lock** so two tracks never gallop, and transition points **snap to the beat** so fades land on bar lines instead of mid-phrase. End users on the deployed page get all of this **automatically, zero-config**; the editor user just sees a BPM column and a couple of toggles.

**Three deliverables (mapped to the existing roadmap):**
- **TR-07 — Tempo detection**: auto-BPM on upload, editable, with ½/×2 octave fixes.
- **TR-08 — Beat-synced transitions**: real bars→seconds from BPM + beat/bar snapping.
- **TR-09 — Tempo mode on blend**: Instant / Locked / Ramp (tempo-match during the overlap).

---

## 1. What the research taught us (the expertise)

### 1.1 Every BPM detector is the same three-stage pipeline
Onset detection → tempo estimation → (optional) beat tracking [[4]](https://github.com/audiojs/beat) [[9]](http://joesul.li/van/beat-detection-using-web-audio/).

| Stage | What it does | Methods |
|---|---|---|
| **Onset detection** | Produce an Onset Detection Function (ODF): a spike wherever a note/drum hits | **Spectral flux** (STFT → magnitude → +ve frame-to-frame diffs → adaptive threshold) is the gold standard; energy/RMS flux is the cheap variant |
| **Tempo estimation** | Find the dominant periodicity in the ODF | **Autocorrelation** (lag 60–200 BPM; ~70% exact / 87% octave-tolerant) or **comb-filter** (cross-correlate with pulse trains; ~87%/93%, fewer octave errors) |
| **Beat tracking** | Place actual beat *times* (phase grid) | Phase-aligned grid (snap tempo to first onset) or **dynamic programming** (Beatroot/Dixon — globally optimal sequence) |

**The #1 failure mode is octave ambiguity** — autocorrelation can't tell 70 from 140 BPM. Mitigations: fold to a 70–180 perceptual window, perceptual weighting (log-Gaussian ≈120 BPM), snap to integer/half, and **show ½/×2 buttons** so the user picks the right metrical level [[@audio/beat benchmarks]](https://github.com/audiojs/beat).

### 1.2 Beatmatching = tempo match **+** phase match
This is the core craft, repeated across every DJ source [[2]](https://rhythmandpulse.co.uk/tempomatching-vs-phasematching-vs-beatmatching/) [[8]](https://grokipedia.com/page/Beatmatching):
- **Tempo matching** — both tracks play at the same BPM (via time-stretch).
- **Phase matching (bar-matching)** — the *downbeats* (beat 1 of each bar) line up in time. Same BPM but offset beats still sound wrong.
- Both together = a clean beatmatch.

**The phrasing rule (universal):** 4/4 music is built in **8-bar / 32-beat sections**; good transitions align on those phrase boundaries, not arbitrary beats [[6]](https://www.transitions.dj/manual/pgs/mixing.html) [[7]](https://www.transitions.dj/help/mixing.html).

### 1.3 Tempo-matching in the browser — we may need zero new deps
- **`HTMLMediaElement.preservesPitch` + `playbackRate`** time-stretches natively, pitch-preserved, in **all modern browsers** — and the player *already* sets `playbackRate` for the speed feature [[SO]](https://stackoverflow.com/questions/53791472/how-to-do-time-streching-audio-playback-using-javascript-in-2019). Quality is good to **±8–10%**.
- **SoundTouchJS** (AudioWorklet, WSOLA) is the pro upgrade for bigger tempo deltas / independent pitch [[5]](https://www.npmjs.com/package/@soundtouchjs/audio-worklet) [[10]](https://github.com/cutterbl/SoundTouchJS) — a Phase-3+ option, not needed now.

### 1.4 How the commercial analogues do exactly this
- **MixClap**: detect BPM (Essentia) → pick fade in **bars (4/8/16/32)** → two tempo modes: **"Locked"** (incoming time-stretched to the previous tempo) or **"Ramp"** (gradual glide); cut points snap to the nearest beat [[3]](https://mixclap.com/en/blog/bpm-beatmatching-complete-guide).
- **DJ.Studio**: per-transition "BPM window" — when tracks converge, or play at own tempo; "meet in the middle" for big BPM gaps; beatgrid editor to fix first-beat [[4]](https://help.dj.studio/en/articles/8261956-bpm-controls-tips-and-faqs).
- **djay Pro**: **BPM Sync** (tempo only) vs **BPM + Beat Sync** (tempo + downbeat phase) [[1]](https://help.algoriddim.com/user-manual/dj-tools/beatgrids-bpm-sync/sync).

These three map almost 1:1 onto our **Tempo mode** (Instant / Locked / Ramp) and **Snap-to-beat** toggle — confirming the model is both proven and the right shape.

### 1.5 The gotchas that will bite us
1. **BPM needs the decoded audio** (`decodeAudioData`). Works great for uploads/blobs/local files. **Remote URLs (Pixabay/Bandcamp) may CORS-fail** on fetch → auto-detect won't run; fall back to **manual BPM entry**. (Same root cause as the visualiser CORS-zero issue — VIZ-21 proxy would fix both later.)
2. **Octave errors** → always store confidence + offer ½/×2.
3. **`decodeAudioData` cost** → ~1–2 s for a 4-min track. Analyze **async on upload** with a "Detecting…" state; never block the UI.
4. **Autoplay policy** doesn't affect offline analysis (no AudioContext gesture needed for `decodeAudioData` on a file), so detection runs the moment a file is added.

---

## 2. Build on what's already there (no rewrites)

The transition engine is already complete; Phase 2 mostly *feeds it real data* and adds two behaviours. Existing pieces we reuse:

| Existing | Role in Phase 2 |
|---|---|
| `transitionFor(i)` → `{fade, curve, beats}` | Unchanged shape; `beats` now meaningful |
| `transitionSeconds(t, tr)` = `beats>0 && t.bpm>0 ? beats*4*60/t.bpm : tr.fade` | **Already correct** — just needs `t.bpm` populated (TR-07) |
| `gs.transitionDefault {fade, curve, beats}` | Add `tempoMode` + `snap` defaults |
| AB engine: `armCrossfade` / `startTransition` / `abCompleteHandover` / `crossfadeGains` | Gain ramps unchanged; add tempo-match + bar-snap *around* them |
| Per-row ⧉ editor (`openTransitionEditor`) + Global transition block | Add the new controls here |
| `getThemeData()` / server theme / deployed polling | Ship `t.bpm`, `t.bpmConfidence`, `t.bpmOffset`, `t.bpmSource` per track + global defaults |

So: **no engine rewrite.** We add one analysis module, three track fields, a tempo-match step, and a bar-snap step.

---

## 3. The proposal, deliverable by deliverable

### TR-07 — Tempo detection (the foundation)

**Library:** vendor **`realtime-bpm-analyzer`** (Apache-2.0, <5 KB, zero-dep, AudioWorklet, best-maintained, the docs' original pick) [[1]](https://www.realtime-bpm-analyzer.com/guide/introduction) [[3]](https://github.com/dlepaux/realtime-bpm-analyzer). Use its **offline strategy** — `decodeAudioData(file) → analyzeFullBuffer(buffer)` returns ranked BPM candidates — so we get a **stable BPM up front** (exactly what transitions need), independent of the live AudioContext.

> *Alternative if we want beat-times/phase in one call:* **`@audio/beat`** `detect()` returns `{bpm, confidence, beats[]}` [[4]](https://github.com/audiojs/beat), or **`web-audio-beat-detector`** `guess()` returns `{bpm, offset}` [[9]](https://github.com/chrisguttandin/web-audio-beat-detector). Recommendation: start with realtime-bpm-analyzer; revisit if bar-snap needs a true beatgrid.

**New per-track fields:** `t.bpm` (number), `t.bpmConfidence` (0–1), `t.bpmSource` (`'auto' | 'manual'`), optional `t.bpmOffset` (s, first-beat — for bar-snap).

**Flow:**
1. On upload/import (`applyAudioFileToTrack`), after the file is read → `decodeAudioData` → `analyzeFullBuffer` → pick top candidate, fold to 70–180, store `bpm` + `confidence` + `source:'auto'`.
2. Show a **"Detecting BPM…"** badge on the row; replace with the number + confidence dot when done.
3. On failure (CORS/decode error/beatless) → leave BPM empty, badge "set BPM" — manual entry available.
4. Manual controls per row: **edit BPM**, **½** / **×2** (fix octave), **↻ re-detect**. Any manual edit sets `source:'manual'` (so re-detect won't clobber a user fix unless they ask).

**UX principle:** auto-first, manual-as-escape-hatch. The number is always visible and always correctable.

### TR-08 — Beat-synced transitions (make "bars" real + snap to the beat)

Once `t.bpm` exists, the existing bars dropdown instantly does the right thing. Two additions:

**(a) Real bars → seconds.** Already implemented in `transitionSeconds`; just verified it kicks in once `t.bpm` is set. No code change beyond populating BPM.

**(b) Snap-to-beat toggle** (`tr.snap`: `false` default). When on:
- **Bar-boundary snapping** — the transition's *arm/blend start* is moved forward to the outgoing track's nearest **bar line** (multiple of `4 × 60/BPM` from its first beat). This makes the outgoing fade exit cleanly on a musical boundary instead of mid-bar. Needs `t.bpmOffset`; if absent, snap to the nearest bar relative to the detected first onset; if still absent, snap silently degrades to "no snap."
- The blend *length* stays in bars (so a 16-bar blend is still 16 bars — just starting on a bar line).

**Why not full phase-lock?** True sample-accurate phase alignment of the *incoming* against the *outgoing* is club-software territory and needs a real beatgrid. For a deployable web player, **tempo-lock (TR-09) + bar-snap on the exit** delivers ~90% of the perceived quality at ~10% of the complexity. We leave incoming-phase-lock as a Phase-3 stretch (TR-14 cue points / TR-16 waveforms would feed it).

### TR-09 — Tempo mode on blend (Instant / Locked / Ramp)

A new `tr.tempoMode` (global default + per-pair override), mirroring MixClap's proven model [[3]](https://mixclap.com/en/blog/bpm-beatmatching-complete-guide):

| Mode | Behaviour | Best for |
|---|---|---|
| **Instant** *(default, current behaviour)* | At handover the tempo simply becomes the incoming track's BPM. | Most playlists; tracks at similar tempo |
| **Locked** | During the overlap, the **incoming** track is time-stretched (native `preservesPitch`+`playbackRate` = `outBPM/inBPM`) to the **outgoing** tempo; snaps back to its real BPM after handover. | Seamless blends between different-tempo tracks (no gallop) |
| **Ramp** | During the fade, **both** tracks glide from the outgoing tempo to the incoming tempo ("meet in the middle"-ish) so the tempo change is imperceptible. | Long ambient/DJ-style blends |

**Implementation:** the AB engine already ramps gains in `startTransition`'s rAF loop. We add a parallel `playbackRate` ramp on the matching elements (native pitch-preserved) using the same `k = (now−t0)/fade` interpolation. Big-BPM-gap guard: if `|outBPM−inBPM|/inBPM > ~12%`, Locked/Ramp auto-fallback to Instant with a one-time editor hint (native time-stretch artefacts grow past ±8–10%).

---

## 4. UX — simple, clean, clear, easy

**Deployed player (end user): zero new UI.** Beat-synced transitions just *happen* using the saved per-track BPM + saved transition settings. The user hears cleaner blends; nothing to learn.

**Editor (you / the designer):**
- **Playlist Manager gains a compact BPM column** — auto number, confidence dot (green/amber/grey), click to edit. ½ / ×2 / ↻ inline. A "Detect all" button bulk-analyzes tracks missing a BPM.
- **Per-row ⧉ transition editor** gains two compact rows under the existing Fade/Curve/Beats:
  - `Snap to beat` ☐ (bar-boundary snapping)
  - `Tempo` [Instant ▾] (Instant/Locked/Ramp)
  - Same "Apply to all" pattern already there.
- **Global tab → Transition default** gains the same `Snap` + `Tempo mode` defaults (so every pair inherits them unless overridden).
- **Helpful copy, not jargon:** tooltips read "land the fade on a bar line" / "keep both tracks at the same speed during the blend" / "glide the tempo across the blend."

**Visual signal (optional, cheap win):** a faint beat-tick or a "🎯 snapped" marker on the seek arc when a beat-synced transition is armed — confirms the magic is working without clutter.

---

## 5. Architecture & integration points

```
new module:  analyzeBpm(file) -> {bpm, confidence, offset?}      (vendor: realtime-bpm-analyzer, offline)
hook into:   applyAudioFileToTrack() / addFilesToPlaylist()      -> set t.bpm (+badge), async, non-blocking
persist:     getThemeData().tracks[] += bpm, bpmConfidence, bpmOffset, bpmSource
             gs.transitionDefault += { tempoMode:'instant', snap:false }
engine:      transitionSeconds()       -> unchanged (already BPM-aware)
             armCrossfade()/startTransition()  -> if snap: nudge arm point to next bar line (outgoing bpm/offset)
                                               -> if tempoMode: playbackRate ramp on A/B elements (native preservesPitch)
             abCompleteHandover()      -> reset incoming playbackRate to 1.0 (real BPM) after Locked/Ramp
UI:          renderPlaylistManager()   -> BPM column + inline ½/×2/↻/edit
             openTransitionEditor()    -> + Snap row + Tempo-mode row
             gsSyncUI()/Global block   -> + Snap default + Tempo-mode default
```

**Dependency:** one vendored file (`vendor/realtime-bpm-analyzer/...`). No build step — it ships a UMD/global build we can `<script>` like Pickr/ColorThief. Offline mode needs only `AudioContext.decodeAudioData` (no AudioWorklet registration required for the offline path), so it works everywhere including Safari.

---

## 6. Phased delivery (each step ships a working, testable state)

**Step 1 — "BPM is real" (the unlock).** Vendor lib + `analyzeBpm` + auto-detect on upload + manual edit/½/×2/re-detect + BPM column. *Outcome: every track has a BPM; the dormant "bars" dropdown now produces correct durations.* Ship & verify.

**Step 2 — "No more galloping" (Locked tempo mode).** Add `tempoMode` + the playbackRate ramp in `startTransition`/`abCompleteHandover`. *Outcome: different-tempo tracks blend locked.* This is the single biggest perceived-quality leap.

**Step 3 — "Lands on the beat" (Snap-to-beat).** Add `snap` + bar-boundary nudge in `armCrossfade` (uses `bpm`+`bpmOffset`). *Outcome: fades exit on bar lines.*

**Step 4 — "Ramp" tempo glide (stretch).** Add the Ramp curve (both elements glide). *Outcome: imperceptible tempo transitions for long blends.*

Each step is independently valuable and deployable. I recommend doing **1 → 2 → 3**, treating 4 as optional polish.

---

## 7. Risks & decisions to confirm

1. **Library choice.** `realtime-bpm-analyzer` (recommended) vs `@audio/beat` (gives beat-grid/phase in one call, useful if we later want true incoming-phase-lock). *Decision: start with realtime-bpm-analyzer?*
2. **CORS on remote tracks.** Auto-BPM only works on files we can `fetch`+decode. Pixabay/Bandcamp remote tracks → manual BPM (or wait for the VIZ-21 audio proxy). *Acceptable?*
3. **Tempo-match tech.** Native `preservesPitch` (zero-dep, ±8% clean) now vs SoundTouchJS (pro, heavier) later. *Decision: native now, SoundTouchJS as a Phase-3 upgrade?*
4. **Scope of "beat-sync."** Bar-snap on the *outgoing exit* (simple, proposed) vs full *incoming phase-lock* (needs beatgrid, much harder). *Decision: outgoing bar-snap now, full phase-lock deferred to Phase 3?*
5. **Octave policy.** Auto-fold to 70–180 + show ½/×2, or ask the user on low-confidence results? *Decision: auto-fold + always-offer ½/×2?*

---

## 8. Sources
- realtime-bpm-analyzer (lib + docs + repo): [realtime-bpm-analyzer.com](https://www.realtime-bpm-analyzer.com/guide/introduction) · [npm](https://npm.io/package/realtime-bpm-analyzer) · [github](https://github.com/dlepaux/realtime-bpm-analyzer)
- Algorithm pipeline & benchmarks: [@audio/beat](https://github.com/audiojs/beat) · [Joe Sullivan – Beat detection with Web Audio](http://joesul.li/van/beat-detection-using-web-audio/)
- Other libs: [web-audio-beat-detector (guess→{bpm,offset})](https://github.com/chrisguttandin/web-audio-beat-detector) · [music-tempo (Beatroot)](https://github.com/killercrush/music-tempo) · [bpm-detective](https://www.jsdelivr.com/package/npm/bpm-detective)
- Beatmatching craft (tempo+phase, phrasing): [rhythmandpulse](https://rhythmandpulse.co.uk/tempomatching-vs-phasematching-vs-beatmatching/) · [Grokipedia – Beatmatching](https://grokipedia.com/page/Beatmatching) · [Transitions DJ – Mixing](https://www.transitions.dj/manual/pgs/mixing.html)
- Commercial analogues: [MixClap – Locked/Ramp + bars](https://mixclap.com/en/blog/bpm-beatmatching-complete-guide) · [DJ.Studio – BPM controls](https://help.dj.studio/en/articles/8261956-bpm-controls-tips-and-faqs) · [djay Pro – BPM vs Beat sync](https://help.algoriddim.com/user-manual/dj-tools/beatgrids-bpm-sync/sync)
- Tempo-matching tech: [preservesPitch+playbackRate (SO)](https://stackoverflow.com/questions/53791472/how-to-do-time-streching-audio-playback-using-javascript-in-2019) · [SoundTouchJS audio-worklet](https://www.npmjs.com/package/@soundtouchjs/audio-worklet) · [SoundTouchJS repo](https://github.com/cutterbl/SoundTouchJS)
