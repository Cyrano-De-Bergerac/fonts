# Visualisers — Actionable Task List

Every task needed to ship the visualiser suite in the Round Player, ordered for
**ease of implementation**. Tick boxes as tasks land.

**Status key:** ✅ done · 🟡 partial · ⬜ not started — Effort: ★ (trivial) → ★★★★★ (large)

> **Reconciled 2026-08-17** against what's actually shipped (script.js v192).
> Beyond the original plan below, two big additions have landed and are NOT
> numbered here: **8 Edge/Rim visualisers** (Entry S5–8: outer bars, mirror,
> bass ring, beat ripples, polar waveform, concentric rings, particle orbit,
> stacked blocks — independent controls + colours) and the **3D Rollercoaster**
> (lazy-loaded three.js, Entry S15).

---

## Phase 0 — Foundations (prereq for everything)

- [x] **VIZ-F1** `<canvas id="vizCanvas" class="viz-canvas">` on BOTH pages, absolute over the circle, `pointer-events:none`, hidden by default — ✅ v48
- [x] **VIZ-F2** Lazy Web Audio graph: `AudioContext` on first gesture; `createMediaElementSource` for `<audio>`+`<video>` (once each) → analyser → destination; `resume()` on play — ✅ v48
- [x] **VIZ-F3** Analyser defaults: `fftSize` 512 (configurable), smoothing 0.82, min/max dB −90/−10 — ✅ v48
- [x] **VIZ-F4** Canvas sizing: player rect × DPR, resized on `window.resize` — ✅ v48
- [x] **VIZ-F5** Theme-aware palette helper (`--progress-*`, `--btn-play-fg`) + Rainbow/Mono/Custom — ✅ v48

## Phase 1 — Core modes + the Visualisers tab

- [x] **VIZ-01** Visualisers tab: mode dropdown, sensitivity/smoothing/opacity/bar-count/colour-scheme/show-artwork — ✅ v48
- [x] **VIZ-02** **Frequency Bars** mode — ✅ v48
- [x] **VIZ-03** **Radial Spectrum** mode (ring, bass glow, rotation) — ✅ v48
- [x] **VIZ-04** **Waveform** mode (oscilloscope, mirrored) — ✅ v48
- [x] **VIZ-05** **Starfield** mode (pseudo-3D stars, bass-reactive) — ✅ v48
- [x] **VIZ-06** **Plasma** mode (sin-wave colour fields) — ✅ v48
- [x] **VIZ-07** Persistence: `localStorage` viz config, applied on load — ✅ v48
- [x] **VIZ-08** Server/deployed inheritance: `viz` in theme → `window.__serverViz` — ✅ v48
- [x] **VIZ-09** Live preview in editor — ✅ v48
- [x] **VIZ-10** rAF lifecycle (run while active, stop when Off) — ✅ v48
- [x] **VIZ-11** Automated tests — ✅ v48

## Phase 2 — Polish & more 2D modes

- [ ] **VIZ-12** **Mirrored bars** (in-circle, top+bottom) — ⬜ *(edge "Mirror Bars" ships the concept on the rim; in-circle mirrored bars not added)*
- [x] **VIZ-13** **Ring of fire** (glowing pulsing rings) — ✅ via edge **Bass Ring** + **Beat Ripples**
- [x] **VIZ-14** **Beat-reactive artwork** (cover pulses with bass) — ✅ `--beat-pulse` loop *(feel-tuning parked — user unsatisfied with prior attempts)*
- [x] **VIZ-15** **Particle field** — ✅ Starfield (in-circle) + edge Particle Orbit
- [ ] **VIZ-16** **Spectrum ribbon** (flowing gradient band) — ⬜ *(edge Polar Waveform is a blob, not a ribbon)*
- [ ] **VIZ-17** Preset drop-down (combos of mode+settings) — ⬜
- [x] **VIZ-18** Per-mode visibility rules in tab — ✅ *(star-size/fog/edge/custom rows show conditionally; edge-settings block toggles)*
- [ ] **VIZ-19** `prefers-reduced-motion` → static idle — ⬜
- [ ] **VIZ-20** Fullscreen visualiser (F key) — ⬜

## Phase 3 — Effects, integration & robustness

- [x] **VIZ-21** Same-origin audio proxy (`/proxy?url=…`, Range) so CDN sources feed the analyser (incl. Safari) — ✅ Entry S19 (Range-capable `/proxy` + client auto-routes cross-origin audio/video; same-origin/blobs bypass)
- [ ] **VIZ-22** Graceful "no analyser data" notice — 🟡 *(viz fills zeros silently; no user notice)*
- [ ] **VIZ-23** Visualiser toggle on the **deployed** player UI — 🟡 *(per-track viz already shows on deployed via applyTrackViz; no visitor-facing toggle button)*
- [x] **VIZ-24** Per-track visualiser override — ✅ *(per-track viz config saved + applied)*
- [x] **VIZ-25** Beat/onset detection helper — ✅ *(bass-flux engine in beatPulseLoop; drives beat-pulse + edge ripples)*
- [ ] **VIZ-26** Snapshot/export current visual as PNG — ⬜

## Phase 4 — Heavy / WebGL / advanced

- [ ] **VIZ-27** WebGL modes w/ 2D fallback: **Galaxy**, **Terrain** — 🟡 *(the 3D Rollercoaster is a WebGL mode; Galaxy/Terrain specifically not)*
- [x] **VIZ-28** **butterchurn** (Milkdrop) opt-in "Milkdrop" mode — ✅ Entry S20 (lazy-loaded Butterchurn core+minimal presets ~375KB; WebGL2 detect+graceful fallback; auto-cycling presets every 20s; DPR-aware canvas; audio-tapped via existing analyser graph)
- [ ] **VIZ-29** Preset export/import — ⬜
- [ ] **VIZ-30** Kaleidoscope mode — ⬜

---

## Scorecard
- **Done (✅):** Phase 0 (5), Phase 1 (11), VIZ-13/14/15/18/24/25, plus 8 Edge modes + 3D coaster.
- **Partial (🟡):** VIZ-22, VIZ-23, VIZ-27.
- **Open (⬜):** VIZ-12, 16, 17, 19, 20, 21, 26, 28, 29, 30.
- **Net:** the core + signature visualiser experience is shipped. Remaining items are extras/robustness, except **VIZ-21** which can be launch-critical for cross-origin media.

## Suggested next order
1. **VIZ-21** audio proxy — IF album media will be served cross-origin (verify hosting first); else skip.
2. **VIZ-28** Milkdrop (opt-in, lazy, zero impact on initial load) — the "wow" stretch goal; plan ready.
3. Cheap wins: VIZ-19 reduced-motion, VIZ-22 graceful notice, VIZ-23 deployed toggle.
4. Remaining 2D/WebGL modes as desired.
