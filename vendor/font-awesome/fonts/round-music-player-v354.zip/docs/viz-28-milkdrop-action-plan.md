# 🥛 VIZ-28 — Milkdrop (Butterchurn) Mode — Action Plan

> Add **Milkdrop** as an **opt-in, lazy-loaded** visualiser mode using
> **Butterchurn** (the WebGL2 port of Winamp's Milkdrop 2). Heavy dependency →
> fetched only when the user picks the mode, so it never affects initial load.
> **Status:** researched + plan ready. Awaiting go-ahead.
> **Created:** 2026-08-17 · script.js v192

---

## 1. What it is
[Butterchurn](https://github.com/jberg/butterchurn) is a faithful WebGL 2.0 + WASM port of **Milkdrop 2** (the iconic Winamp visualiser). It runs thousands of classic "preset" animations (geiss, flexi, martin, etc.) driven by the audio spectrum/waveform — the psychedelic flowing imagery people associate with Winamp. It's MIT-licensed and is the same engine Webamp uses.

## 2. Bundle size (measured, not estimated)
Probed the real files on unpkg:

| Asset | Raw | ~Gzip | Purpose |
|---|---|---|---|
| `butterchurn@2.6.7/lib/butterchurn.min.js` | **188 KB** | ~55 KB | core engine (UMD, global `butterchurn`) |
| `butterchurn@2.6.7/lib/isSupported.min.js` | 1.4 KB | <1 KB | WebGL2 capability probe |
| `butterchurn-presets@2.4.7/lib/butterchurnPresetsMinimal.min.js` | **187 KB** | ~40 KB | curated preset pack (~170 presets) |
| (full presets, NOT recommended) | 638 KB | — | `butterchurnPresets.min.js` (all) |
| (extra presets) | 825 KB | — | `butterchurnPresetsExtra.min.js` |

**Recommended ship set = core + minimal presets ≈ 375 KB raw / ~95 KB gzip.**
Because it's **lazy-loaded only when "Milkdrop" is selected**, this adds **0 bytes to initial page load** — fully consistent with the performance budget (`docs/PERFORMANCE-GUIDE.md`).

## 3. Requirements
- **WebGL 2.0** (most modern browsers; not some old mobile/Safari). Feature-detect up front; if unsupported, the mode is hidden/disabled and falls back gracefully.
- **Web Audio graph** — we already have it (`ensureVizGraph`); Butterchurn taps an analyser/audio node.
- UMD globals (`window.butterchurn`, `window.butterchurnPresets`) → lazy-load via `<script>` injection + poll (the library isn't an ES module).

## 4. Do we have what we need? — **Yes.**
- ✅ Web Audio analyser graph (feed Butterchurn's `connectAudio()`).
- ✅ Lazy-load pattern (we lazy-load three.js for the coaster; same idea, script-injection flavour for UMD).
- ✅ Visualiser mode framework (mode dropdown, rAF lifecycle, per-track persistence).
- ✅ Performance discipline (one heavy mode at a time; lazy; the guide).
- ➗ We only need to **vendor the 3 files** + write the **WebGL2 detect + integration glue + preset UI**.

## 5. Should we finish other phases first? — **No hard blocker, but one launch check first.**
There's **no prerequisite** that blocks VIZ-28 — it's self-contained and opt-in. However, before spending effort on Milkdrop, confirm the one **launch-critical** item: **VIZ-21 (audio proxy)**. Reason: visualisers only animate if the analyser receives audio data, and **cross-origin media (a CDN without CORS headers) gives the analyser nothing → every visualiser is dead on the deployed page.** If your 14-track media will be served **same-origin** (from your own host), you're fine and can skip straight to VIZ-28. If any media is cross-origin, do VIZ-21 first.

## 6. Implementation plan

**Step 1 — Vendor the assets** (`vendor/butterchurn/`): download `butterchurn.min.js` (188 KB), `butterchurnPresetsMinimal.min.js` (187 KB), `isSupported.min.js` (1.4 KB). Add MIME for `.js` (already served). ~375 KB total — within workspace budget (currently 46 MB).

**Step 2 — WebGL2 probe + lazy loader:** `ensureButterchurn()` injects the two core scripts on demand, resolves when `window.butterchurn` + presets are ready; `butterchurnIsSupported()` wraps `isSupported` (or a `canvas.getContext('webgl2')` check). Mode disabled/hidden if unsupported.

**Step 3 — "Milkdrop" mode entry** in the Visualisers mode dropdown (after the existing modes). On select: ensure graph → ensureButterchurn → create a dedicated WebGL `<canvas>` in the media window → `butterchurn.createVisualizer(audioContext, canvas, {w,h})` → `connectAudio(analyser)` → `loadPreset(...)`.

**Step 4 — Render loop:** a rAF that calls `visualizer.render()`; auto-cycle presets every N seconds (configurable) with a short blend; pause the loop when the mode is off (like the other modes). Size the canvas DPR-aware (cap 1.5×) and resize on player resize. Only ONE heavy mode runs — entering Milkdrop pauses the 3D coaster and vice-versa.

**Step 5 — Preset picker UI:** a small dropdown (or ◀ ▶ cycle) of the minimal-pack preset names in the Visualisers tab, shown only for Milkdrop mode; chosen preset persists per track.

**Step 6 — Persist + deploy:** add `milkdropPreset` to the per-track viz config (like the other modes) so it saves and shows on the deployed page. Verify on `dev.html` and the deployed `index.html`.

**Step 7 — Verify & ship:** `node --check`; bump `script.js` `?v=`; restart; rebuild `round-music-player-v<N>.zip`; confirm lazy-load (Network tab: butterchurn NOT fetched until mode picked), GPU framerate, graceful fallback on a WebGL2-less device, and that initial load is unchanged.

## 7. Risks / watch-items
- **WebGL2 not universal** → must degrade silently (mode unavailable), not crash.
- **GPU cost** → cap canvas size, one heavy mode at a time, pause when off-screen/hidden.
- **Preset pack size** → ship Minimal (187 KB), not Full (638 KB); let power users add more later.
- **Audio tap** → connect to the analyser we already create (don't add a second graph); verify CORS-clean same-origin media feeds it on the deployed page (ties to VIZ-21).
- **UMD lazy-load** → script-injection + ready-poll (not `import()`, since it's not ESM).

## 8. Effort
~1 focused session: vendor (10 min) + WebGL2 detect + lazy loader + integration glue + render loop + preset UI + persistence + verify. Low–medium risk; the engine is mature and well-documented.

---

*Ready to build on your go-ahead. First confirm: **will the album media be same-origin on your host?** (Decides whether VIZ-21 must come first.)*
