# 🎵 Circular Music Player — Arena Chat Context

> **Living handoff document.** Upload this file into a new Arena chat whenever a
> chat gets too long and you must start fresh. It gives the new chat the full
> project context — architecture, conventions, design decisions, current state,
> and a chronological session log — so work can continue without lost context.
>
> **Format:** Markdown (Arena renders it; readable as plain text too).
> **Location:** `/home/user/docs/PROJECT-CONTEXT.md`
> **Last updated:** 2026-08-20

---

## 0. 🚀 How to use this document (read first)

### If you are a NEW chat continuing this project
1. **Read this whole document.** It is dense on purpose — every line is load-bearing context.
2. The Node server stops between turns/chats. **Start it before any work:**
   ```bash
   cd /home/user && node server.js   # binds 0.0.0.0:3000
   ```
   (Use `start_process` for a long-lived server; see §4.)
3. Skim §3 (file map) and §4 (operational gotchas) — these prevent the most common mistakes.
4. The **Session Log** in §8 is the chronological history of what was asked, diagnosed, and done. Read from the bottom for recent activity.

### How to keep this document "live"
After **every** completed task, the assistant **must append a new entry to §8 (Session Log)** using the template in §9, and update §6 (current state) / §1 (versions) if anything changed. The user can also say *"update the context doc"* to force a refresh.

---

## 1. Project at a glance

- **What:** A **Circular Music Player** web app — a round player disc with a rotating/scrubbing playhead, cover art, audio/video media, a 2D + a 3D "rollercoaster" visualiser, cinema/immersive video mode, beat-synced DJ transitions, and a circular playlist disc that overlaps the player.
- **Stack:** Zero-dependency **Node.js** backend (`server.js`) serving static files + small REST APIs. Vanilla JS frontend (`script.js`), plain CSS (`styles.css`). Three.js r124 for the 3D visualiser (vendored, ES modules).
- **Runs at:** `http://localhost:3000` (binds `0.0.0.0`). Launcher = `hub.html`.
- **Current versions** (these are cache-busting query params; bump on every code change to that file):
  | File | Version | Source |
  |------|---------|--------|
  | `script.js` | **v303** | `<script src="script.js?v=303">` — also drives the on-screen version badge |
  | `styles.css` | **v300** | bumped alongside script.js |
  | `viz3d.js` | **v140** | lazy-loaded via dynamic `import('./viz3d.js')` (multi-instance, Entry S21) |

---

## 2. Architecture

### Backend — `server.js` (zero-dependency, Node 20)
- Binds `0.0.0.0:3000`.
- **Static serving** (range-aware, supports HTTP Range for media seeking).
- **All responses** send `Cache-Control: no-store, no-cache, must-revalidate, max-age=0`. HTML pages also carry `<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate" />`.
- **API endpoints:**
  - `GET/POST/DELETE /api/theme` — persisted theme (server-side `data/theme.json`).
  - `POST /api/upload` — multipart upload.
  - `POST /api/upload-chunk` — JSON chunked upload.
  - `GET /api/ping`, `GET /api/uploads`.
- `/data/` is **private** (returns 404) — never served directly.

### Frontend pages
- **`index.html`** — the deployed player page (what end users see).
- **`dev.html`** — the designer/editor page (editor + live player). Side-by-side layout: player on the left, a tabbed box (Editor | Playlist Manager) on the right. This is where most work/test happens.
- **`hub.html`** — launcher page (root `/`).
- **`status.html`** — server diagnostics.

### Player DOM structure (`.music-player`)
A circle (`border-radius: 50%`, `overflow: hidden`) containing, in z/DOM order:
- `#cover.album` — cover-art **image** (the backdrop layer).
- `#coverVideo.album` — **video** element (transparent so letterbox reveals cover art).
- `.viz-canvas` — 2D visualiser canvas (top half = "media window").
- `.viz-canvas-3d` — 3D rollercoaster visualiser canvas (WebGL, own element).
- `.viz-fog-layer` — black-fog backdrop layer between artwork and the 3D canvas.
- `#vizCanvas` — (legacy/2D) visualiser.
- `.drag-overlay` — full-circle grab surface used while repositioning media.
- `.dash` — the control surface (panel, controls, info, seeker, playhead).

`.knob-overlay` = the **visible playhead** dot. `.arc-knob` = its invisible hit target.

### Visualiser modules
- **`viz3d.js`** — the 3D rollercoaster (ES module, three.js r124). Exposes `window.RoundViz3D = { ready, active, setActive(on), resize(), setColors(s), setIntensity(v), getIntensity(), setFog(v) }`. Uses `EffectComposer` + `RenderPass` + `UnrealBloomPass`. Custom ShaderMaterial on a TorusKnot ribbon with seamless seam-closure frame blending.

### Vendor libraries (all vendored, no network needed)
- `vendor/three/` — Three.js r124 (modules + postprocessing + curves).
- `vendor/bpm-detect/bpm-detect.js` — bespoke BPM analyzer.
- `vendor/font-awesome/` — FA 4.7.
- `vendor/colorthief/color-thief.global.js` — Color Thief shim.
- `vendor/pickr/` — Pickr 1.8.2.

### Data & uploads
- `data/theme.json` — persisted theme (server).
- `uploads/` — uploaded media files.
- `test/test_tone.mp3`, `test/test_cover.png` — seed media.

---

## 3. File map

| Path | Role |
|------|------|
| `/home/user/server.js` | Node server (zero-dep), port 3000 |
| `/home/user/script.js` | Main player logic (~7000+ lines), v184 |
| `/home/user/styles.css` | All styles, v184 |
| `/home/user/index.html` | Deployed player page |
| `/home/user/dev.html` | Designer editor page (editor + player) |
| `/home/user/hub.html` | Launcher page |
| `/home/user/status.html` | Server diagnostics |
| `/home/user/viz3d.js` | 3D rollercoaster visualiser (ES module, three.js r124), v139 |
| `/home/user/scallop.png` | Scallop panel mask (rebuilt) |
| `/home/user/vendor/...` | Vendored libs (see §2) |
| `/home/user/test/...` | Seed media |
| `/home/user/data/theme.json` | Persisted theme |
| `/home/user/uploads/` | Uploaded media |
| `/home/user/docs/PROJECT-CONTEXT.md` | **THIS document** (handoff context) |
| `/home/user/docs/PHASE2-WORKLOG.md` | Running worklog transcript (entries to date) |
| `/home/user/docs/PHASE2-PROGRESS.md` | Checkpoint/progress log |
| `/home/user/test_independent_transform.js` | jsdom regression test for art/video independence |

---

## 4. ⚠️ Critical operational knowledge (gotchas & conventions)

### Server restart protocol
- **The Node server stops between turns/chats — assume it is DOWN at the start of every task.** Restart it after any code change and verify the new version is served.
- **NEVER** use `pkill -f "node server.js"`. To free port 3000 use:
  ```bash
  fuser -k 3000/tcp
  # or, if that doesn't kill it:
  ss -tlnp | grep ':3000' | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -u | xargs -r kill -9
  ```
- For a long-lived server use the `start_process` tool (not `bash`).

### Versioning & cache-busting
- Each frontend file has a `?v=N` query param in its `<script>`/`<link>` tag. **Bump it on every code change to that file** so browsers fetch fresh code (server sends no-store, but query bump is belt-and-suspenders for the live preview).
- The on-screen **version badge is derived from `?v=` on `script.js`**. `viz3d.js` has its own separate `?v=` (currently 139).
- After editing, run `node --check <file>` for syntax validation on pure JS. (`viz3d.js` is an ES module — `node --check` still validates syntax without resolving imports.)

### Editing rules
- Use `cat -A` or `sed -n` to get **EXACT** text before patching with `edit_file`.
- The `edit_file` tool **requires the `path` parameter** — forgetting it throws "Something went wrong".
- Fuzzy matching tolerates whitespace/indentation differences.

### The user's working style
- **Prefers direct action over asking questions** when intent is clear. Ask only when ambiguity genuinely blocks a good result.

### Things you must NOT change
- **`--overlap-fraction: 0.12`** — the 12% overlap between the main player and the playlist panel. Intentional. Leave it.
- **The `.seeker` (400×200px) and `.wheel` (364×364px)** are huge containers at the bottom of the player that visually cover everything — **do NOT use them in cinema zone-hit-testing guards** (they'd swallow the whole surface).

### Caching
- Server already forces `no-store`. Don't add extra cache headers.

---

## 5. 🧠 Key design decisions ("why it's how it is")

### A. Drag/zoom layers use CSS variables (no JS transform swaps)
Each media layer has its own `translate/scale` driven by CSS custom properties. Repositioning/zooming writes a CSS var; the CSS `transform` reads it.

| Layer | Non-cinema vars | Cinema vars |
|-------|-----------------|-------------|
| **Video** (`#coverVideo`) | `--cover-dx/dy/scale` | `--cinema-dx/dy/scale` |
| **Cover-art backdrop** (`#cover`) | `--art-dx/dy/scale` | (shares `--art-*`) |
| **Visualiser** (2D + 3D + fog) | `--viz-dx/dy/scale` | `--viz-cinema-dx/dy/scale` |
| **Wave panel** (`.dash`) | `--panel-dx/dy/scale` | (none yet — see §7) |
| **Playlist panel** backdrop | `--pl-art-*` (cover) / `--pl-vid-*` (video) | (mirror mode, see below) |

**Why:** independent cinema/non-cinema framing. The user can reposition/zoom media differently for the normal view vs the cinema view, and both persist per track. This is implemented purely with CSS (the `.cinema` class switches which vars the `transform` reads, with fallbacks) — **no JS swap**. (An earlier JS transform-swap caused a grey anomaly in the playlist panel by saving `coverScale=1` pre-fill; removing the swap entirely fixed it.)

**Helper functions in `script.js`:**
- `coverVar(suffix)` → `(cinema ? '--cinema-' : '--cover-') + suffix`
- `vizVar(suffix)` → `(cinema ? '--viz-cinema-' : '--viz-') + suffix`
- `persistCoverTransform()` → saves to `t.cinemaTransform` (if `.cinema`) else `t.transform`.
- `persistVizTransform()` → saves to `t.vizCinemaTransform` (if `.cinema`) else `t.vizTransform`.
- `loadTrack()` sets BOTH var sets: `--cover-*` from `t.transform` AND `--cinema-*` from `t.cinemaTransform` (or a copy of `--cover-*` if unset). Same for `--viz-*` / `--viz-cinema-*`.

### B. Cinema / immersive video mode
- `engageCinema(on)` **just toggles the `.cinema` class** — no transform swap.
- The `.cinema` class hides the control surface (panel, icons, buttons, text) but keeps the scrubber + playhead (track stays scrubbable).
- **`cinemaStyleForTrack()`** returns `'head'` only if `t.cinemaStyle === 'head'`, else `'bar'`. No global fallback.
  - `head` = playhead dot only (hides progress track/tail/wheel).
  - `bar` = progress bar kept visible (default).
- **`cinemaOnPlay()`** engages cinema for ANY video track while playing (not just video-master tracks).
- Checkbox handler: checking the box → `engageCinema(true)` if `videoMediaActive()`; unchecking → `engageCinema(false)`.
- `onPause` does **NOT** force-disengage cinema (removed earlier to fix a white flash).
- `mouseleave` re-engages cinema if `videoMediaActive() && cinemaEnabledForTrack() && state.master && !state.master.paused`.
- **Cinema mousemove handler (v184) zones:**
  - Top **55%** → cinema stays ON (video area, draggable/zoomable).
  - Playhead dot (`.knob-overlay`, `.arc-knob`) → cinema stays ON (scrubbable).
  - Rest of the bottom **45%** → **250ms dwell** → reveal controls.
  - While scrubbing (`state.dragging`) → cinema stays ON.

### C. Cover art is ALWAYS visible behind the video
- `#cover.album { display: block !important; }` and `#coverVideo.album { background: transparent !important; }`. The video is transparent so letterbox gaps reveal the cover-art backdrop. The `.video-active` class (kept in sync via `syncVideoActive()` + a MutationObserver on `el.coverVideo`) routes the cover `<img>` to the `--art-*` vars so cover + video move independently.

### D. Playlist panel (circular disc overlapping the player)
- Per-track flags: `t.plMedia` (default **OFF**), `t.plMirror` (default **ON**), `t.plVideoOn` (default **ON**).
- **plMedia OFF = colors scheme** (uses `--pl-base` / `--pl-grad` from the Colors tab). Media backdrop hidden.
- **Mirror mode** = the playlist panel mirrors the main player's cinema view.
  - `syncPlVideo()` mirrors play/pause/time/rate to the panel's video.
  - `syncPlMirror()` mirrors `--cinema-*` → `--pl-vid-*` (only while cinema is ON; **freezes** otherwise) and `--art-*` → `--pl-art-*`.
- **Migration** clears stale `plMedia=true` from **both** localStorage AND the in-memory `demoPlaylist` (guard flag `_plMediaMemCleared`).

### E. The 3D rollercoaster visualiser (`viz3d.js`)
- Renders inside the round player's **media window (top half)**.
- Camera = original codepen behaviour (Frenet binormal up) but with a **seam-closure frame blend** so the loop joins seamlessly (~88% original feel, last 20% is a smooth twist). This fixed a violent camera snap at the wrap.
- Distance fog fades the far track to **transparent** (not opaque black) so the artwork shows through; the canvas uses `mix-blend-mode: screen` so black → transparent.
- `.viz-fog-layer` is a black backdrop whose opacity (driven by `setFog(0..1)`) dials the black background in/out AND scales the track's fog density.
- Audio-reactive bloom via `setIntensity()` (called every frame by the main script).

---

## 6. ✅ Current state (what's done)
- **Full workstation:** server.js, vendor libs, seed assets, `dev.html` editor, `index.html` deployed, `hub.html` launcher.
- **DJ Phase 2:** BPM detection, beat-synced transitions, tempo modes (Instant/Locked/Ramp via native `preservesPitch`, >12% gap auto-fallback).
- **Cinema mode:** auto-hide controls on video tracks, progress-bar / playhead-only styles, zone-based reveal.
- **Independent cinema/non-cinema framing** for video (`--cover-*/--cinema-*`) and visualiser (`--viz-*/--viz-cinema-*`) — no JS swap. Fog layer follows the visualiser transform.
- **Per-track playlist panel backdrop:** cover art + video, mirror mode, drag & drop, independent reposition/zoom, media on/off, video on/off. Defaults to OFF (colors scheme).
- **Playlist video sync (mirror mode):** play/pause/time/rate; freezes on cinema framing when controls reveal.
- **Visualiser framing:** Reposition/Reset/Zoom in the Visualisers tab, cinema-aware.
- **Editor cleanup:** two sub-tabs (Edit Main Player / Edit Playlist Panel).
- **Repositioning/zoom persistence** per track (both cinema & non-cinema, video & visualiser). Fixed cover-zoom slider + overlay wheel-zoom persistence.
- **Crossfade handover:** uses `nt` (not `t`) for cinema transform restore.
- **plMedia migration:** clears stale `plMedia=true` from localStorage AND in-memory.
- **3D visualiser zoom no longer pixelates** (drawing buffer now matches on-screen zoom) — see Session Log Entry S1.

---

## 7. 🅿️ Parked / not-yet-solved
- **Beat-pulse artwork feel** — PARKED. User was not satisfied with any of 4 approaches tried.
- **Cinema for non-video tracks** — ✅ DONE (Entry S11): cinema now engages for cover-art / visualiser tracks too, anytime it's enabled.
- **Artwork transform persistence per track for the playlist panel** — currently per-session only.
- **Independent cinema/non-cinema framing for the wave panel (`--panel-*`)** — only video and visualiser have it so far.
- *(Watch items)* Potential white rectangle when adding video; playhead scrubbing reliability.

---

## 8. 📒 Session Log (LIVING — append newest at the bottom)

> Each entry captures: **the user's request → the diagnosis (thinking) → the processing
> (files/commands) → the outcome.** Newest tasks go at the END.

### Prior context (from earlier sessions — condensed)
- Built the full workstation (server, vendor, seed assets, editor, deployed player, launcher).
- Implemented DJ Phase 2 (BPM detection, beat-synced transitions, tempo modes) — `patch-phase2*.py` re-runnable; persisted per-track `bpm` fields + transition `tempoMode/snap`.
- Built cinema mode + zone-based reveal; removed a JS transform swap that caused a grey anomaly in the playlist panel (now pure CSS vars).
- Added independent cinema/non-cinema framing for video and visualiser.
- Added the per-track playlist panel backdrop (cover + video, mirror mode, drag & drop, media on/off).
- Fixed `.video-active` sync so cover `<img>` and video move independently (regression test `test_independent_transform.js`).
- Progressed versions up to **script.js v184 / viz3d.js v138** before the entry below.

---

### Entry S1 — 3D rollercoaster visualiser pixelates when zoomed in  *(2026-08-17)*

**User request:**
> "When I zoom in on the rollercoaster 3d visualiser it starts to pixelate. Can you make it so that when I zoom in it keeps its visual integrity?"

**Diagnosis (thinking):**
- The visualiser zoom is a **CSS `transform: scale(--viz-scale)`** on `.viz-canvas-3d`. But the **WebGL drawing buffer** in `viz3d.js`'s `layout()` was sized only to the canvas's base CSS size (top half of the player) and never grew with the zoom. So zooming in just **stretched** the fixed-resolution pixels across a larger screen area → pixelation.
- A `1.5×` pixel-ratio cap made it worse the more you zoomed (effective resolution ≈ `1.5 / (dpr × scale)` drawing pixels per device pixel).
- Also found a latent issue: the bloom `EffectComposer`'s `_pixelRatio` was captured at construction (=1, before `setPixelRatio` ever ran), so its render targets were lower-res than the canvas backing store → bloom/scene were soft-upscaled onto the larger canvas.

**Processing (files & commands):**
- Edited **`viz3d.js`** (only file with logic changes):
  - Added `effectiveVizScale()` — cinema-aware reader of `--viz-cinema-scale` / `--viz-scale` (mirrors `vizVar()` in the main script).
  - `layout()` now sizes the drawing buffer = **base CSS size × zoom scale** (`BW = W × scale`, `BH = H × scale`). Camera aspect still uses base `W/H` (both dims scale equally → framing unchanged). Also calls `composer.setPixelRatio(pr)` so bloom render targets match the canvas.
  - `loop()` reads `effectiveVizScale()` each frame and only re-runs `layout()` when it actually changed — catches **all** zoom sources (editor slider, mouse wheel, double-click reset, track load, crossfade, cinema toggle) with no per-call-site wiring. Steady-state cost = one cheap style read per frame.
- Cache-bust: `viz3d.js?v=138 → v139` in `index.html` + `dev.html`. (`script.js` v184 untouched.)
- Restarted server (`fuser`/`ss`+`kill -9` to free 3000, then `node server.js`); verified served `viz3d.js` contains the new functions and `?v=139`; confirmed `Cache-Control: no-store`. `node --check viz3d.js` passed.
- Updated `docs/PHASE2-WORKLOG.md` (Entry 55) and `docs/PHASE2-PROGRESS.md`.

**Outcome:**
- ✅ Zooming the 3D visualiser (in or out) now keeps ~1 buffer pixel per displayed pixel at every zoom level — no pixelation. The ride's look (camera, FOV, bloom strength, fog) is unchanged; it's just crisper when zoomed. Verified live in the preview.

---

<!-- ═══════════════════════════════════════════════════════════════════ -->
<!-- APPEND NEW SESSION ENTRIES BELOW THIS LINE using the template in §9 -->

### Entry S2 — Reformat features-checklist.md into a readable document *(2026-08-17)*

**User request:**
> "When i bring up 'features-checklist.md' it's in a hard to read format. Please make it open and look like a document."

**Diagnosis (thinking):**
- File was valid Markdown but unreadable: every feature was a dense one-liner mixing `[x]` checkboxes, bold IDs, middots, em-dashes, emojis, and notes (×184) — a wall of text.

**Processing (files & commands):**
- Wrote a parser (`reformat_checklist.py`) that transformed each section into a GFM table (`ID | Feature | Status | Notes`), plus a computed progress dashboard + TOC.
- Hit a read-own-output bug (script read & wrote the same file → second run re-parsed the table version). Recovered the original from captured content into a separate source, re-ran once. Fixed TOC title repetition, stray status emojis in note cells, and the FM-09 row (em-dash inside parentheses). Removed scratch files.
- Output: **`uploads/features-checklist.md`** (dashboard + TOC + 15 tables; all 184 items preserved).

**Outcome:**
- ✅ Checklist now opens as a scannable document.

---

### Entry S3 — Update Section C (Visualisation suite) statuses in the checklist *(2026-08-17)*

**User request:**
> "Check C. Visualisation suite and update. We have addressed some of these in the player but the status still says to do."

**Diagnosis (thinking):**
- Inspected the player's Visualisers tab + `script.js` draw functions. The player actually ships **6 modes**: `bars`, `radial`, `waveform`, `starfield`, `plasma`, `coaster` (`viz3d.js`, three.js), plus Sensitivity/Smoothing/FFT-size controls, colour palettes (theme/rainbow/mono/custom), per-track+global persistence, and an active `beatPulseLoop()` animating `--beat-pulse` on detected beats.

**Processing (files & commands):**
- Updated the 13 VIZ rows in `uploads/features-checklist.md`: **8 → Done** (VIZ-01 bars, -02 radial, -03 waveform, -05 starfield particle field, -07 3D WebGL, -08 switcher+persist, -09 sensitivity/smoothing/FFT, -10 colour palette); **2 → Partial** (VIZ-06 radial-burst flavour only/no spiral; VIZ-12 beat-pulse active but "feel" parked); **3 stay To do** (VIZ-04 ribbon, VIZ-11 fullscreen, VIZ-13 PNG snapshot).
- Updated dashboard: Section C `0/0/13/0%` → `8/2/3/62%`; TOTAL `53/12/119/29%` → `61/14/109/33%` (verified against a ground-truth recount of all 184 rows).

**Outcome:**
- ✅ Section C now reflects reality.
- ⚠️ Note: this confirms other checklist items are also stale (e.g. **PL-17/TR-07 BPM detection** and **TR-04 true crossfade** are live). A full checklist refresh was offered but deferred until requested.

---

### Entry S4 — Edge / circumference visualisers: research + action plan *(2026-08-17)*

**User request:**
> "Please look at 'Vizzy.io'. They have a visualizer that is able to pulse around the circumference of a circle. I would like to have visualisers that use the outer edge of the circular player. Please do extensive research into the different variations of visualiser that operate around the edge of a shape and create an action plan on how to implement those into our player."

**Diagnosis (thinking):**
- Researched Vizzy.io + the ecosystem (SoundTools "Ring of Fire"/"Circular Spectrum", Banger, dmeldrum6 ref-impl, IUSV, nelsonr, basicfreetools, etc.). Core technique = FFT bins → polar angles → `cos/sin` radius `R ± amplitude`.
- **Key structural constraint found:** `.music-player` is `overflow:hidden`, so outward (Vizzy-style) pulsing is **cropped at the rim**. Fix = a new **un-clipped edge canvas** as a sibling of the player inside `.player-pair` (not inside it).
- Catalogued **12 edge-visualiser variations** (outer bars, mirror/dual, bass ring, beat ripples, polar waveform, concentric frequency rings, particle orbit, stacked blocks, ribbon/filled, spiral/galaxy, kaleidoscope, scope ring). Most reuse the same polar-math core.
- Confirmed we already have the hard parts (AnalyserNode graph, palette, beat engine, per-track persistence, bloom) → this is an **additive** feature.

**Processing (files & commands):**
- Wrote **`docs/edge-visualisers-action-plan.md`** — research/ecosystem table, 12-variation catalogue, architecture (edge layer + the `overflow:hidden` fix), 3-phase roadmap (E1 = Outer Bars + Mirror + Bass Ring + Beat Ripples), detailed Phase-E1 steps incl. a `drawEdgeBars()` code sketch, integration notes, 6 open design decisions, effort estimate, 12 references.
- No code changes (planning only). Server untouched.

**Outcome:**
- ✅ Plan delivered. **Awaiting go-ahead + answers to §8** (scope, outward box size, cinema behaviour, playlist-open behaviour, mode UX, layering) before Phase E1 implementation.

---

### Entry S5 — Edge/circumference visualisers IMPLEMENTED (Phases E1+E2, v185) *(2026-08-17)*

**User decisions (from §8):** scope = **E1+E2 (8 modes)**; reach = **adaptive per-track slider**; cinema = **keep visible**; layering = **edge + in-circle run together**.

**Diagnosis (thinking):**
- `.music-player` is `overflow:hidden`, so outward (Vizzy-style) pulses would be cropped. Solution = a new **un-clipped `.viz-edge` canvas as a sibling of `.music-player` inside `.player-pair`** (not inside the clipped disc).
- Made the edge layer **independent**: own canvas, own rAF (`vizEdgeTick`), own mode (`viz.edgeMode`) + reach (`viz.edgeReach`), so it layers on top of the in-circle visualiser rather than replacing it.
- Reuses the existing AnalyserNode graph, palette (`vizColor`/`vizPalette`), and per-track persistence (`saveCurrentAsTrackViz`/`trackVizConfig`). Beat ripples use a self-contained bass-onset detector (no coupling to the beat engine).

**Processing (files & commands):**
- **`script.js` (v184→v185):** added `edgeMode`/`edgeReach` to the `viz` object + `VIZ_DEFAULTS`; edge state vars + `EDGE_BOX=1.7`; `ensureEdgeCanvas()`/`sizeVizEdgeCanvas()` (DPR-aware, auto-resize); 8 draw fns (`drawEdgeBars/Mirror/BassRing/Ripples/Polar/Rings/Orbit/Blocks`); `vizEdgeTick()` dispatcher; `applyEdgeViz()`; wired into `applyTrackViz`, `vizSyncUI`, `attachVisualizerUI` (bindings), and both track-viz save paths. Applied via an auditable Python patch (9 replacements, all asserted).
- **`dev.html`:** new "Edge / Rim visualiser" section — `<select id="vizEdgeMode">` (Off + 8 modes) + `<input id="vizEdgeReach">` slider. Versions bumped (script v185, styles v181).
- **`styles.css` (v180→v181):** `.viz-edge` (absolute, centred, `pointer-events:none`, z-index 11, `display:none`/`.visible`), `body.playlist-open .viz-edge{opacity:.35}`, `#vizEdgeReachRow` show/hide.
- `node --check` OK; server restarted; served v185 confirmed; 8 options ↔ 8 switch cases ↔ CSS all present.

**Outcome:**
- ✅ 8 edge visualisers live. Test in **dev.html → Visualisers tab → Edge mode** (Outer Bars = the Vizzy look). Best viewed full-ring on the deployed **index.html** (dev's right panel can overlap the rim slightly). Stays visible in cinema; layers with the in-circle mode; reach slider + per-track save work. E-9 Ribbon (closes checklist VIZ-04) still pending as Phase E3.

---

### Entry S6 — Edge visualiser fixes: glide with player + Beat Ripples (v186) *(2026-08-17)*

**User request:**
> "It needs to animate with the player so that when the playlist is opening the visualiser moves with the main player exactly in time so that it ends up with the main player on the lefthand side of the playlist panel. Also, 'Beat ripples' doesn't do anything, apparently."

**Diagnosis (thinking):**
- **Glide:** `.viz-edge` only had the centering `translate(-50%,-50%)`, while `.music-player` glides via `translateX(calc(var(--open) * -1 * var(--pair-gap)))` (1.1s cubic-bezier). `--open` is set on `document.documentElement`, so `.viz-edge` inherits it — just needed the same glide + easing added.
- **Beat Ripples:** my onset detector's `bass > 0.22` threshold (avg of 8 bins /255) was too high for softer tracks, and ripples were thin (lw 2, alpha 0.55) → little/nothing visible. The player already has a **proven beat engine** (`_gpLast` kick-onset in `beatPulseLoop`).

**Processing (files & commands):**
- **`styles.css` (v181→v182):** `.viz-edge` transform now `translate(-50%,-50%) translateX(calc(var(--open) * -1 * var(--pair-gap)))`; transition `transform 1.1s cubic-bezier(.22,1,.36,1), opacity .4s ease` — matches the player exactly.
- **`script.js` (v185→v186):** rewrote `drawEdgeRipples` — now driven by the **shared beat engine** (`_gpLast` increase = real beat) PLUS a local kick-flux fallback (mirrors the engine's flux method, so it fires even if the artwork beat-pulse toggle is off). Ripples brighter (a 0.78), thicker (bass-scaled), with `shadowBlur` glow, longer-lived (decay 0.972), refractory 0.12 s to avoid double-spawn.
- `node --check` OK; server restarted; v186 + both changes verified served; pages 200.

**Outcome:**
- ✅ Edge visualiser now glides left in perfect sync with the main player (ends on the LHS of the playlist panel).
- ✅ Beat Ripples now fire on real detected beats (and local onsets) and are clearly visible.

---

### Entry S7 — Independent edge controls + per-visualiser colours (v187) *(2026-08-17)*

**User request:**
> "Give me the same, but independent, sensitivity, smoothing, opacity, bar etc. sliders for the edge visualiser. Also, I need in both cases [inner + edge] the ability to set the visualisers colours to either match the player with the choices made in the 'Colors' section or to individualise the colours if need be."

**Diagnosis (thinking):**
- Edge was reusing the shared `viz.sensitivity/smoothing/opacity/bars/colors`. For **truly independent smoothing** the edge needs its **own AnalyserNode** (one analyser = one smoothing value); sensitivity/opacity/bars/colours just need their own state + draw-time reads.
- "Match player" already maps to `theme` (palette reads the player's `--progress-*` theme vars = the Colors section); "individualise" = `custom`. Just needed an independent mode + custom set for the edge, and clearer labels.

**Processing (files & commands):**
- **`script.js` (v186→v187)** via an asserted patch:
  - Added `edgeSensitivity/edgeSmoothing/edgeOpacity/edgeBars/edgeColors/edgeCustomColors` to `viz` + `VIZ_DEFAULTS`; module vars `edgeAnalyser`, `vizEdgeFreq`.
  - `ensureVizGraph()` now also creates a **second analyser** (`edgeAnalyser`, fft 512) tapping `vizMasterGain` — independent smoothing.
  - New `edgePalette()`/`edgeColor()`/`edgeColorA()` (theme vars shared with player; colours-MODE + custom set are the edge's own). Edge draw functions + `vizEdgeTick` rewired (region-scoped) to use `viz.edgeSensitivity/edgeBars/edgeOpacity`, `edgeColor/edgeColorA`, `edgePalette()`, and `vizEdgeFreq` from `edgeAnalyser`.
  - `vizSyncUI` syncs all edge controls + toggles `#vizEdgeSettings` (on when an edge mode is active) and `#vizEdgeCustomRow` (on when edge colours = custom); `attachVisualizerUI` binds them (smoothing updates `edgeAnalyser.smoothingTimeConstant` live); both track-viz save paths persist the new fields.
- **`dev.html`:** replaced the lone Edge-reach row with a full **Edge settings block** (Reach, Sensitivity, Smoothing, Opacity, Bars, Colours dropdown, custom 3-colour swatches). Relabelled both visualisers' theme option to **"Theme (match player)"** and custom to **"Custom (individual)"**.
- **`styles.css` (v182→v183):** `#vizEdgeSettings`/`#vizEdgeCustomRow` show/hide rules (replacing the old reach-row rule).
- `node --check` OK; server restarted; v187 + all controls verified served; pages 200.

**Outcome:**
- ✅ Edge visualiser has fully independent sensitivity, smoothing, opacity, bars (smoothing via a dedicated second analyser). Both inner + edge visualisers can each pick **Theme (match player's Colors)** or **Custom (individual)** colours, independently, persisted per track.

---

### Entry S8 — Edge visualiser full opacity with playlist open (v184) *(2026-08-17)*

**User request:**
> "When Playlist panel is open, the opacity of the edge visualiser never reached 100%. When i close it the visualiser opacity jumps to 100%. Please make it so that when the playlist panel is open the opacity can show at 100% as it is when it is closed."

**Diagnosis (thinking):**
- Cause was a CSS rule added back in Entry S5: `body.playlist-open .viz-edge { opacity: .35; }` — it capped the edge at 35% whenever the playlist was open, overriding the opacity slider. That dim was a "don't fight the list" mitigation from before the glide fix; now that the edge glides LEFT with the player (Entry S6) it sits on the LHS, away from the panel, so the dim is unnecessary.

**Processing (files & commands):**
- **`styles.css` (v183→v184):** removed the `body.playlist-open .viz-edge { opacity: .35; }` rule. `.viz-edge` keeps `opacity: 1`, so the **opacity slider** now controls the edge at full strength whether the playlist is open or closed.
- `script.js` unchanged (v187). Server restarted; v184 served; dim rule confirmed gone; dev.html 200.

**Outcome:**
- ✅ Edge visualiser now shows at full (slider-set) opacity with the playlist open — no more dim/jump.

---

### Entry S10 — Edge visualiser moved BEHIND the player (diagnostic + Vizzy look) *(2026-08-17)*

**User report:** "Cinema mode is no longer working" + "cannot reposition and zoom cover art."
**Investigation (no static bug found):** verified ALL cinema code/CSS/wiring (engageCinema, cinemaOnPlay, mousemove reveal, attachCinema @ init 7525), cover-drag code (startDragMode, el.dragOverlay, btnCoverDrag @ 1751), edge functions (no duplicates), `.viz-edge` CSS (pointer-events:none, no event listeners attached → cannot intercept), CSS brace balance (331=331), `node --check` pass, init sequence clean. Conclusion: code is intact → likely a runtime error or stale browser cache. Awaiting console error / hard-refresh result.

**User suggestion + action:** move the edge visualiser BEHIND the player. Done — `.viz-edge` z-index 11 → **8** (behind the disc at z-index 10, above the playlist at 5).
- Why it helps: removes the edge layer from above the player's interactive surface entirely (rules out any edge-related interference with the drag-overlay / cinema mousemove), even though pointer-events:none should already prevent that.
- Visual: bars now radiate from BEHIND the rim (more authentic Vizzy look). Trade-off: inward-drawing content (mirror inward half, polar blob, bass ring) is hidden behind the opaque disc — acceptable since the outward look is the priority.

**Processing:** `styles.css` v184→v185 (z-index 11→8 + comment). script.js unchanged (v187). Server restarted; z-index:8 confirmed served.

**Outcome:**
- ⏳ Awaiting user test (hard-refresh + retest cinema/cover-drag). If still broken → not the edge layer → need browser console error.

---

### Entry S11 — Cinema for any media + cover-art reposition fix (v188) *(2026-08-17)*

**User report:** "Cinema view works [it was no video]. Please make it work when there is only cover art or visualiser present — ie. anytime a user wishes." + "Edge visualiser is off but I still cannot reposition or zoom artwork."

**Diagnosis (root causes found):**
1. **Cinema was video-only:** `cinemaOnPlay`/checkbox/mouseleave all gated on `videoMediaActive()`. So cover-art / visualiser-only tracks never engaged cinema.
2. **Cover-art tools wrote the wrong var:** "Cover art tools" (`art` mode) wrote `--art-*`, but the cover IMAGE reads `--art-*` only when `.video-active`; on non-video tracks it reads `--cover-*`, and in cinema the cover tool writes `--cinema-*` (also ignored by the image). So the artwork never moved on non-video tracks (the gap cinema-for-non-video exposed). The edge layer was NOT the cause (confirmed: edge off didn't help).

**Processing (files & commands):** `script.js` (v187→v188) via an asserted patch:
- New `cinemaContentActive()` = video OR cover-art OR (in-circle/edge) visualiser. Replaced `videoMediaActive()` with it in the 3 cinema gates (cinemaOnPlay, checkbox ON, mouseleave). Left the direct-video-framing gate (`framable`) as `videoMediaActive()` (that one IS video-specific). → cinema now engages for cover/visualiser tracks too.
- New `artVar(suffix)` = `.video-active ? '--art-' : '--cover-'`. Retargeted the cover-ART tools (drag onDown/onMove/onDbl/onWheel, btnArtReset, artZoom, applyArtAutoFill) to `artVar(...)`. → "Cover art tools" now controls the cover IMAGE on every track type (non-video, video-active, cinema). Internal backdrop management (`--art-*` in loadTrack/crossfade/persistArt) left untouched.
- Added persistence: art-mode drag-up now calls `persistCoverTransform()` when non-video + non-cinema, so the reposition survives track switches.
- `node --check` OK; server restarted; v188 + both helpers confirmed served; dev.html 200.

**Outcome:**
- ✅ Cinema engages for cover-art / visualiser tracks (anytime cinema is enabled), not just video.
- ✅ Cover artwork can be repositioned/zoomed via "Cover art Tools" on non-video tracks (and persists). Edge-behind (Entry S10) also removed any chance of the edge layer interfering.

---

### Entry S12 — Per-track look save + MP3/video audio clash fixes (v189) *(2026-08-17)*

**User report:**
> "Looks for individual tracks are not saving. I set a video look + visualiser for track 1, save; track 2 audio+visualiser, save; back to track 1 → the video look reverted." + "If I have an mp3 and a cover video is loaded rather than override the mp3, the video and mp3 play at the same time (clash)."

**Diagnosis (root causes found):**
1. **Look revert:** `saveCurrentAsTrackTheme` captured the video framing via `coverVar(...)`, which reads `--cinema-*` if you save while in cinema — so it wrote cinema values into the *non-cinema* `t.transform` slot; on reload the video look reverted.
2. **Audio clash:** nothing muted the cover video when an MP3 was the audio master (`setMaster('audio')` doesn't touch video mute; `loadTrack`'s video branch didn't mute either). Also, adding a cover video to an MP3 track force-switched to video-master (`setMaster('video')`) without pausing the MP3.

**Processing (files & commands):** `script.js` (v188→v189) via an asserted patch:
- `saveCurrentAsTrackTheme` now captures `t.transform` from `--cover-*` (non-cinema) AND `t.cinemaTransform` from `--cinema-*` — independently, so saving in cinema no longer corrupts the non-cinema framing. (Matches how `loadTrack` already restores: `--cover-*` from `t.transform`, `--cinema-*` from `t.cinemaTransform`.)
- `loadTrack` video branch: `el.coverVideo.muted = !!t.audio;` — a track with its own MP3 plays the MP3 as sound and the video as a SILENT visual.
- "Add cover video" handler: if the track already has an MP3, it now keeps the MP3 as master (`useVideoAudio` off, video muted, no `setMaster('video')`); only video-only tracks make the video the audio source.
- `node --check` OK; server restarted; v189 + all changes confirmed served; dev.html 200.

**Outcome:**
- ✅ Per-track video/cinema framing now saves + restores correctly (no revert after editing other tracks).
- ✅ MP3 + cover video no longer clash — MP3 is the audio, video is a muted visual. Note: for audio+video tracks the MP3 is now always the sound source (video muted); use a video-only track if you want the video's audio.

---

### Entry S13 — Workspace bloat cleanup (no player changes) *(2026-08-17)*

**User report:** "Workspace over budget — 140.4 MB across 150 files, past the 128 MB limit." Worried future work (zip) won't save.

**Root cause:** `uploads/` was 138 MB of 75 files, but the playlist (`data/theme.json`) referenced only 6. The other 69 were **orphaned duplicates** — every re-upload of the same file gets a NEW UUID-prefixed name (`server.js` `/api/upload`), so re-uploading the same cover/audio/video silently piled up copies (e.g. 3× the 22 MB video, 4× an MP3, ~60× the cover image).

**Action:** Garbage-collected `uploads/` — kept every file referenced by `theme.json`, deleted the 69 orphans (incl. stale `.md` duplicates superseded by `docs/`). Verified 0 referenced files missing; server still serves all referenced media + pages (200).

**Result:** workspace **141 MB → 45 MB** (freed ~96 MB). `uploads/` 138 MB → 42 MB (6 files). `docs/`, code, `vendor/`, `data/`, `test/` untouched.

**Prevention (not yet implemented — offered):** dedupe uploads by content hash in `server.js` `/api/upload` so re-uploading the same file reuses the existing copy instead of creating a new UUID file. Also: the deferred **video transcode-on-upload** (Entry S9) would shrink the 22 MB video. Note: one playlist track references `1ce44ecaf56a07a7-Anne_Murray_-_How_About_Goodbye.mp3` which was ALREADY missing before cleanup (pre-existing broken media, not caused by this).

---

### Entry S14 — Upload dedup by content hash IMPLEMENTED (server.js) *(2026-08-17)*

**User request:** "**Dedupe uploads by content hash**" (prevent the bloat from recurring).

**Implementation (`server.js`, zero-dependency — uses built-in `crypto`):**
- New persisted index `data/upload-index.json` mapping `sha1(content) → filename`.
- `buildUploadIndex()` runs once at startup: if the index is missing it hashes every existing upload (one-time), else it loads + prunes stale entries (file deleted → dropped).
- `storeUpload(data, origName)`: hashes the bytes; if an identical file already exists on disk it reuses it (no new write); otherwise saves a new UUID file and updates the index.
- Both upload paths now go through `storeUpload`: `/api/upload` (multipart) and `/api/upload-chunk` (chunked finalize).
- `node --check` OK; server restarted; **verified**: re-uploading identical bytes returns the SAME url both times and adds only 1 file (not 2).

**Result:** re-uploading the same cover/audio/video now reuses the existing copy — no more silent duplicate buildup. Multiple tracks can safely share one media file (playlist GC keeps any file still referenced). Workspace 45 MB, uploads 6, pages 200.

---

### Entry S15 — Performance: lazy-load three.js + performance guide (v190) *(2026-08-17)*

**User request:** The player will deploy on a 14-track album promo page and must load with no wait and run smoothly (video/artwork/visualisers in main player + playlist panel). Keep all future features fast.

**Diagnosis:** deployed `index.html` loaded ~1.7 MB of JS/CSS; the single biggest waste was **three.js (1.17 MB)** pulled in eagerly via the `<script type="module" src="viz3d.js">` tag even though the 3D coaster is only used if someone picks that mode.

**Action:**
- **Lazy-load the coaster/three.js:** removed the eager `viz3d.js` module tag from `index.html` + `dev.html`; `ensureViz3D()` now `import('./viz3d.js')` on demand (fires only when coaster mode is picked). Initial transfer drops from ~1.7 MB / ~400 KB-gzip to **~530 KB / ~100 KB-gzip** (excl. media). Verified: eager viz3d tag gone (0), viz3d still served 200 for the dynamic import, `node --check` OK.
- Wrote **`docs/PERFORMANCE-GUIDE.md`** — a performance budget (FCP < 1.2 s, TTI < 2.5 s, initial JS < 80 KB-gzip), 7 rules every new feature must pass (no eager deps, one heavy viz at a time, current+next media only, no per-frame allocations, measure before/after), a production deployment checklist (Brotli/gzip, long-cache + `?v=` busting, minify, preload track 1, WebP/AVIF, replace Font Awesome with inline SVG, short/video transcode, CDN, HTTP/2), and runtime notes for video/art/viz combos.
- script.js v189→v190 (cache-bust). Server restarted; all verified served.

**Outcome:**
- ✅ three.js no longer blocks initial load (1.2 MB saved for non-coaster visitors). A living performance guide now governs future features. Remaining wins are production-host tasks (compress/cache/minify/preload) documented in the guide.

---

### Entry S16 — Video transcode-on-upload IMPLEMENTED (v191) *(2026-08-17)*

**User request:** "build the video transcode-on-upload now" (Entry S9, elevated to a deployment priority: media size dominates visitor load time).

**Implementation (`script.js` v190→v191):**
- New `async function transcodeVideo(file, onProgress)`: offscreen `<video>` plays the source (muted); frames are drawn to a `<canvas>` sized ≤720p (even dims); `canvas.captureStream(30)` + the source's audio track (`video.captureStream()`/`mozCaptureStream`, optional) → combined `MediaStream` → `MediaRecorder` at **~1.5 Mbps** (vp9→vp8→webm fallback). Real-time (plays through once); progress callback drives the UI; `finally` revokes the object URL.
- `fileVideo` handler now: instant **raw preview** (as before) → background transcode with a `setSyncStatus` progress line ("Optimizing video… X%") → if the WebM is smaller, wrap in `new File([blob],'optimized.webm')`, swap the preview to it, and **upload the WebM**; on any failure (or unsupported browser) it **falls back to uploading the raw file**. Server stores it as `.webm` (MIME map + dedup apply).
- `node --check` OK; server restarted; both changes confirmed served; dev.html 200.

**Test status:** static verification done (function defined, handler wired, fallback present, served). **Live browser test pending the user** (sandbox can't run MediaRecorder): in the editor pick a cover video → expect "Optimizing video… X%" → a smaller `*.webm` saved to uploads/ and used. ⚠️ Output is WebM (not MP4); ⚠️ transcode is ~real-time (a 1-min clip ≈ 1 min) — keep cover clips short.

**Outcome:**
- ✅ Cover videos added from now on are auto-shrunk to a few MB → visitors download a few MB instead of tens of MB (directly serves the "no load time" goal). Pre-existing big videos (e.g. the 22 MB Sunshine Roses) aren't auto-retrofitted — re-add them to transcode.

---

### Entry S17 — Fresh-default release zip + auto-refresh on version bumps *(2026-08-17)*

**User request:** Provide a download zip with NO media (boots into a fresh default player every time), and refresh it to the latest version whenever the player version updates.

**Implementation:**
- `make-release-zip.sh` (repo root): allow-lists the runnable code + assets (server.js, script.js, styles.css, viz3d.js, *.html, package.json, scallop.png, vendor/, test/, docs/), creates an EMPTY `uploads/`, resets `data/theme.json` to `{"updatedAt":0}` (→ player boots into the built-in demo playlist: track 1 uses `test/` seed media, tracks 2–4 use external URLs — no uploads/ needed), writes an empty `data/upload-index.json`, adds a `README.txt` (version + run instructions), and zips as **`round-music-player-latest.zip`**. Scratch `.py` files and any media are excluded by the allow-list.
- Result: **1.1 MB** (was 42 MB with media). Verified fresh: `theme.json={"updatedAt":0}`, `uploads/` empty, index `{}`.
- **Workflow commitment:** after EVERY player version bump (any `?v=` change), run `./make-release-zip.sh` to refresh `round-music-player-latest.zip` so the download always matches the latest code. (Added to the IN-PROGRESS workflow + operational knowledge.)
- Old media zip (`round-music-player-v191.zip`) removed. Workspace 46 MB.

**Outcome:**
- ✅ A lean, always-fresh download zip is in the workspace; unzip + `node server.js` → clean default player, no media. Refreshed on every version bump going forward.

---

### Entry S18 — Scallop embedded as data URI + versioned zip naming (v192) *(2026-08-17)*

**User reports:** (1) "Not seeing the scallop image in the wave panel in my browser." (2) "Put the version number on the latest zip — downloads are confusing."

**Diagnosis / fixes:**
1. **Scallop not showing:** the scallop PNG (a valid alpha mask, served 200) wasn't rendering in the user's local browser — the external `url("scallop.png")` in `mask-image` was failing to load (path/file:// quirk). **Fix: embedded the scallop as a base64 data URI** inside the `--scallop-png` CSS var (`styles.css` v185→v186) — no separate file to fetch, so the scalloped wave-panel edge renders regardless of how the page is opened. Verified in served CSS + the zip.
2. **Versioned zip:** `make-release-zip.sh` now names the release **`round-music-player-v<scriptVer>.zip`** (was `…-latest.zip`) and removes older release zips so only the latest stays in the workspace. `script.js`'s `?v=` is now the **canonical release version**, bumped on every change → each release gets a distinct, ascending zip name (so downloads never confusingly overwrite). Bumped `script.js` 191→192 to capture the scallop fix as release **v192**.
- `node --check` OK; server restarted; verified served v192 + scallop data URI; zip = `round-music-player-v192.zip` (1.1 MB). Updated the IN-PROGRESS standing rules accordingly.

**Outcome:**
- ✅ Scallop renders reliably (data URI, no external-file dependency). Release downloads are now version-stamped (`round-music-player-v192.zip`, then v193, …) — easy to tell apart.

---

### Entry S19 — VIZ-21 same-origin audio proxy (v193) *(2026-08-17)*

**User request:** "Let's knock out viz-21 first" (before VIZ-28 Milkdrop) — so cross-origin media feeds the analyser.

**Diagnosis:** A cross-origin `<audio>`/`<video>` without CORS headers taints the media → `createMediaElementSource` silences the analyser → dead visualisers. Fix: route cross-origin media through a same-origin proxy.

**Implementation:**
- **Server (`server.js`):** new Range-capable `/proxy?url=<encoded>` endpoint (`handleProxy`). Validates http(s), forwards the client's `Range` header (seeking) + `User-Agent`/`Referer`, streams the upstream response back with `Content-Type`/`Content-Range`/`Accept-Ranges`/`Content-Length` preserved, + `Access-Control-Allow-Origin: *`. Added `https` require.
- **Client (`script.js` v192→v193):** new `proxiedMediaUrl(u)` helper — relative/blob/data/same-origin URLs pass through unchanged; cross-origin → `/proxy?url=encoded`. Applied at all 6 media-src chokepoints: `playSrc` (master audio), `abPreload` (A/B next-track), the `new Audio()` preload, and both cover-video sites. Same-origin uploads/blobs are never proxied.
- `node --check` both files; server restarted; **verified**: proxy full GET → 200 (unsplash, 153 KB); **Range → 206 with Content-Range + Accept-Ranges** (seeking works); client helper present at 6 sites; zip rebuilt `round-music-player-v193.zip`.

**Outcome:**
- ✅ Cross-origin media now feeds the analyser → visualisers animate on any source. Same-origin album media is unaffected (bypasses the proxy). VIZ-21 ✅ done. Ready to proceed to VIZ-28 (Milkdrop).

---

### Entry S20 — VIZ-28 Milkdrop (Butterchurn) IMPLEMENTED (v194) *(2026-08-20)*

**User request:** "Start viz-28" — the Milkdrop/Butterchurn opt-in visualiser mode.

**Implementation (`script.js` v193→v194, `vendor/butterchurn/` 384 KB):**
- Vendored `butterchurn.min.js` (188 KB) + `butterchurnPresetsMinimal.min.js` (187 KB, ~170 presets) + `isSupported.min.js` (1.4 KB) from unpkg into `vendor/butterchurn/`.
- New Milkdrop module: `milkdropSupported()` (WebGL2 probe), `ensureButterchurn()` (lazy script-inject UMD libs), `ensureMilkdropCanvas()` (dynamically creates a `.viz-canvas.milkdrop-canvas` in the player — reuses existing `.viz-canvas` CSS), `startMilkdrop()` (async: WebGL2 check → ensure graph → create visualizer → connectAudio(analyser) → load preset → rAF), `milkdropTick()` (render + auto-resize + preset cycle every 20s with 1.5s blend), `stopMilkdrop()` (cancel rAF, hide canvas).
- Wired into `applyViz()` (mode==='milkdrop' → hide 2D/3D canvases, startMilkdrop; otherwise stopMilkdrop). `vizTick` guard skips milkdrop.
- Added "Milkdrop (WebGL)" option to the dev.html mode dropdown (after Rollercoaster).
- `node --check` OK; vendor served 200; server restarted; zip `round-music-player-v194.zip` (1.2 MB — vendor/butterchurn included).

**Test status:** static verification done. **Live browser test pending the user** (needs WebGL2 + audio playback): dev.html → Visualisers → Milkdrop → play → expect "Loading Milkdrop…" → "Milkdrop ready ✓" → psychedelic visuals cycling every ~20s.

---

### Entry S9 — Video upload file-size reduction: research + deferred decision (no code) *(2026-08-17)*

**User request:**
> "I believe the player can resize cover art so that if the file uploaded is too large it reduces it... Is there a way to resize the file size of video uploads in a similar way?"

**Findings (research, no changes made):**
- **Cover art IS shrunk client-side** by `downscaleImageDataURI()` (`script.js`): image → `<canvas>` at ≤600 px → JPEG quality ladder (0.82→0.32) until ≤150 KB. Works because re-encoding one image is instant in-browser. (Server stores uploads verbatim; the shrink is browser-side, mainly for embedded ID3 art + localStorage quota.)
- **Video uploads are stored verbatim** (`/api/upload`, `/api/upload-chunk` write raw bytes). No compression today.
- **Video ≠ image:** shrinking a video = **transcoding** (decode every frame + re-encode + re-mux) → inherently lossy, slower (≈real-time), browser output is **WebM** (not MP4). But tuned to display size it shows no visible loss.
- **ffmpeg is NOT installed** in the sandbox; server.js is zero-dependency.
- **Recommended approach:** browser **`MediaRecorder`** (play upload via `<video>` → smaller `<canvas>` → `captureStream()` → record WebM). No deps/downloads/server changes. Alternatives: ffmpeg.wasm (~25 MB load, can keep MP4), or server-side ffmpeg (not available).

**User decision:** "Just explain for now" (do **not** build yet). Preferred params when they do proceed: **automatic on upload**, target **720 p / ~1.5 Mbps**, WebM output.

**Outcome:**
- ⏸️ Deferred. Build when the user gives the go-ahead, using MediaRecorder→WebM, auto-on-upload, 720 p/~1.5 Mbps, with a progress indicator. Caveats to restate: output .webm, ≈real-time processing, small tunable quality reduction.

---

### Entry S21 — Playlist visualiser FULL parity: Coaster + Edge on the playlist disc  *(2026-08-20)*

**User request:**
> "the Coaster-on-playlist and edge-modes-on-playlist are the remaining items from the parity plan, ready to build when you say." → "Build the rest of the playlist plan"

**Diagnosis (thinking):**
- The 3D coaster (`viz3d.js`) was a SINGLETON bound to `#player` — `_boot()` hardcoded `document.getElementById('player')` and wrote to a module-global `api`/`window.RoundViz3D`. Putting a coaster on the playlist needed a true multi-instance design without breaking the dozens of existing `window.RoundViz3D.setActive/setColors/setFog/setIntensity/resize` call sites.
- The 8 edge draw functions (`drawEdgeBars` … `drawEdgeBlocks`) read module-level `viz.edge*` settings AND shared beat state (`vizEdgeRipples`, `vizEdgeParticles`, `_edgeBass`…). Reusing them for the playlist without disturbing the main edge required swapping settings + state in/out around the draw — fully isolated per-edge.
- PL coaster's internal three.js `setAnimationLoop` would burn GPU while the playlist disc is closed/invisible → must pause/resume with the disc.

**Processing (files & commands):**
- **viz3d.js → v140** (multi-instance refactor, the high-risk item): `_boot(host, opts)` replaces `_boot()`. opts: `heightFraction` (0.5 main media-window / 1.0 full playlist disc), `scaleMode` ('viz' cinema-aware `--viz-*` / 'pl' `--pl-viz-scale`), `canvasClass`, `fogClass`, `colorHost` (theme vars always read from `#player`). Returns an instance object `{ ready, active, setActive, resize, setColors, setFog, setIntensity, getIntensity, _dbg }`. New `createInstance(hostOrId, opts)` factory. The MAIN instance still boots on `#player` and is assigned to `window.RoundViz3D` (backward compatible) with `.create` added; a stub covers the no-`#player` case. Coaster math is byte-for-byte unchanged (only `player`->`host` + parameterisation).
- **styles.css → v198**: `.playlist-circle > .pl-viz-canvas-3d` (full-circle, framed by `--pl-viz-*`, `mix-blend-mode: screen`), `.pl-viz-fog-layer`, `.pl-edge` (sibling in `.player-pair`, glides RIGHT `translateX(--open * --pair-gap)`, z-index 4 behind the playlist disc, `opacity: var(--open)`), `#vizPlEdgeSettings`/`#vizPlEdgeCustomRow` visibility rules.
- **script.js → v207**: new `viz.plEdge*` settings (+ defaults + VIZ_DEFAULTS); module state (`plCoasterInst`, `plEdgeRAF`, `plEdgeAnalyser`, PL ripple/particle/bass state); 3rd analyser in `ensureVizGraph`; `startPlCoaster/stopPlCoaster/plCoasterTick`, `ensurePlEdgeCanvas/sizePlEdgeCanvas/plEdgeTick/applyPlEdgeViz`; `applyPlViz` handles `plMode==='coaster'`; `togglePlaylist` pauses/resumes the PL coaster with the disc; resize handler resizes PL coaster + PL edge; `vizSyncUI` + `attachVisualizerUI` wire the new controls; new fields persisted in `saveCurrentAsTrackViz` + `vizTrackOn`.
- **dev.html**: `vizPlMode` gains `<option value="coaster">`; new "Playlist edge / rim" section (`vizPlEdgeMode` + `vizPlEdgeSettings`).
- **Verification:** `node --check` on script.js + viz3d.js OK. Built a **functional three.js mock** and ran viz3d.js in Node (jsdom DOM) -> **27/27** multi-instance checks pass (main + PL instances independent, correct host targeting, backward-compat API, coaster math runs for real — seam closes). Built a **dev.html jsdom smoke test** -> **8/8** DOM integration checks pass, 0 runtime errors (PL edge canvas created/hidden, settings visibility, coaster option, no-throw on coaster pick). Restarted server (port 3000), confirmed v207/v198 served with no-store. Built `round-music-player-v207.zip` (1.2 MB, fresh-default).
- Updated `docs/IN-PROGRESS.md`, `docs/PHASE2-PROGRESS.md`, `docs/PHASE2-WORKLOG.md`, `docs/pl-viz-parity-plan.md`.

**Outcome:**
- ✅ Playlist panel now has FULL visualiser parity with the main player: 2D modes + **Coaster (3D)** + Milkdrop + **Edge/Rim (8 modes)**, all independent, all per-track. The playlist visualiser parity plan is COMPLETE (only Step 6 "Centre-default fill/reset buttons" remains as a minor polish item, not part of this request).
- ⚠️ Not browser-verified in-sandbox (no headless Chromium + WebGL available); validated via functional three.js mock + jsdom integration tests. User should hard-refresh and confirm the coaster renders in the playlist disc + edge rims pulse around it.
<!-- ═══════════════════════════════════════════════════════════════════ -->

### Session N — 2026-08-22 — **CRITICAL FIX: player was completely dead (dead-code bug)**

**Symptom:** The player's JavaScript appeared not to execute at all — no version badge, no working buttons/tabs, no red error bar from the on-screen error catcher. Happened both in Arena preview AND in the downloaded zip run locally. `node --check` passed; basic jsdom parse showed 0 errors.

**Root cause (found via jsdom execution trace):** The `PLAYER_VERSION` IIFE at the top of `script.js` (line ~299) was **missing its closing `})();`**. The IIFE body contained `return 'v11';` (line ~307), which exited the function immediately. Because the IIFE was never closed, **every line from ~309 to the end of the file was unreachable dead code inside that function body** (the function's body extended all the way to a trailing `})();` at EOF). Only the code *before* line 299 ever ran — which is why `[DBG] IIFE START` (line 16) logged but nothing after it did. The two trailing `})();` at EOF were accounting for two openings (main IIFE + the unclosed PLAYER_VERSION IIFE), so `node --check` reported syntax OK despite the entire app being dead code.

**How it was diagnosed:**
- Added 3 `console.log` debug markers (IIFE START / before badge / INIT COMPLETE). User's console showed only IIFE START + "1310 log entries not shown".
- Built a jsdom execution harness (`test-init.js`) that loads `dev.html` DOM + runs `script.js` with browser-API stubs. It reproduced the exact symptom: IIFE START logged, nothing else, no error, no hang (eval returned normally) → proved an early-exit, not a loop or throw.
- Searched for a top-level `return` / unmatched structure → found the unclosed PLAYER_VERSION IIFE.

**Fix (script.js → v303):**
1. Added `})();` immediately after `return 'v11';` (line 308) — closes the PLAYER_VERSION IIFE properly so the rest of the file is reachable.
2. Removed the now-redundant extra `})();` at EOF (was compensating for the unclosed IIFE).
3. Removed the 3 temporary `[DBG]` debug markers.
4. Bumped version `v302 → v303` in `dev.html` + `index.html`.

**Verification:**
- `node --check` OK.
- jsdom harness now executes deep into `init()` (reaches `initFromData`, `initArc`, `renderPlaylist`…) — remaining jsdom errors are pure jsdom limitations (no `getPointAtLength`, `createSVGPoint`, `HTMLMediaElement.load`), NOT player bugs.
- Server restarted (port 3000); served `script.js` MD5 matches disk; `dev.html` references `?v=303`.
- Rebuilt `round-music-player-v303.zip` (1.4 MB, fresh-default) — verified zip's `script.js` has the fix.

**Lesson:** A missing IIFE close makes `node --check` pass (brackets still balance via a distant trailing close) while silently turning the entire app into dead code. The jsdom *execution* test (not just parse) was what caught it. **Always run the script, don't just `node --check`.**

---

## 9. ✏️ Update protocol & entry template

**When to update this document:** after every completed task (the assistant does this automatically; the user can also say *"update the context doc"*).

**What to update:**
1. Append a new entry to **§8 Session Log** (newest at the bottom, above the comment marker).
2. If versions changed → update **§1 (Current versions)**.
3. If a feature moved between done/parked → update **§6 / §7**.
4. Update the **"Last updated"** date at the very top.

**Entry template (copy & fill):**

```markdown
### Entry S<n> — <short title>  *(<date>)*

**User request:**
> "<exact user quote or paraphrase>"

**Diagnosis (thinking):**
- <root cause / reasoning / key facts discovered>

**Processing (files & commands):**
- Edited **<file>**: <what changed and why>.
- <commands run: node --check, server restart, curl verification, etc.>
- Updated <other docs>.

**Outcome:**
- ✅/⚠️/❌ <result. If unresolved, move item to §7 and say so.>
```

---

## 10. 📚 Related docs (for deeper detail)
- `docs/PHASE2-WORKLOG.md` — detailed running transcript (all entries to date).
- `docs/PHASE2-PROGRESS.md` — milestone checkpoints.
- `test_independent_transform.js` — jsdom regression test for art/video transform independence.

---

*End of document.*
