# Phase 2 — Implementation Progress Log 🔧

> **RESUME PROTOCOL (read first if restarting after a crash/compaction):**
> 1. Read this file top-to-bottom — it is the single source of truth for Phase 2 state.
> 2. Jump to **§ RESUME HERE** — it states the exact next action.
> 3. Everything in **§ DONE** is verified-good on disk; do not redo it.
> 4. Code lives at `/home/user/` (script.js, dev.html, styles.css, vendor/, server.js).
> 5. After every batch I update **§ RESUME HERE** + tick items in **§ DONE**.
> 6. The player server: `node server.js` (port 3000). Restart if down.

**Goal:** DJ Phase 2 — beat/tempo detection (TR-07), beat-synced transitions (TR-08), tempo modes Instant/Locked/Ramp (TR-09), plus signature polish (BPM chip + beat-pulse artwork). "Seamless, beautiful, unique."

---

## § DECISIONS (locked)

- **Beat engine = bespoke, zero-dependency** `vendor/bpm-detect/bpm-detect.js` (NOT realtime-bpm-analyzer). Pipeline: mono+decimate→RMS energy→half-wave flux ODF→autocorrelation 70–180 BPM→parabolic peak→confidence + beat-0 phase offset. Exposes `window.BpmDetect.analyze(audioBuffer)` → `{bpm, confidence, offset}`.
- **Tempo-match = native** `preservesPitch` + `playbackRate` (no SoundTouchJS). Big-gap guard: |ΔBPM|>12% → Locked/Ramp auto-fallback to Instant.
- **Beat-sync scope = outgoing bar-snap** (blend START lands on outgoing's bar line). Full incoming phase-lock deferred to Phase 3.
- **Remote tracks (Pixabay/Bandcamp) = manual BPM fallback** (CORS blocks decodeAudioData). Auto-detect works on uploads/local only (for now; VIZ-21 proxy would fix).
- **Order:** Step1 BPM-real → Step2 Locked → Step3 bar-snap → Step4 Ramp. Plus signature polish (BPM chip + beat pulse).
- **`read_file` collapses some line breaks** → use `sed -n 'A,Bp'` / `cat` to get EXACT text before patching. The Python patch script asserts `count==1` and aborts atomically (no partial writes).

---

## § DATA MODEL ADDITIONS

Per track: `t.bpm` (num), `t.bpmConfidence` (0–1), `t.bpmOffset` (s, beat-0 phase), `t.bpmSource` ('auto'|'manual').
Per transition (track.transition + gs.transitionDefault): `snap` (bool, default false), `tempoMode` ('instant'|'locked'|'ramp', default 'instant').
Global: `gs.beatPulse` (bool, default true — subtle), `gs.beatPulseStrength` (0–100, default 35).
Default transition becomes: `{ fade:0, curve:'equal-power', beats:0, tempoMode:'instant', snap:false }`.

---

## § NEW FUNCTIONS TO ADD (append before the `init` IIFE)

- `decodeForBpm(arr)` → AudioBuffer (lazy shared `bpmCtx` AudioContext; promise; null on fail)
- `analyzeBpm(fileOrUrl, entry, {isUrl})` → decode → `BpmDetect.analyze` → set entry.bpm* + render + savePlaylist + status
- `setTrackBpm(entry, bpm, {source})` → set + clamp fold + re-render + save
- `redetectBpm(entry)` → fetch(entry.audio) → decode → analyze (manual button)
- `updateBpmChip()` → show ♩BPM in `.info` (create `#bpmChip` element)
- beat-pulse rAF loop `beatPulseLoop()` → sets `--beat-pulse` from current track BPM/offset (env decays each beat); toggled by gs.beatPulse + track.bpm
- `applyTempoModeSetup()` → set preservesPitch on AB.a/AB.b + el.audio/coverVideo (once)

---

## § DONE (verified on disk)

- [x] **Analyzer written + validated.** `vendor/bpm-detect/bpm-detect.js`. Node test `test-bpm.js` → **5/5** (120/90/140/128-noisy/124-60s, all ±0.2 BPM). ✓
- [x] Confirmed exact current text of regions: `transitionFor`(4824), `transitionSeconds`(4836, **no edit needed — already bpm-aware**), `startTransition`(5089), `abCompleteHandover`(4993), `armCrossfade`(5144).
- [x] Located all edit targets (line numbers in § EDITS).

---

## § EDITS (status)

**script.js:**
- [ ] E1 `gs.transitionDefault` add tempoMode+snap (line 4795)
- [ ] E2 `transitionFor` return +tempoMode+snap (4824–4832)
- [ ] E3 `applyAudioFileToTrack` call analyzeBpm after readMp3Meta (near 4615)
- [ ] E4 `renderPlaylistManager` row + BPM cell + wiring (4421+)
- [ ] E5 `openTransitionEditor` + Snap row + Tempo-mode row + save/clear/all carry them (4343+)
- [ ] E6 `startTransition` tempo-mode playbackRate ramp + preservesPitch + gap guard (5089–5143)
- [ ] E7 `abCompleteHandover` reset incoming playbackRate (applySpeed) after Locked/Ramp (4993+)
- [ ] E8 `armCrossfade` bar-snap blend start (5144–5187)
- [ ] E9 `getThemeData` tracks map add bpm/bpmConfidence/bpmOffset/bpmSource (line ~397)
- [ ] E10 `loadTrack` call updateBpmChip + start beat pulse (2809+)
- [ ] E11 `gsSyncUI` + `attachGlobalUI` bind global Snap + Tempo-mode + beat-pulse (5334+, 5372+, trans block ~5384)
- [ ] E12 append new functions (analyzeBpm, decodeForBpm, setTrackBpm, redetectBpm, updateBpmChip, beatPulseLoop, applyTempoModeSetup) + init wiring
- [ ] E13 `gs` object: add beatPulse/beatPulseStrength (4795 area)

**dev.html:**
- [ ] D1 `<script src="vendor/bpm-detect/bpm-detect.js?v=111">` (editor only)
- [ ] D2 Global tab gs-trans-block: + Snap checkbox + Tempo-mode select
- [ ] D3 Global tab: + Beat-pulse toggle + strength slider

**styles.css:**
- [ ] C1 `.album` transform → include `* var(--beat-pulse,1)`; default `--beat-pulse:1`
- [ ] C2 `.pm-row` BPM cell/pill styles, confidence dot, ½/×2/↻ buttons
- [ ] C3 `#bpmChip` styling in `.info`
- [ ] C4 tempo-mode badge (optional, if added)

**Finalize:**
- [ ] F1 bump ?v=111 → ?v=112 in index.html + dev.html
- [ ] F2 node --check script.js; serve smoke test; update this log § DONE

---

## § CONFIRMED EXACT SNIPPETS (so I don't re-extract after a crash)

`transitionFor` returns:
```
      fade: own && isFinite(own.fade) ? own.fade : (def.fade || 0),
      curve: (own && own.curve) || def.curve || 'equal-power',
      beats: own && isFinite(own.beats) ? own.beats : (def.beats || 0)
    };
```
`transitionSeconds` (NO CHANGE — already does `if (tr.beats > 0 && t && t.bpm > 0) return tr.beats * 4 * 60 / t.bpm;`).

`startTransition` crossfade rAF `step`:
```
      const k = Math.min(1, (performance.now() - t0) / (fade * 1000));
      const g = crossfadeGains(k, tr.curve);
      try { outEl.volume = vol * g.a; } catch {}
      try { inEl.volume = vol * g.b; } catch {}
      if (k < 1) AB.blendRaf = requestAnimationFrame(step);
      else { AB.blendRaf = null; abCompleteHandover(nextIdx, vol); }
```
→ add tempo-mode playbackRate ramp here (inEl/outEl). Need outBPM=t.bpm, inBPM=next.bpm.

`armCrossfade` ARM phase condition: `if (remain <= fade + 0.35 && AB._preloadNext !== null){ ... if (ready){ AB._preloadNext=null; AB.active=true; startTransition(n); return; } ...}`
→ with snap: replace the arm trigger with `currentTime >= plannedBlendStart` where plannedBlendStart = next bar boundary (outBPM/offset) that fits before end.

`gs.transitionDefault` line 4795: `    transitionDefault: { fade: 0, curve: 'equal-power', beats: 0 }   // 0 = gapless`

---

## § STILL-NEEDED EXACT TEXT (extract before patching these)

- `openTransitionEditor` full body (4343–~4410) — for E5
- `renderPlaylistManager` row template + event wiring (4421–~4520) — for E4
- `gsSyncUI` transition lines (5344–5349) — for E11
- `attachGlobalUI` transFade/transCurve block (5384–5393) — for E11
- `getThemeData` tracks map around line 390–400 — for E9
- `applyAudioFileToTrack` around 4615 (the readMp3Meta.then block + where audio set) — for E3
- `loadTrack` body (2809+) where cover/title set — for E10 (bpm chip + beat pulse start)
- `init` IIFE end (where to append new funcs / wire beat pulse) — for E12

---

## § RESUME HERE — PHASE 2 CORE COMPLETE ✅ (2026-08-12)

**All EDITS applied & verified:** script.js (17 patches via `patch-phase2.py` + 1 bugfix
for the `'detecting'` quote + 2 server-rebuild-loop bpm patches), dev.html (3 via
`patch-phase2-html.py`), styles.css (2 via `patch-phase2-css.py`). Version bumped
?→v112. Server smoke-tested: all routes 200, bpm-detect.js serves as text/javascript,
dev.html references it / index.html does NOT. `node --check` passes; analyzer 5/5.

**What's live:** TR-07 (auto-BPM on upload + ½/×2/↻ + editable BPM column), TR-08
(real bars→seconds from BPM + outgoing bar-snap), TR-09 (Instant/Locked/Ramp tempo
modes via native preservesPitch, >12% gap auto-fallback), + signature polish
(♩BPM chip on the player + beat-pulse artwork locked to the detected beat).
All persisted (per-track bpm fields + transition tempoMode/snap ship to server;
deployed player rebuilds them). Persisted patch scripts on disk = re-runnable.

**Next (when resuming):** BROWSER TEST (I can't run one) — in dev.html drop a
beat-heavy track → watch BPM detect → set ⧉ transition bars + Locked + Snap →
verify blend + beat-pulse + chip. Then optional polish: beat-sync armed marker
on the seek arc, Ramp fine-tuning, VIZ-21 audio proxy so remote tracks auto-detect.

## Checkpoint — v139 (2026-08-14): independent artwork/video reposition FIXED
- Bug: cover <img> + video moved together despite separate --art-*/--cover-* vars.
- Cause: `.video-active` class (which routes the cover <img> to --art-*) was missing
  on upload + handover paths -> cover fell back to the shared --cover-* base rule.
- Fix: `syncVideoActive()` + MutationObserver on el.coverVideo -> .video-active always
  tracks whether a video is actually showing. One mechanism fixes all paths.
- Verified: jsdom test against real styles.css shows cover->var(--art-dx),
  video->var(--cover-dx) when video-active (independent). node --check OK. v139 served.
- Files touched: script.js (syncVideoActive + observer), styles.css (--art-* decls),
  dev.html/index.html (?v=139). New regression test: test_independent_transform.js.

## Checkpoint — viz3d v139 (2026-08-17): 3D visualiser zoom pixelation FIXED
- Bug: zooming in on the rollercoaster 3D visualiser pixelated (lost visual integrity).
- Cause: WebGL drawing buffer was the canvas's base CSS size only; the --viz-scale
  CSS transform then stretched those fixed pixels on screen.
- Fix (viz3d.js): drawing buffer now = base size × zoom scale (cinema-aware via
  effectiveVizScale reading --viz-cinema-scale/--viz-scale); loop() re-layouts only
  when the zoom value changes; composer pixel ratio synced to the canvas so bloom
  stays full-res. Camera aspect uses base size so framing is unchanged.
- Verified: node --check OK; v139 served with no-store. script.js v184 untouched.

## Checkpoint — Entry S21 / v207 (2026-08-20): Playlist visualiser FULL parity (Coaster + Edge)
- Goal: give the playlist disc EXACTLY the same visualiser power as the main player. The two
  remaining items — 3D Coaster on the playlist (Step 3) + Edge/Rim modes on the playlist (Step 5) —
  are now IMPLEMENTED. The parity plan is complete.
- viz3d.js multi-instance refactor (the high-risk item): `_boot(host, opts)` + `createInstance()`
  factory. Main instance boots on #player and stays `window.RoundViz3D` (backward compatible, every
  existing setActive/setColors/setFog/setIntensity/resize call unchanged). PL instance created via
  `window.RoundViz3D.create('playlistCircle', {heightFraction:1, scaleMode:'pl', canvasClass, fogClass})`
  — fully separate scene/camera/renderer/composer. Coaster math byte-for-byte unchanged.
- PL edge: `.pl-edge` canvas (sibling in .player-pair, glides RIGHT, z-4 behind the disc,
  opacity:var(--open)). Reuses all 8 edge draw functions via a settings + beat-state swap that is
  fully isolated per-edge (own analyser `plEdgeAnalyser`, own ripple/particle/bass state).
- PL coaster pauses/resumes with the disc (togglePlaylist) so it doesn't burn GPU when closed.
- New per-track settings: plEdgeMode/Reach/Sensitivity/Smoothing/Opacity/Bars/Colors/CustomColors
  (persisted in saveCurrentAsTrackViz + vizTrackOn). Editor: vizPlMode gains Coaster; new
  "Playlist edge / rim" section.
- Verified: node --check OK; functional three.js mock + jsdom ran viz3d.js -> 27/27 multi-instance
  checks; dev.html jsdom smoke test -> 8/8 DOM integration checks, 0 runtime errors. Server
  restarted, v207/v198 served. round-music-player-v207.zip built (1.2 MB).
- Files touched: viz3d.js (v140), styles.css (v198), script.js (v207), dev.html, docs/*.

## Checkpoint — Entry S22 / v209 (2026-08-21): Milkdrop fixed under strict CSP (sandbox preview)
- Bug: Milkdrop rendered a black circle in the Arena live preview (worked in a normal browser).
- Root cause: the sandboxed preview iframe injects a CSP `script-src 'self' 'unsafe-inline' https:`
  (NOT from server.js or our HTML — from the platform proxy). butterchurn compiles every preset's
  per-frame/per-vertex math with `new Function("a", eqs_str + " return a;")` = eval, which CSP
  forbids -> EvalError at loadPreset -> black screen. (Previously masked by the earlier
  `.default` createVisualizer bug; fixing that exposed this deeper wall.)
- Fix (no unsafe-eval needed at runtime): PRECOMPILE the 29 minimal presets at build time.
  `tools/precompile-butterchurn.cjs` reads butterchurnPresetsMinimal in Node, turns each
  *_eqs_str into a REAL function literal, and emits `vendor/butterchurn/butterchurnPresetsPrecompiled.js`
  (106 KB). butterchurn's loadPreset guards all 8 new Function calls behind
  `if (typeof preset.init_eqs !== 'function')`; the precompiled file attaches real functions
  (init/frame/pixel + per enabled shape + per enabled wave), so the guard is false -> eval skipped.
  Milkdrop helpers (above/below/pow/mod/equal/bnot/...) are window.* globals, so the precompiled
  functions resolve them identically to butterchurn's new Function version.
- Wiring: ensureButterchurn now loads butterchurn -> minimal presets -> precompiled (sequential);
  cache key includes window.__butterchurnPrecompiled. Removed the temporary unsafeEvalAllowed blocker.
- Verified: node --check OK; vm-run of the generated file against real presets = 100% coverage
  (0 preset/shape/wave eqs missing); served HTTP 200 (108 KB); zip includes it.
- Files: +tools/precompile-butterchurn.cjs, +vendor/butterchurn/butterchurnPresetsPrecompiled.js,
  script.js v209 (ensureButterchurn + removed blocker). Regenerate precompile if preset set changes.
