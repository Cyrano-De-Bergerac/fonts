# 🎵 Round Music Player — Feature Implementation Checklist

> A scannable, document-style view of every feature from the research report (`music-player-features-research.md`), with current status. Suggested build order = **P1 → P2 → P3**.

**Status key:** ✅ Done (in the Round Player) · 🟡 Partial (exists, needs work) · ⬜ To do (not started)

---

## 📊 Progress dashboard

| Section | ✅ Done | 🟡 Partial | ⬜ To do | Total | Progress |
|---|---:|---:|---:|---:|---:|
| **A. Playback & audio engine** | 11 | 2 | 9 | 22 | 50% |
| **B. Formats & codecs** | 9 | 0 | 0 | 9 | 100% |
| **C. Visualisation suite (Web Audio AnalyserNode → canvas)** | 8 | 2 | 3 | 13 | 62% |
| **D. Lyrics panel** | 0 | 0 | 9 | 9 | 0% |
| **E. Playlists, queue & library** | 4 | 0 | 8 | 12 | 33% |
| **F. UI, design & theming** | 2 | 3 | 12 | 17 | 12% |
| **G. OS & platform integration** | 4 | 0 | 3 | 7 | 57% |
| **H. Embedding & sharing (deploy on any website)** | 1 | 3 | 9 | 13 | 8% |
| **I. Streaming & live** | 1 | 2 | 2 | 5 | 20% |
| **J. Audio processing & effects** | 0 | 0 | 13 | 13 | 0% |
| **K. Accessibility, mobile & i18n** | 0 | 2 | 3 | 5 | 0% |
| **L. Content & metadata** | 2 | 0 | 3 | 5 | 40% |
| **M. Bandcamp & indie-platform integration (the "Bandcamp radio" story)** | 0 | 0 | 12 | 12 | 0% |
| **DJ playlist engine** | 6 | 0 | 12 | 18 | 33% |
| **Global Settings tab (v65)** | 13 | 0 | 11 | 24 | 54% |
| **TOTAL** | **61** | **14** | **109** | **184** | **33%** |

---

## 📑 Contents

1. **A. Playback & audio engine**
2. **B. Formats & codecs**
3. **C. Visualisation suite (Web Audio AnalyserNode → canvas)**
4. **D. Lyrics panel**
5. **E. Playlists, queue & library**
6. **F. UI, design & theming**
7. **G. OS & platform integration**
8. **H. Embedding & sharing (deploy on any website)**
9. **I. Streaming & live**
10. **J. Audio processing & effects**
11. **K. Accessibility, mobile & i18n**
12. **L. Content & metadata**
13. **M. Bandcamp & indie-platform integration (the "Bandcamp radio" story)**
14. **DJ playlist engine** — gapless, crossfades & pro workflows (planned)
15. **Global Settings tab (v65)** — whole-player settings in one place
16. **Suggested first wave** — quick wins + wow-factor starter pack

---

## A. Playback & audio engine

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **PL-01** | Play / pause / stop · next / previous · click-to-seek | ✅ Done | (arc seek + knob + transport) |
| **PL-02** | Volume slider + mute | ✅ Done | — |
| **PL-03** | Per-track volume | ⬜ To do | (P3) |
| **PL-04** | Loop modes: off / repeat-all / repeat-one | ✅ Done | v65 Global tab |
| **PL-05** | Shuffle | ✅ Done | v65 Global tab (random next track) |
| **PL-06** | Smart shuffle (avoid same-artist repeats) | ⬜ To do | (P2) |
| **PL-07** | Autoplay on load | ✅ Done | v65 Global tab toggle (browser-safe catch) |
| **PL-08** | Playback speed 0.5×–2× | ✅ Done | v65 Global tab (audio + video) |
| **PL-09** | Preload strategy + buffering indicator | ✅ Done | (preload=auto) |
| **PL-10** | Resume playback position per track | ✅ Done | v65 Global tab toggle |
| **PL-11** | True audio crossfade with per-transition durations + curves | ⬜ To do | planned (TR-01…TR-06 in the DJ section); v65 has a simple fade-between-tracks |
| **PL-12** | Gapless playback (preload next + instant switch) | 🟡 Partial | v65 basic gapless (preload); TRUE sample-accurate gapless via dual-element A/B engine planned (TR-01…TR-03) |
| **PL-13** | Fade-in / fade-out on track change | ✅ Done | v65 Global tab (fade between tracks) |
| **PL-14** | ReplayGain / volume normalisation | ⬜ To do | (P3) |
| **PL-15** | Keyboard shortcuts (space, ←/→ seek, ↑/↓ volume, N/P, M, F fullscreen) | 🟡 Partial | only Esc handled; build full map (P1) |
| **PL-16** | Repeat-A/B segment | ⬜ To do | (P3) |
| **PL-17** | BPM detection (client-side) | ⬜ To do | planned (TR-07, vendored realtime-bpm-analyzer) |
| **PL-18** | Sleep timer (15/30/45/60 min → pause) | ✅ Done | v65 Global tab |
| **PL-19** | Volume boost beyond 100% (100–200%, VLC-style) | ✅ Done | v65 Global tab (Web Audio master gain) |
| **PL-20** | True-random shuffle | ⬜ To do | re-seed every session (VLC's same-seed bug is the anti-pattern) — (P1, do with PL-05) |
| **PL-21** | Speed control with VISIBLE timestretch toggle (VLC users complained it was buried) | ⬜ To do | (P2) |
| **PL-22** | Timestamp bookmarks per track (VLC wish) | ⬜ To do | (P3) |

## B. Formats & codecs

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **FM-01** | MP3 | ✅ Done | — |
| **FM-02** | WAV (PCM) | ✅ Done | accept in file input + correct MIME on server — v64: uploads allowed, served as `audio/wav`, Range 206, plays (tested) |
| **FM-03** | FLAC | ✅ Done | same as WAV; browsers play it natively (~96% support) — v64: uploads allowed, served as `audio/flac`, Range 206 |
| **FM-04** | AAC / M4A / MP4-audio | ✅ Done | v64: `.m4a`/`.aac` uploads allowed, served as `audio/mp4` / `audio/aac`, Range 206 |
| **FM-05** | OGG Vorbis + Opus | ✅ Done | v64: `.ogg`/`.oga`/`.opus` uploads allowed, served as `audio/ogg` (+ `codecs=opus`), Range 206 |
| **FM-06** | `canPlayType()` check + friendly "unsupported on your browser" message | ✅ Done | v64: report in editor media summary (per-format ✓/✗), friendly warnings on file pick / playlist add / URL add / deployed error badge (e.g. AIFF) |
| **FM-07** | Video cover media (MP4/WebM) | ✅ Done | — |
| **FM-08** | Server: correct MIME map for .wav/.flac/.m4a/.ogg/.opus/.aiff + Range support | ✅ Done | v64: explicit `AUDIO_MIME` map in serve.py; Range 206 verified per format |
| **FM-09** | AIFF (VLC plays it; browser support patchy — gate via canPlayType + friendly notice) | ✅ Done | v64: uploads allowed, served as `audio/aiff`, but gated via canPlayType with a friendly "AIFF is not supported by web browsers — convert to FLAC/WAV/MP3" message |

## C. Visualisation suite (Web Audio AnalyserNode → canvas)

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **VIZ-01** | Frequency bars (classic spectrum) | ✅ Done | `bars` mode |
| **VIZ-02** | Circular / radial spectrum around the ring | ✅ Done | `radial` (sunburst) mode |
| **VIZ-03** | Waveform / oscilloscope | ✅ Done | `waveform` mode (mirrored trace) |
| **VIZ-04** | Smooth spectrum ribbon (gradient band) | ⬜ To do | (P2) — no ribbon mode yet (plasma is a colour field, not a ribbon) |
| **VIZ-05** | Particle field (bass-reactive) | ✅ Done | `starfield` mode — 220 bass-reactive particles + central bass glow |
| **VIZ-06** | Radial burst / spiral | 🟡 Partial | radial sunburst covers the "radial burst" flavour; no dedicated spiral mode |
| **VIZ-07** | 3D modes (WebGL: sphere / waterfall / starfield) | ✅ Done | rollercoaster (`viz3d.js`, three.js WebGL) + starfield |
| **VIZ-08** | Mode switcher UI (dropdown/cycle) + persistence per track/global | ✅ Done | Mode dropdown + per-track (Save/Reset) + global persistence |
| **VIZ-09** | Sensitivity / smoothing / FFT-size controls | ✅ Done | all three: Sensitivity, Smoothing, FFT size |
| **VIZ-10** | Colour palette per visualiser (reuse theme colours) | ✅ Done | theme / rainbow / mono / custom (3-colour) palettes |
| **VIZ-11** | Fullscreen visualiser mode | ⬜ To do | (P2) |
| **VIZ-12** | Beat-reactive album art (cover pulses/zooms) | 🟡 Partial | `--beat-pulse` loop animates artwork on detected beats (toggle + strength slider); "feel" tuning parked (prior attempts unsatisfying) |
| **VIZ-13** | Snapshot/export current visual as PNG | ⬜ To do | (P3) |

## D. Lyrics panel

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **LYR-01** | Synced lyrics panel with auto-scroll (active line highlighted & centred) | ⬜ To do | (P1) |
| **LYR-02** | Click a line → seek to that timestamp | ⬜ To do | (P1) |
| **LYR-03** | LRC parser (standard + enhanced word-level) | ⬜ To do | (P1) |
| **LYR-04** | Auto-fetch from LRCLIB (free, no key) by title+artist, with graceful "no lyrics" state | ⬜ To do | (P1) |
| **LYR-05** | Manual sync offset (e.g. [ / ] keys ±0.5 s) | ⬜ To do | (P2) |
| **LYR-06** | Paste/upload custom LRC per track + store with track | ⬜ To do | (P2) |
| **LYR-07** | Karaoke mode (fullscreen, large text) | ⬜ To do | (P3) |
| **LYR-08** | Auto-scroll pause on manual scroll, resume notice | ⬜ To do | (P2) |
| **LYR-09** | Lyrics panel layout in/around the round player (drawer vs overlay) | ⬜ To do | design decision — (P1) |

## E. Playlists, queue & library

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **LIB-01** | Create / edit / reorder playlists (drag & drop) | ✅ Done | — |
| **LIB-02** | Per-track theme designer + overall theme + master toggle | ✅ Done | — |
| **LIB-03** | Like / favourite tracks | ✅ Done | — |
| **LIB-04** | ID3/APIC metadata + embedded cover parse | ✅ Done | — |
| **LIB-05** | Queue ("play next" list) | ⬜ To do | (P2) |
| **LIB-06** | Play history (recently played + back/forward) | ⬜ To do | (P2) |
| **LIB-07** | Live search / filter of playlist | ⬜ To do | (P2) |
| **LIB-08** | Sort by title / artist / duration / likes | ⬜ To do | (P2) |
| **LIB-09** | "Play radio from this track" (auto-continue with related tracks) | ⬜ To do | (P3) |
| **LIB-10** | Smart playlists (rules) + pinning | ⬜ To do | (P3) |
| **LIB-11** | Library views: artists / albums / genres / folders | ⬜ To do | (P3) |
| **LIB-12** | Track numbers, album grouping, multi-disc | ⬜ To do | (P3) |

## F. UI, design & theming

### Signature idea: shape-changing player

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **UI-01** | Full colour theming + designer editor | ✅ Done | (beyond most players) |
| **UI-02** | Light/dark mode toggle | ⬜ To do | (P2) |
| **UI-03** | Responsive + mobile touch (swipe to change track) | 🟡 Partial | responsive; gestures pending (P2) |
| **UI-04** | Mini-player / compact "windowshade" mode | ⬜ To do | (P2) |
| **UI-05** | Fullscreen mode | ⬜ To do | (P2, pairs with visualiser/karaoke) |
| **UI-06** | Collapsible panels (playlist / lyrics / visualiser) | 🟡 Partial | playlist panel exists; lyric/viz panels to come |
| **UI-07** | Notifications: "now playing" toast on track change | ⬜ To do | (P2) |
| **UI-08** | Custom player size + border radius + fonts | 🟡 Partial | size fixed 415; make configurable (P2) |
| **UI-09** | Theme export / import (share a look) | ⬜ To do | (P2) |
| **UI-10** | Animated transitions | ✅ Done | (glide-open, theme swaps) |
| **SHAPE-01** | Shape presets: circle (current), triangle, square, pentagon, hexagon, octagon | ⬜ To do | (P2, biggest wow-factor) |
| **SHAPE-02** | Random-shape generator (seeded polygon) | ⬜ To do | (P2) |
| **SHAPE-03** | User-drawn custom shape (drag points on a canvas → polygon) | ⬜ To do | (P3) |
| **SHAPE-04** | Shape mask via `clip-path`/mask + scallop-mask variants per shape | ⬜ To do | (P2) |
| **SHAPE-05** | Controls/buttons/media re-flow per shape (JS layout functions per shape) | ⬜ To do | (P2) |
| **SHAPE-06** | Smooth morph animation between shapes | ⬜ To do | (P2) |
| **SHAPE-07** | Per-shape theme + persist choice with track/global theme | ⬜ To do | (P2) |

## G. OS & platform integration

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **OS-01** | Media Session API: metadata (title/artist/artwork) | ✅ Done | v65 Global tab toggle (default on) |
| **OS-02** | Media Session action handlers: play/pause/next/prev/seek + playbackState | ✅ Done | v65 |
| **OS-03** | `setPositionState` for lock-screen scrubber | ✅ Done | v65 (throttled ~1/s) |
| **OS-04** | Hardware media keys / headset buttons (via Media Session) | ✅ Done | v65 |
| **OS-05** | PWA: manifest + installable + service-worker offline shell | ⬜ To do | (P3, mind server-persistence model) |
| **OS-06** | Web Share API (share track natively) | ⬜ To do | (P3) |
| **OS-07** | Last.fm scrobbling (API key) | ⬜ To do | (P3) |

## H. Embedding & sharing (deploy on any website)

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **EMB-01** | One-line embed via `<script>` tag / iframe + config | 🟡 Partial | data-attribute config works; produce the embed snippet — (P1) |
| **EMB-02** | Auto-generated embed code in the designer ("copy embed code") | ⬜ To do | (P1) |
| **EMB-03** | Embed options: colour, size, autoplay, show/hide download | 🟡 Partial | theme vars exist; add toggles — (P2) |
| **EMB-04** | Download button toggle per track | ⬜ To do | (P2) |
| **EMB-05** | Per-track download with TRACK TITLE as filename + "download full playlist/demo" (VoiceZam "downloads a la mode") | ⬜ To do | (P1) |
| **EMB-06** | Portfolio/showcase mode: named categories (Commercial, Narration, Promo…) with VISIBLE tabs/dropdown (VoiceZam's hidden dropdown was a UX complaint) | ⬜ To do | (P2) |
| **EMB-07** | Contacts panel: artist name, direct contact, agent/representation details, social buttons (VoiceZam "calling card") | ⬜ To do | (P2) |
| **EMB-08** | Play analytics via own server: who listened, how long, per-track play counts (Zamtistics-style, no third party) | ⬜ To do | (P2) |
| **EMB-09** | Buy/support link per track (Bandcamp-style) | ⬜ To do | (P2) |
| **EMB-10** | Share links (X / WhatsApp / copy) with deep link to track | ✅ Done | share exists; deep-link query param — (P2) |
| **EMB-11** | Multiple independent player instances per page | 🟡 Partial | single instance today; scope-check (P3) |
| **EMB-12** | Podcast RSS import (player doubles as podcast player) | ⬜ To do | (P3) |
| **EMB-13** | Third-party URLs (SoundCloud / YouTube / Drive via proxy) | ⬜ To do | (P3) |

## I. Streaming & live

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **ST-01** | Range-request streaming for instant seeking | ✅ Done | — |
| **ST-02** | Live radio URLs (Icecast/Shoutcast) | 🟡 Partial | `<audio>` mostly works; add status handling — (P3) |
| **ST-03** | HLS (.m3u8) via hls.js | ⬜ To do | (P3) |
| **ST-04** | Connecting / buffering / offline status indicators | 🟡 Partial | sync status exists for editor; player-facing needed — (P2) |
| **ST-05** | Fallback stream URL on failure | ⬜ To do | (P3) |

## J. Audio processing & effects

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **FX-01** | Graphic EQ, 8–10 bands (BiquadFilterNode chain) + presets | ⬜ To do | (P2) |
| **FX-02** | Bass boost (low-shelf, 0–24 dB) | ⬜ To do | (P2) |
| **FX-03** | Reverb (ConvolverNode, wet/dry mix) | ⬜ To do | (P3) |
| **FX-04** | Stereo widener + balance/panning | ⬜ To do | (P3) |
| **FX-05** | Loudness normalisation (AGC/ReplayGain) | ⬜ To do | (P3) |
| **FX-06** | EQ curve display + preset save/load | ⬜ To do | (P3) |
| **FX-07** | Audio routing through AudioContext (enables ALL effects + visualisers + crossfade) | ⬜ To do | foundational — (P2, do before FX-01…06) |
| **FX-08** | Compressor / dynamic-range control (VLC) | ⬜ To do | (P2) |
| **FX-09** | Spatializer + headphone virtual surround (VLC) | ⬜ To do | (P3) |
| **FX-10** | Karaoke vocal-reduction filter (VLC; pairs with karaoke lyrics) | ⬜ To do | (P3) |
| **FX-11** | Stereo modes + channel remap (Mono/Stereo/L/R/Reverse) | ⬜ To do | (P3) |
| **FX-12** | EQ preset library | ⬜ To do | 18 VLC-style presets + preamp (Club, Dance, Full Bass, Headphones, Live, Party, Reggae, Ska, Techno…) — (P2) |
| **FX-13** | ReplayGain track + album modes, target-dB normalisation (VLC/Winamp) | ⬜ To do | (P3) |

## K. Accessibility, mobile & i18n

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **ACC-01** | ARIA labels + keyboard focus states on custom controls | 🟡 Partial | partial; audit needed — (P1) |
| **ACC-02** | `prefers-reduced-motion` support | ⬜ To do | (P2) |
| **ACC-03** | Touch targets ≥ 44 px, safe-area insets | 🟡 Partial | audit — (P2) |
| **ACC-04** | Transcripts / captions panel for audio | ⬜ To do | (P3) |
| **ACC-05** | Language packs / i18n | ⬜ To do | (P3) |

## L. Content & metadata

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **MT-01** | ID3 + APIC parse | ✅ Done | — |
| **MT-02** | Auto-fill title/artist from filename | ✅ Done | — |
| **MT-03** | Album grouping, track numbers | ⬜ To do | (P3) |
| **MT-04** | Timestamped comments (SoundCloud-style) | ⬜ To do | (P3) |
| **MT-05** | Track chapters / intros | ⬜ To do | (P3) |

## M. Bandcamp & indie-platform integration (the "Bandcamp radio" story)

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **BC-01** | Import a Bandcamp album/track URL → parse `data-tralbum` metadata → playlist with title/artist/cover/tracks + stream URLs | ⬜ To do | (P2, server-side; bandcamp-fetch pattern) |
| **BC-02** | "Bandcamp radio" mode | ⬜ To do | pre-curated genre/theme playlists from Bandcamp tag feeds + editorial picks, streamed through the player — (P2, the #1 Bandcamp fan wish) |
| **BC-03** | Random-discovery "surprise me" radio | ⬜ To do | random tag/album picks, skip = next pick (Bandcamp Discover's button, continuous) — (P2) |
| **BC-04** | Per-track "Buy / support on Bandcamp" link (name-your-price, artist page) | ⬜ To do | (P2; pairs with EMB-09 buy/support links) |
| **BC-05** | Purchase-prompt etiquette | ⬜ To do | ~3 free plays of an unowned imported track → "support the artist" nudge (mirrors Bandcamp's own 3-play limit; ToS-aware) — (P2) |
| **BC-06** | Attribution-first UI for imported tracks | ⬜ To do | artist, album, release info, link to album page — (P2) |
| **BC-07** | Tag-aware radio browsing | ⬜ To do | stations by Bandcamp tag (genre/mood/location) — (P3) |
| **BC-08** | Audio proxy for imported streams (CORS-safe, reuses Range server) so visualisers/EQ work on Bandcamp audio | ⬜ To do | (P3, needed before VIZ + BC-02 combine) |
| **BC-09** | Official embed fallback | ⬜ To do | "play in Bandcamp's own player" iframe option — (P3) |
| **BC-10** | Owned-collection import via fan login (Bandcamp API partner access; long-term) | ⬜ To do | (P3+) |
| **BC-11** | Radio analytics loop | ⬜ To do | most-liked imported tracks feed back into curation — (P3) |
| **BC-12** | "Bought-together" recommendations surfaced in the player (Bandcamp's hidden panel, made visible) | ⬜ To do | (P3+) |

## DJ playlist engine — gapless, crossfades & pro workflows (planned)

Knowledge base: `docs/dj-gapless-crossfade-knowledge-base.md`. Phased, ease-first.

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **TR-01** | Dual-element A/B engine | ✅ Done | v66 (second `<audio>` into the Web Audio graph; idle→preload→arm→blend→handover) |
| **TR-02** | Per-transition storage | ✅ Done | v66 (`transition` per track → next; persisted in playlist + server theme; global default fallback) |
| **TR-03** | TRUE gapless at 0 s | ✅ Done | v72 (preload + instant handover; incoming element wired + audible; per-track blob tracking so dead blobs revive from THIS track's server copy — never the demo default) |
| **TR-04** | Equal-power crossfade ramp 0–90 s (equal-gain option) | ✅ Done | v72 (overlap verified; deadlock fixed; incoming wired+audible; per-track transform re-applied; volume bug fixed; manual-click grace — a clicked track plays alone, blends only near its natural end; full audit: no phantom playback, click = stop-all + own media) |
| **TR-05** | UI: Global default slider + per-transition editor in Playlist Manager (row ⧉ + apply-to-all) | ✅ Done | v66 (copy/paste presets deferred to TR-17) |
| **TR-06** | Tests: gapless boundary advance, equal-power gain math, per-transition persistence + apply-to-all | ✅ Done | v66 (9 v66 checks) |
| **TR-07** | Vendor `realtime-bpm-analyzer` | ⬜ To do | auto BPM on upload, editable — Phase 2 |
| **TR-08** | Beat-synced transitions (bars → seconds via BPM; bars toggle) | ⬜ To do | Phase 2 |
| **TR-09** | Tempo mode on blend: instant / gradual ramp / tempo-lock | ⬜ To do | Phase 2 |
| **TR-10** | Key column: manual + Mixed In Key/Rekordbox tag import (+ optional chromagram estimate); Camelot display | ⬜ To do | Phase 3 |
| **TR-11** | Energy column (1–10) manual + auto-estimate | ⬜ To do | Phase 3 |
| **TR-12** | Smart filters in the manager (BPM band, key family, energy) | ⬜ To do | Phase 3 |
| **TR-13** | Next-track compatibility suggestions (key/BPM/energy score) | ⬜ To do | Phase 3 |
| **TR-14** | Cue points + phrase/intro-outro markers (manual first) | ⬜ To do | Phase 4 |
| **TR-15** | Loop-aware transitions (blend while looping the outro) | ⬜ To do | Phase 4 |
| **TR-16** | Waveform overview strip in the playlist | ⬜ To do | Phase 4 |
| **TR-17** | "Transition tests" mode + export/import transition presets | ⬜ To do | Phase 4 |
| **TR-18** | Automix / set-planning view (energy arc + key chain) | ⬜ To do | Phase 4 |

## Global Settings tab (v65) — whole-player settings in one place

See `docs/global-settings-tab.md` for the full rationale.

| ID | Feature | Status | Notes / Priority |
|---|---|---|---|
| **GLOB-01** | Overall theme (Save Current as Overall + ON/OFF toggle) | ✅ Done | moved into the Global tab — v65 |
| **GLOB-02** | Autoplay on load | ✅ Done | v65 |
| **GLOB-03** | Loop mode: Off / Repeat all / Repeat one | ✅ Done | v65 |
| **GLOB-04** | Shuffle | ✅ Done | v65 |
| **GLOB-05** | Gapless playback (preload next + instant switch) | ✅ Done | v65 |
| **GLOB-06** | Fade between tracks | ✅ Done | v65 |
| **GLOB-07** | Playback speed 0.5×–2× | ✅ Done | v65 |
| **GLOB-08** | Volume boost 100–200% | ✅ Done | v65 (Web Audio master gain) |
| **GLOB-09** | Resume position per track | ✅ Done | v65 |
| **GLOB-10** | Sleep timer 15/30/45/60 min | ✅ Done | v65 |
| **GLOB-11** | Media Session toggle (lock screen / media keys) | ✅ Done | v65 |
| **GLOB-12** | Default volume | ✅ Done | v65 |
| **GLOB-13** | Reset all settings | ✅ Done | v65 |
| **GLOB-14** | Theme presets (Dark / Light / Neon / Pastel) | ⬜ To do | suggested |
| **GLOB-15** | Import/export theme JSON | ⬜ To do | suggested |
| **GLOB-16** | True crossfade duration (dual-element overlap) | ⬜ To do | suggested |
| **GLOB-17** | Custom skip intervals (forward/rewind seconds) | ⬜ To do | suggested |
| **GLOB-18** | ReplayGain / loudness normalisation | ⬜ To do | suggested |
| **GLOB-19** | Remember last volume/mute | ⬜ To do | suggested |
| **GLOB-20** | A-B repeat | ⬜ To do | suggested |
| **GLOB-21** | PWA install prompt | ⬜ To do | suggested |
| **GLOB-22** | Web Share for the current track | ⬜ To do | suggested |
| **GLOB-23** | Now-playing toast toggle | ⬜ To do | suggested |
| **GLOB-24** | Export/import full config JSON | ⬜ To do | suggested |

---

## 🚀 Suggested first wave (quick wins + wow-factor)

1. **FM-02/FM-03** WAV + FLAC accept & play (trivial)
2. **OS-01/02/04** Media Session API + hardware keys (small, huge payoff)
3. **PL-15** Keyboard shortcuts
4. **PL-10** Resume position
5. **VIZ-01/02/03/08** First visualisers (bars, circular, waveform + switcher)
6. **LYR-01/02/03/04** Lyrics panel with auto-scroll + LRCLIB
7. **EMB-01/02** Embed snippet generator
8. **SHAPE-01/04/05** First shape presets (triangle/octagon) — the differentiator
9. **BC-01/02** Bandcamp URL import + first curated radio stations — the "Bandcamp radio" differentiator (with BC-04/05 buy-links + purchase etiquette for the ethical loop)
10. **EMB-05/06** VoiceZam-style per-track downloads + portfolio categories (the showcase mode)

---

*Reformatted for readability — every feature, status, and note is preserved.*
