# Global Settings Tab — Suggested Features

The editor's **Global Settings** tab hosts everything that applies to the WHOLE player
(not per-track): look, playback behaviour, OS integration, defaults and housekeeping.
Sources: Pulsar Music Player, jellyplay (Jellyfin client), jasperbernaers.com MP3 Player,
VLC/Winamp preferences panels, and our own research docs.

Legend: ✅ implemented in v65 · ⬜ suggested (not yet built)

---

## 1. Look & site blending
- ✅ **Overall theme** — "Save Current as Overall" captures the editor look as ONE theme
  that overrides every track's colours (media stays per-track). Perfect for blending the
  player into a website's palette. Toggle ON/OFF.
- ⬜ **Theme presets** — a few ready-made overall looks (Dark, Light, Neon, Pastel).
- ⬜ **Import/export theme** — paste/copy a JSON theme string to share looks between sites.
- ⬜ **Background opacity / glassmorphism** — global panel translucency.

## 2. Playback behaviour
- ✅ **Autoplay on load** — start playing when the page opens (browser-permitting).
- ✅ **Loop mode** — Off / Repeat all / Repeat one.
- ✅ **Shuffle** — random next track.
- ✅ **Gapless playback** — preload the next track and switch instantly at the end.
- ✅ **Fade between tracks** — short volume fade in/out masks the seam.
- ✅ **Playback speed** — 0.5×–2× (pitch-preserved by the browser).
- ✅ **Volume boost beyond 100%** — up to 200% (VLC-style), via a Web Audio gain node.
- ✅ **Resume position per track** — remembers where each track stopped.
- ✅ **Sleep timer** — pause after 15/30/45/60 min.
- ⬜ **Crossfade duration** — overlap two tracks by N seconds (needs dual-element engine).
- ⬜ **Skip intervals** — custom forward/rewind seconds (currently fixed ±10s).
- ⬜ **ReplayGain / loudness normalisation** — even out track volumes.
- ⬜ **Remember last volume/mute** across reloads.
- ⬜ **A-B repeat** — loop a selected segment (podcast/learning).
- ⬜ **BPM detection + beat-synced visuals** — analyser-based.

## 3. OS & platform integration
- ✅ **Media Session (lock screen / media keys)** — title, artist, artwork + play/pause/
  next/prev/seek on the OS lock screen, notification shade and keyboard media keys.
- ⬜ **PWA install prompt** — "Install this player" toggle (manifest + service worker).
- ⬜ **Web Share** — native share button for the current track.
- ⬜ **Now-playing notifications** — toast on track change (toggle).

## 4. Defaults
- ✅ **Default volume** — the level new sessions start at (applies immediately too).
- ⬜ **Default visualiser** — pick the global visualiser that tracks without their own
  config use (already lives in the Visualisers tab; could be linked here).

## 5. Housekeeping
- ✅ **Reset all settings** — clears themes, playlist, visualiser, global prefs + server
  theme, back to factory defaults.
- ⬜ **Export/import full config** — a single JSON blob for backing up or cloning players.

---

## Why these matter (research notes)
- **Gapless + crossfade** are the #1 requested music-player features everywhere
  (r/DigitalAudioPlayer: "a hard pass without it").
- **Media Session** is the #1 "feels native" web feature — one ~40-line API gives lock
  screen + hardware keys.
- **Volume boost** is a beloved VLC quirk; **speed** is standard in every player.
- **Sleep timer** (15/30/45/60) appears in virtually every player (Pulsar, VLC, web players).
- **Overall theme** answers the user's core goal: blend the player into a website without
  touching track-by-track themes.
