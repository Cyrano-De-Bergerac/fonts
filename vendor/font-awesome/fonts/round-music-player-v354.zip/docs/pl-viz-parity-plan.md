# 🎯 Playlist Panel Visualiser — Full Parity Action Plan

> Goal: the playlist panel has EXACTLY the same visualiser capabilities as the
> main player — all modes (2D + Coaster + Milkdrop), edge modes, mirror-on-top,
> artwork backdrop, framing (centre default + reset), cinema toggle, and preset
> switching. Built right in one pass.
>
> **Status:** ✅ COMPLETE — Coaster (Step 3) + Edge (Step 5) built in Entry S21 (v207). Playlist panel now has FULL visualiser parity with the main player. Only Step 6 (Centre-default fill/reset buttons) remains as a minor polish item.
> **Created:** 2026-08-20

---

## 1. The 7 issues + fixes

### 1.1 No Coaster on playlist
**Fix:** Refactor `viz3d.js` to accept a `target` argument in `_boot(targetId)` so it can create a second coaster instance on the playlist circle. The module exports `createInstance(targetId, audioCtx)` instead of a singleton. The main player calls it with `'player'`, the playlist with `'playlistCircle'`.

### 1.2 No artwork/media behind visualiser
**Fix:** CSS specificity — change `.playlist-circle.pl-viz-active > .pl-backdrop` to use `!important` (it already does but `.pl-media-off > .pl-backdrop { display: none }` may win). Also ensure the `pl-viz-active` class is actually being added (add console.log to verify). Additionally, when PL viz is on, the backdrop should show the TRACK's cover art (plCover), not just colors.

### 1.3 Mirror should layer WITH a visualiser (not be a separate mode)
**Fix:** Remove `'mirror'` from the PL mode dropdown. Instead, add a separate **"Mirror main player" checkbox** (`vizPlMirror`) in the PL visualiser section. When checked, a mirror canvas (`#plMirrorCanvas`) renders the main player's current visual (2D modes) at playlist-canvas dimensions — BEHIND the independent PL viz. So the user can have: Mirror ON (main player's Bars mirrored behind) + PL mode = Milkdrop (on top). Both visible, layered.

### 1.4 Playlist defaults to cinema + needs a toggle
**Fix:**
- Remove the `plCircle.classList.add('pl-cinema')` from init (so the playlist starts with the list VISIBLE).
- The existing **"Playlist cinema"** checkbox in Global Settings already toggles it. Make sure it defaults to **unchecked** (gs.plCinema = false) so the playlist starts non-cinema.
- The mouseenter/mouseleave behavior only activates when the checkbox is ON.

### 1.5 No Milkdrop preset switching on playlist
**Fix:** Add ◀ ▶ preset cycle buttons (reuse the `cycleMilkdropPreset` pattern but for the PL Milkdrop instance: `cyclePlMilkdropPreset(dir)`). Show them in the PL visualiser section when PL mode = milkdrop.

### 1.6 No edge modes on playlist
**Fix:** Create a `.pl-edge` canvas as a child of `.player-pair` (sibling of `.playlist-circle`), sized 1.7× the disc, positioned over the playlist disc (which is offset to the right by `--pair-gap`). The PL edge canvas glides RIGHT (opposite of the main edge which glides left). Reuse the 8 edge draw functions with PL-specific settings (`viz.plEdgeMode`, `viz.plEdgeReach`, etc.). Add a "PL Edge mode" dropdown to the editor.

### 1.7 No centre default / reset for visualisers
**Fix:**
- All PL viz canvases default to `transform: none` (centre, scale 1) — the CSS vars `--pl-viz-dx/dy/scale` default to `0px/0px/1`.
- Add a **"Centre" button** (one-click reset) next to the PL framing controls that sets `--pl-viz-dx = 0px; --pl-viz-dy = 0px; --pl-viz-scale = 1`.
- Apply the same to the MAIN player's visualiser framing (add a "Centre" button there too).
- For media (cover/video), ensure the auto-fill default centres the media in the circle.

---

## 2. Architecture

### 2.1 Canvases on the playlist circle (DOM order, bottom to top)
```
.playlist-circle
  .pl-bg                    (base color)
  .pl-backdrop              (cover art + video)
    #plCover (img)
    #plVideo (video)
  .pl-viz-canvas            (2D visualiser — bars/radial/etc.)
  .pl-viz-canvas-milkdrop   (Milkdrop WebGL — separate canvas)
  .pl-viz-canvas-3d         (Coaster WebGL — separate canvas, new)
  .pl-mirror-canvas         (mirror of main player's viz — new)
  .pl-gradient              (color gradient)
  .pl-scrim                 (readability scrim)
  .pl-viewport > .pl-list   (track list)
  .pl-scroll                (curved scrollbar)
```
All canvases: `position:absolute; inset:0; border-radius:50%; overflow:hidden; pointer-events:none; display:none;` + `.visible { display:block; }`.

### 2.2 Edge canvas for playlist
A `.pl-edge` canvas as a child of `.player-pair` (like `.viz-edge`), positioned over the playlist disc. Glide: RIGHT (`translateX(calc(var(--open) * var(--pair-gap)))`). Size: 1.7× disc.

### 2.3 Settings (viz object additions)
```
plMode: 'off'              // off | bars | radial | waveform | starfield | plasma | milkdrop | coaster
plOpacity: 0.85
plEdgeMode: 'off'          // off | edge-bars | edge-mirror | edge-bass | edge-ripple | ...
plEdgeReach: 35
plMirror: false            // mirror main player viz behind PL viz
plMilkdropPreset: null     // preset name for PL milkdrop
```

### 2.4 Editor UI (Visualisers tab → "Playlist visualiser" section)
```
PL mode:      [Off ▼]  (Off / Bars / Radial / Waveform / Starfield / Plasma / Milkdrop / Coaster)
PL opacity:   [━━●━━] 85%
PL Milkdrop preset: [◀] Preset name [▶]   (shown when mode=milkdrop)
PL edge mode: [Off ▼]  (Off / Outer Bars / Mirror / Bass Ring / ...)
PL edge reach:[━━●━━] 35%
☑ Mirror main player (layer behind PL viz)
PL framing:   [Reposition] [Centre] [Reset]
PL zoom:      [━━●━━] 1.00×
```

---

## 3. Implementation steps (build order)

### Step 1: CSS fixes (quick wins)
- Fix backdrop visibility (`!important` specificity).
- Remove init `pl-cinema` class; default `gs.plCinema = false`.
- Add Centre button CSS.
- Add `.pl-edge` canvas CSS (glide right).

### Step 2: Mirror-on-top
- Add `#plMirrorCanvas` to the playlist circle.
- `plMirrorTick()`: reads main player's analyser data, draws the main player's CURRENT mode to the mirror canvas (behind the PL viz).
- Add "Mirror main player" checkbox.

### Step 3: Coaster on playlist
- Refactor `viz3d.js`: `_boot(targetId)` → creates canvas inside the target element. Export `window.RoundViz3D.create(targetId)`.
- Main player: `RoundViz3D.create('player')`. Playlist: `RoundViz3D.create('playlistCircle')`.
- Two independent coaster instances, each with its own canvas/scene/camera.

### Step 4: Milkdrop preset switching on playlist
- `cyclePlMilkdropPreset(dir)` + ◀ ▶ buttons in the editor.
- Reuse the preset list from the main Milkdrop instance.

### Step 5: Edge modes on playlist
- `ensurePlEdgeCanvas()` → creates `.pl-edge` in `.player-pair`.
- `plEdgeTick()` → reuses the 8 edge draw functions.
- Glide RIGHT (opposite of main edge).
- PL edge settings (mode, reach) independent.

### Step 6: Centre defaults + reset buttons
- All viz/media framing defaults to centre (dx=0, dy=0, scale=1 or auto-fill).
- "Centre" button on both main player + playlist visualiser sections.
- Ensures visualisers fill the circle by default.

### Step 7: Wire + persist + test
- Bind all new controls.
- Persist in per-track viz config.
- Rebuild zip.

---

## 4. Effort estimate
~2 focused sessions. Step 3 (Coaster refactor) is the highest-risk item.

## 5. What you get
- Main player: Bars. Playlist: Milkdrop with preset switching + mirrored Bars behind + edge rings around the playlist disc + artwork backdrop + cinema toggle + centre/reset framing. All independent. All per-track.
